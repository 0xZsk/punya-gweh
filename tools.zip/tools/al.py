from urllib.parse import urlsplit
import re, os

src = "/home/mikusec/Documents/filter/resultlogs/wpall.txt"
out = "/home/mikusec/Documents/mass_exploit_wp2shell/ac.txt"

seen = set()
domains = []

with open(src, "r", encoding="utf-8", errors="ignore") as f:
    for line in f:
        m = re.search(r'https?://[^\s:]+', line.strip())
        if not m:
            continue

        host = urlsplit(m.group(0)).hostname
        if not host:
            continue

        host = host.lower().rstrip(".")
        if host.startswith("www."):
            host = host[4:]

        if host not in seen:
            seen.add(host)
            domains.append(host)

with open(out, "w", encoding="utf-8") as f:
    f.write("\n".join(domains) + "\n")

print(f"Done ngab — {len(domains):,} domain unik.")
print(f"File: {out}")
