#!/usr/bin/env python3
"""Merge per-instance output files into single files with dedup."""
import glob, os
from pathlib import Path

ROOT = Path(__file__).resolve().parent

def merge(pattern, outfile):
    seen = set()
    lines = []
    for f in sorted(glob.glob(str(ROOT / pattern))):
        try:
            for line in open(f, encoding="utf-8", errors="replace"):
                d = line.split("|", 1)[0].strip().lower()
                if d and d not in seen:
                    seen.add(d)
                    lines.append(line if line.endswith("\n") else line + "\n")
        except: pass
    out = ROOT / outfile
    with open(out, "w", encoding="utf-8") as fh:
        fh.writelines(lines)
    print(f"{outfile}: {len(lines)} unique from {pattern}")

if __name__ == "__main__":
    merge("mass_verified_admins_*.txt", "mass_verified_admins_merged.txt")
    merge("mass_manual_check_*.txt", "mass_manual_check_merged.txt")
    merge("mass_failed_*.txt", "mass_failed_merged.txt")
    print("\nDone! Merged files ready.")
