import os
import sys
import time
import random
from colorama import Fore, Style, init

init(autoreset=True)

# ========== WARNA ==========
def get_random_color_code():
    color_codes = ["\033[91m", "\033[92m", "\033[93m", "\033[94m", "\033[95m", "\033[96m"]
    return random.choice(color_codes)

# ========== FILTER CORE ==========
def filter_lines(input_file, output_file, keywords, encoding='utf-8'):
    """Filter baris dalam file berdasarkan keyword (hemat RAM)."""
    extracted_count = 0
    try:
        with open(input_file, 'r', encoding=encoding, errors='ignore') as infile, \
             open(output_file, 'a', encoding=encoding) as outfile:
            for line in infile:
                if any(keyword in line for keyword in keywords):
                    outfile.write(line)
                    extracted_count += 1
    except Exception as e:
        print(f"{Fore.RED}Error processing {input_file}: {e}{Style.RESET_ALL}")
    return extracted_count

# ========== FILE HANDLER ==========
def get_txt_files_from_directory(directory):
    """Ambil semua file .txt di folder."""
    try:
        return [os.path.join(directory, f) for f in os.listdir(directory) if f.endswith('.txt')]
    except Exception as e:
        print(f"{Fore.RED}Error membaca direktori: {e}{Style.RESET_ALL}")
        return []

def choose_files(files):
    """Pilih file single / multiple."""
    print(f"\n{Fore.CYAN}📂 File .txt terdeteksi di folder ini:{Style.RESET_ALL}")
    for i, file in enumerate(files, 1):
        print(f"  {i}. {os.path.basename(file)}")

    print(f"\n{Fore.YELLOW}Ketik nomor file (mis: 1,3,5-7) → Enter untuk semua file:{Style.RESET_ALL}")
    choice = input("> ").strip()

    if not choice:
        return files  # pilih semua

    selected_indices = set()
    for token in choice.split(","):
        token = token.strip()
        if "-" in token:
            start, end = token.split("-", 1)
            if start.isdigit() and end.isdigit():
                selected_indices.update(range(int(start), int(end) + 1))
        elif token.isdigit():
            selected_indices.add(int(token))

    selected = [files[i - 1] for i in sorted(selected_indices) if 1 <= i <= len(files)]
    return selected

# ========== FILTER PRESET ==========
def choose_filter():
    """User bisa pilih filter preset atau custom keyword."""
    presets = {
        "1": ["gov.my", "gov.ng", "gov.ph", "gov.pk", "gov.in", "gov.za", "gov.au", "gov.sg", "gov.bd"],
        "2": ["go.th", "go.kr", "go.jp", "go.cn", "go.uk", "go.br", "go.mx", "go.us"],  # tanpa go.id
        "3": ["edu.in", "edu.pk", "edu.ng", "edu.ph", "edu.my", "edu.bd", "edu.uk", "edu.au", "edu.br"],
        "4": ["ac.in", "ac.za", "ac.kr", "ac.uk", "ac.my", "ac.th", "ac.ng", "ac.pk"],  # tanpa ac.id
        "5": ["go.id/", "ac.id/", "sch.id/"],  # local Indonesia
    }

    print(f"\n{Fore.CYAN}🎯 Pilihan Filter Preset:{Style.RESET_ALL}")
    print("  1. gov.*  → domain pemerintah luar (gov.my, gov.ph, gov.pk, dll)")
    print("  2. go.*   → domain pemerintahan global (go.jp, go.kr, go.th, dll)")
    print("  3. edu.*  → domain pendidikan global (edu.in, edu.ng, dll)")
    print("  4. ac.*   → domain akademik luar (ac.in, ac.za, ac.uk, dll)")
    print("  5. local id → domain lokal Indonesia (go.id, ac.id, sch.id, co.id)")
    print(f"  6. Custom → keyword buatan sendiri")

    choice = input(f"\n{Fore.YELLOW}Pilih filter (1-6): {Style.RESET_ALL}").strip()

    if choice in presets:
        return presets[choice]
    elif choice == "6":
        custom_input = input(f"{Fore.YELLOW}Masukkan keyword dipisahkan koma (contoh: panel,root,server): {Style.RESET_ALL}")
        return [x.strip() for x in custom_input.split(",") if x.strip()]
    else:
        print(f"{Fore.RED}Pilihan tidak valid, gunakan custom keyword.{Style.RESET_ALL}")
        return choose_filter()

# ========== MAIN ENGINE ==========
def main():
    try:
        start_time = time.time()
        current_dir = os.path.dirname(os.path.abspath(__file__))

        # Folder output "resultlogs"
        result_dir = os.path.join(current_dir, "resultlogs")
        if not os.path.exists(result_dir):
            os.makedirs(result_dir)
            print(f"{Fore.YELLOW}📁 Folder 'resultlogs' dibuat otomatis.{Style.RESET_ALL}")

        # Ambil daftar file .txt
        txt_files = get_txt_files_from_directory(current_dir)
        if not txt_files:
            print(f"{Fore.RED}❌ Tidak ada file .txt ditemukan di folder ini.{Style.RESET_ALL}")
            return

        # Pilih file (single / multi)
        selected_files = choose_files(txt_files)
        print(f"\n{Fore.GREEN}Dipilih {len(selected_files)} file:{Style.RESET_ALL}")
        for f in selected_files:
            print(f"  - {os.path.basename(f)}")

        # Pilih filter (preset / custom)
        keywords = choose_filter()
        print(f"\n{Fore.MAGENTA}🔍 Filter aktif: {', '.join(keywords)}{Style.RESET_ALL}")

        # Nama file output
        output_name = input(f"\n{Fore.YELLOW}Masukkan nama file output (contoh: hasil.txt): {Style.RESET_ALL}").strip()
        if not output_name:
            output_name = "result.txt"

        # Path lengkap output file
        output_file = os.path.join(result_dir, output_name)

        print(f"\n{Fore.CYAN}🚀 Mulai proses filter...{Style.RESET_ALL}\n")
        total_extracted = 0
        total_files = len(selected_files)

        for i, file in enumerate(selected_files, 1):
            extracted = filter_lines(file, output_file, keywords)
            total_extracted += extracted

            color = get_random_color_code()
            elapsed = time.strftime('%H:%M:%S', time.gmtime(time.time() - start_time))
            name = os.path.basename(file).ljust(25)
            sys.stdout.write(f"{color}[{elapsed}] {name} → {extracted} baris cocok | File {i}/{total_files}\033[0m\n")
            sys.stdout.flush()

        print(f"\n{Fore.GREEN}✅ Selesai! Total hasil cocok: {total_extracted}{Style.RESET_ALL}")
        print(f"{Fore.CYAN}Semua hasil disimpan di: {output_file}{Style.RESET_ALL}\n")

    except KeyboardInterrupt:
        print(f"\n{Fore.RED}❌ Dihentikan oleh pengguna.{Style.RESET_ALL}")
    except Exception as e:
        print(f"{Fore.RED}Terjadi kesalahan: {e}{Style.RESET_ALL}")

# ========== RUN ==========
if __name__ == "__main__":
    main()
