#!/usr/bin/env bash

echo "=== 4 Terminal Launcher ==="
echo

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR" || exit 1

for i in 1 2 3 4; do
    if command -v gnome-terminal >/dev/null 2>&1; then
        gnome-terminal \
            --title="MASS-$i" \
            -- bash -c "cd '$SCRIPT_DIR' && python3 mass_exploit.py $i; exec bash" &
    elif command -v xfce4-terminal >/dev/null 2>&1; then
        xfce4-terminal \
            --title="MASS-$i" \
            --command="bash -c 'cd \"$SCRIPT_DIR\" && python3 mass_exploit.py $i; exec bash'" &
    elif command -v konsole >/dev/null 2>&1; then
        konsole \
            --hold \
            --title="MASS-$i" \
            -e bash -c "cd '$SCRIPT_DIR' && python3 mass_exploit.py $i" &
    else
        echo "Tidak ada terminal GUI yang didukung."
        exit 1
    fi

    # Jeda 3 detik seperti timeout /t 3 di .bat
    [[ "$i" -lt 4 ]] && sleep 3
done

echo
echo "4 terminal launched!"
echo
read -r -p "Press Enter to continue..."
