# main.py
import tkinter as tk
from tkinter import filedialog, messagebox, ttk, scrolledtext
import threading
import sorter
import checker
import merge
import searcher

THEMES = {
    "Dark": {
        "bg": "#121212", "card": "#1e1e1e", "fg": "#e0e0e0",
        "accent": "#4fc3f7", "entry": "#2a2a2a", "log_fg": "#b0b0b0",
    },
    "Darker": {
        "bg": "#0a0a0a", "card": "#141414", "fg": "#d0d0d0",
        "accent": "#00e676", "entry": "#1a1a1a", "log_fg": "#9e9e9e",
    },
    "Midnight": {
        "bg": "#0d1117", "card": "#161b22", "fg": "#c9d1d9",
        "accent": "#58a6ff", "entry": "#21262d", "log_fg": "#8b949e",
    },
    "Purple": {
        "bg": "#13111c", "card": "#1c1829", "fg": "#e0d6f5",
        "accent": "#b388ff", "entry": "#2a2438", "log_fg": "#a89cc8",
    },
}


class App:
    def __init__(self, root):
        self.root = root
        self.root.title("Wordlist Tools")
        self.root.geometry("1020x760")
        self.root.minsize(940, 680)

        self.current_theme = "Dark"
        self.colors = THEMES[self.current_theme]

        self.file_path = tk.StringVar()
        self.output_name = tk.StringVar(value="hasil")
        self.single_url = tk.StringVar()

        self.sort_az = tk.BooleanVar(value=True)
        self.domain_only = tk.BooleanVar(value=False)
        self.remove_dupe = tk.BooleanVar(value=True)
        self.keep_scheme = tk.BooleanVar(value=False)
        self.type_vars = {t: tk.BooleanVar() for t in sorter.DOMAIN_PATTERNS}
        self.country_vars = {c: tk.BooleanVar() for c in sorter.COUNTRY_TLDS}

        # Checker mode: single / mass_alive / mass_cms
        self.check_mode = tk.StringVar(value="mass_alive")
        self.cms_vars = {}

        # Merge
        self.merge_paths = []
        self.merge_output = tk.StringVar(value="merged")
        self.merge_dupe = tk.BooleanVar(value=True)
        self.merge_sort = tk.BooleanVar(value=False)
        self.merge_skip_empty = tk.BooleanVar(value=True)

        # searcher
        self.searcher_input = tk.StringVar()

        self.stop_flag = False
        self.entries = []

        self.build_ui()
        self.apply_theme()
        self.on_domain_only()
        self.toggle_checker_mode()

    def apply_theme(self):
        c = self.colors
        self.root.configure(bg=c["bg"])
        style = ttk.Style()
        style.theme_use("clam")

        style.configure(".", background=c["bg"], foreground=c["fg"])
        style.configure("TFrame", background=c["bg"])
        style.configure("TLabel", background=c["bg"], foreground=c["fg"])
        style.configure(
            "TCheckbutton", background=c["bg"], foreground=c["fg"],
            indicatorbackground=c["entry"], indicatorforeground=c["accent"],
        )
        style.map(
            "TCheckbutton",
            background=[("active", c["bg"])],
            indicatorbackground=[
                ("selected", c["accent"]), ("!selected", c["entry"]),
            ],
            indicatorforeground=[("selected", "#000000"), ("!selected", c["fg"])],
        )
        style.configure(
            "TRadiobutton", background=c["bg"], foreground=c["fg"],
            indicatorbackground=c["entry"],
        )
        style.map(
            "TRadiobutton",
            background=[("active", c["bg"])],
            indicatorbackground=[
                ("selected", c["accent"]), ("!selected", c["entry"]),
            ],
        )
        style.configure(
            "TButton", background=c["card"], foreground=c["fg"], padding=(12, 6)
        )
        style.map(
            "TButton",
            background=[("pressed", c["accent"]), ("active", c["accent"])],
            foreground=[("pressed", "#000000"), ("active", "#000000")],
        )
        style.configure("TNotebook", background=c["bg"], borderwidth=0)
        style.configure(
            "TNotebook.Tab", background=c["card"], foreground=c["fg"], padding=[14, 6]
        )
        style.map(
            "TNotebook.Tab",
            background=[("selected", c["card"])],
            foreground=[("selected", c["accent"])],
        )
        style.configure("TLabelframe", background=c["bg"], foreground=c["accent"])
        style.configure(
            "TLabelframe.Label", background=c["bg"], foreground=c["accent"]
        )
        style.configure("Vertical.TScrollbar", background=c["card"])
        style.configure(
            "Treeview",
            background=c["entry"], foreground=c["fg"],
            fieldbackground=c["entry"], rowheight=22,
        )
        style.map("Treeview", background=[("selected", c["accent"])])

        for e in self.entries:
            e.configure(
                bg=c["entry"], fg=c["fg"], insertbackground=c["fg"],
                relief="flat", highlightthickness=0,
            )
        for w in (self.sort_log, self.log_text, self.merge_log, self.searcher_log):
            w.configure(bg=c["entry"], fg=c["log_fg"], insertbackground=c["fg"])
        if hasattr(self, "country_canvas"):
            self.country_canvas.configure(bg=c["bg"], highlightthickness=0)

    def cycle_theme(self):
        names = list(THEMES.keys())
        self.current_theme = names[(names.index(self.current_theme) + 1) % len(names)]
        self.colors = THEMES[self.current_theme]
        self.theme_btn.configure(text=f"Theme: {self.current_theme}")
        self.apply_theme()

    def _entry(self, parent, textvariable, width):
        e = tk.Entry(parent, textvariable=textvariable, width=width)
        self.entries.append(e)
        return e

    def build_ui(self):
        header = ttk.Frame(self.root)
        header.pack(fill="x", padx=8, pady=(6, 0))
        ttk.Label(header, text="Wordlist Tools", font=("", 11, "bold")).pack(side="left")
        self.theme_btn = ttk.Button(
            header, text=f"Theme: {self.current_theme}", command=self.cycle_theme
        )
        self.theme_btn.pack(side="right")

        self.nb = ttk.Notebook(self.root)
        self.nb.pack(fill="both", expand=True, padx=8, pady=6)

        self._build_sort_tab()
        self._build_check_tab()
        self._build_merge_tab()
        self._build_searcher_tab()

    # ─── SORTING ───
    def _build_sort_tab(self):
        tab = ttk.Frame(self.nb, padding=6)
        self.nb.add(tab, text="  Sorting & Filter  ")

        r1 = ttk.Frame(tab)
        r1.pack(fill="x", pady=1)
        ttk.Label(r1, text="File:", width=12).pack(side="left")
        self._entry(r1, self.file_path, 52).pack(side="left", padx=4, fill="x", expand=True)
        ttk.Button(r1, text="Browse", width=10, command=self.browse).pack(side="left", padx=2)

        r2 = ttk.Frame(tab)
        r2.pack(fill="x", pady=1)
        ttk.Label(r2, text="Nama Output:", width=12).pack(side="left")
        self._entry(r2, self.output_name, 16).pack(side="left", padx=4)
        ttk.Label(r2, text="→ sorter/").pack(side="left")

        self.op_frame = ttk.LabelFrame(tab, text="Opsi", padding=4)
        self.op_frame.pack(fill="x", pady=3)
        self.chk_az = ttk.Checkbutton(self.op_frame, text="Sort A-Z", variable=self.sort_az)
        self.chk_dupe = ttk.Checkbutton(self.op_frame, text="Hapus Duplicate", variable=self.remove_dupe)
        self.lbl_dupe = ttk.Label(self.op_frame, text="☑ Hapus Duplicate")
        self.chk_domain = ttk.Checkbutton(
            self.op_frame, text="Domain Only", variable=self.domain_only, command=self.on_domain_only
        )
        self.chk_scheme = ttk.Checkbutton(self.op_frame, text="HTTP+HTTPS", variable=self.keep_scheme)
        self.chk_az.pack(side="left", padx=8)

        mid = ttk.Frame(tab)
        mid.pack(fill="x", pady=3)
        left = ttk.LabelFrame(mid, text="Domain Type", padding=4)
        left.pack(side="left", fill="both", expand=True, padx=(0, 3))
        types = list(sorter.DOMAIN_PATTERNS.keys())
        for i, t in enumerate(types):
            ttk.Checkbutton(left, text=t, variable=self.type_vars[t]).grid(
                row=i // 5, column=i % 5, sticky="w", padx=3, pady=0
            )
        bf = ttk.Frame(left)
        bf.grid(row=(len(types) // 5) + 1, column=0, columnspan=5, pady=4, sticky="w")
        ttk.Button(bf, text="All", width=8, command=lambda: self.set_all(self.type_vars, True)).pack(side="left", padx=2)
        ttk.Button(bf, text="Clear", width=8, command=lambda: self.set_all(self.type_vars, False)).pack(side="left", padx=2)

        right = ttk.LabelFrame(mid, text="Negara (type kosong = strict nama.negara)", padding=4)
        right.pack(side="left", fill="both", expand=True, padx=(3, 0))
        cf = ttk.Frame(right)
        cf.pack(fill="both", expand=True)
        self.country_canvas = tk.Canvas(cf, height=110, highlightthickness=0)
        sb = ttk.Scrollbar(cf, orient="vertical", command=self.country_canvas.yview)
        inner = ttk.Frame(self.country_canvas)
        inner.bind("<Configure>", lambda e: self.country_canvas.configure(scrollregion=self.country_canvas.bbox("all")))
        self.country_canvas.create_window((0, 0), window=inner, anchor="nw")
        self.country_canvas.configure(yscrollcommand=sb.set)

        def _mw(e):
            self.country_canvas.yview_scroll(int(-1 * (e.delta / 120)), "units")
        def _bind_mw(e):
            self.country_canvas.bind_all("<MouseWheel>", _mw)
            self.country_canvas.bind_all("<Button-4>", lambda ev: self.country_canvas.yview_scroll(-1, "units"))
            self.country_canvas.bind_all("<Button-5>", lambda ev: self.country_canvas.yview_scroll(1, "units"))
        def _unbind_mw(e):
            self.country_canvas.unbind_all("<MouseWheel>")
            self.country_canvas.unbind_all("<Button-4>")
            self.country_canvas.unbind_all("<Button-5>")
        self.country_canvas.bind("<Enter>", _bind_mw)
        self.country_canvas.bind("<Leave>", _unbind_mw)
        inner.bind("<Enter>", _bind_mw)
        inner.bind("<Leave>", _unbind_mw)
        self.country_canvas.pack(side="left", fill="both", expand=True)
        sb.pack(side="right", fill="y")
        for i, c in enumerate(sorter.COUNTRY_TLDS):
            ttk.Checkbutton(inner, text=f".{c}", variable=self.country_vars[c]).grid(
                row=i // 10, column=i % 10, sticky="w", padx=1, pady=0
            )
        bf2 = ttk.Frame(right)
        bf2.pack(fill="x", pady=2)
        ttk.Button(bf2, text="All", width=8, command=lambda: self.set_all(self.country_vars, True)).pack(side="left", padx=2)
        ttk.Button(bf2, text="Clear", width=8, command=lambda: self.set_all(self.country_vars, False)).pack(side="left", padx=2)

        lf = ttk.LabelFrame(tab, text="Log Sorting", padding=3)
        lf.pack(fill="both", expand=True, pady=3)
        self.sort_log = scrolledtext.ScrolledText(lf, height=7, relief="flat", font=("Consolas", 9))
        self.sort_log.pack(fill="both", expand=True)
        btn = ttk.Frame(tab)
        btn.pack(fill="x", pady=(8, 10))
        ttk.Button(btn, text="START", width=10, command=self.run_sorting).pack(side="left", padx=4, ipady=3)
        ttk.Button(btn, text="STOP", width=10, command=self.stop_sorting).pack(side="left", padx=4, ipady=3)

    # ─── CHECKER ───
    def _build_check_tab(self):
        tab = ttk.Frame(self.nb, padding=6)
        self.nb.add(tab, text="  Alive + CMS Checker  ")

        self.input_row = ttk.Frame(tab, height=36)
        self.input_row.pack(fill="x", pady=2)
        self.input_row.pack_propagate(False)

        self.single_input = ttk.Frame(self.input_row)
        ttk.Label(self.single_input, text="URL:", width=12).pack(side="left")
        self._entry(self.single_input, self.single_url, 58).pack(side="left", padx=4, fill="x", expand=True)

        self.mass_input = ttk.Frame(self.input_row)
        ttk.Label(self.mass_input, text="File:", width=12).pack(side="left")
        self._entry(self.mass_input, self.file_path, 52).pack(side="left", padx=4, fill="x", expand=True)
        ttk.Button(self.mass_input, text="Browse", width=10, command=self.browse).pack(side="left", padx=2)

        # Mode
        modef = ttk.LabelFrame(tab, text="Mode", padding=6)
        modef.pack(fill="x", pady=4)
        ttk.Radiobutton(
            modef, text="Single", variable=self.check_mode, value="single",
            command=self.toggle_checker_mode
        ).pack(side="left", padx=12, ipady=4)
        ttk.Radiobutton(
            modef, text="Mass Alive", variable=self.check_mode, value="mass_alive",
            command=self.toggle_checker_mode
        ).pack(side="left", padx=12, ipady=4)
        ttk.Radiobutton(
            modef, text="Mass CMS", variable=self.check_mode, value="mass_cms",
            command=self.toggle_checker_mode
        ).pack(side="left", padx=12, ipady=4)

        # CMS frame — di-pack di tengah (antara Mode dan Log)
        self.cms_frame = ttk.LabelFrame(tab, text="CMS / Framework", padding=4)
        try:
            names = list(checker.DETECT_ORDER)
        except Exception:
            names = ["WordPress", "Joomla", "Drupal", "Moodle", "phpBB", "PKP_OJS",
                     "phpMyAdmin", "cPanel", "WHM", "Laravel", "CodeIgniter", "Yii", "Django"]
        self.cms_vars = {name: tk.BooleanVar(value=True) for name in names}
        for i, name in enumerate(names):
            ttk.Checkbutton(self.cms_frame, text=name, variable=self.cms_vars[name]).grid(
                row=i // 6, column=i % 6, sticky="w", padx=6, pady=2
            )
        # Pack dulu (akan di-forget di toggle kalau bukan mass_cms)
        self.cms_frame.pack(fill="x", pady=2)

        # Log — selalu di bawah
        self.log_frame = ttk.LabelFrame(tab, text="Log", padding=3)
        self.log_frame.pack(fill="both", expand=True, pady=3)
        self.log_text = scrolledtext.ScrolledText(self.log_frame, height=10, relief="flat", font=("Consolas", 10))
        self.log_text.pack(fill="both", expand=True)

        btn = ttk.Frame(tab)
        btn.pack(fill="x", pady=(8, 10))
        ttk.Button(btn, text="START", width=10, command=self.start_checker).pack(side="left", padx=4, ipady=3)
        ttk.Button(btn, text="STOP", width=10, command=self.stop_checker).pack(side="left", padx=4, ipady=3)

    # ─── MERGE ───
    def _build_merge_tab(self):
        tab = ttk.Frame(self.nb, padding=6)
        self.nb.add(tab, text="  Merge Files  ")
        top = ttk.Frame(tab)
        top.pack(fill="x", pady=2)
        ttk.Button(top, text="Multi File", width=12, command=self.merge_pick_files).pack(side="left", padx=2)
        ttk.Button(top, text="Select Folder", width=12, command=self.merge_pick_folder).pack(side="left", padx=2)
        ttk.Button(top, text="Clear List", width=10, command=self.merge_clear).pack(side="left", padx=2)
        r = ttk.Frame(tab)
        r.pack(fill="x", pady=2)
        ttk.Label(r, text="Nama Output:", width=12).pack(side="left")
        self._entry(r, self.merge_output, 20).pack(side="left", padx=4)
        ttk.Label(r, text="→ merge/").pack(side="left")
        op = ttk.LabelFrame(tab, text="Opsi", padding=4)
        op.pack(fill="x", pady=3)
        ttk.Checkbutton(op, text="Hapus Duplicate", variable=self.merge_dupe).pack(side="left", padx=8)
        ttk.Checkbutton(op, text="Sort A-Z", variable=self.merge_sort).pack(side="left", padx=8)
        ttk.Checkbutton(op, text="Skip baris kosong", variable=self.merge_skip_empty).pack(side="left", padx=8)
        prev = ttk.LabelFrame(tab, text="Preview file", padding=3)
        prev.pack(fill="both", expand=True, pady=3)
        self.merge_tree = ttk.Treeview(prev, columns=("name", "lines", "path"), show="headings", height=8)
        self.merge_tree.heading("name", text="Nama file")
        self.merge_tree.heading("lines", text="Baris")
        self.merge_tree.heading("path", text="Path")
        self.merge_tree.column("name", width=180)
        self.merge_tree.column("lines", width=80, anchor="e")
        self.merge_tree.column("path", width=420)
        msb = ttk.Scrollbar(prev, orient="vertical", command=self.merge_tree.yview)
        self.merge_tree.configure(yscrollcommand=msb.set)
        self.merge_tree.pack(side="left", fill="both", expand=True)
        msb.pack(side="right", fill="y")
        self.merge_total_lbl = ttk.Label(tab, text="Total: 0 file | 0 baris")
        self.merge_total_lbl.pack(anchor="w", pady=2)
        lf = ttk.LabelFrame(tab, text="Log Merge", padding=3)
        lf.pack(fill="both", expand=True, pady=3)
        self.merge_log = scrolledtext.ScrolledText(lf, height=6, relief="flat", font=("Consolas", 9))
        self.merge_log.pack(fill="both", expand=True)
        btn = ttk.Frame(tab)
        btn.pack(fill="x", pady=(8, 10))
        ttk.Button(btn, text="START", width=10, command=self.run_merge).pack(side="left", padx=4, ipady=3)
        ttk.Button(btn, text="STOP", width=10, command=self.stop_merge).pack(side="left", padx=4, ipady=3)

    # ─── searcher ───
    def _build_searcher_tab(self):
        tab = ttk.Frame(self.nb, padding=6)
        self.nb.add(tab, text="  searcher  ")

        r = ttk.Frame(tab)
        r.pack(fill="x", pady=4)
        ttk.Label(r, text="Input:", width=12).pack(side="left")
        self._entry(r, self.searcher_input, 50).pack(side="left", padx=4, fill="x", expand=True)

        info = ttk.Label(
            tab,
            text=f"Command: {searcher.COMMAND_PREFIX} <input>  →  @{searcher.BOT_USERNAME}  →  folder searcher/",
        )
        info.pack(anchor="w", pady=2)

        lf = ttk.LabelFrame(tab, text="Log searcher", padding=3)
        lf.pack(fill="both", expand=True, pady=4)
        self.searcher_log = scrolledtext.ScrolledText(lf, height=14, relief="flat", font=("Consolas", 10))
        self.searcher_log.pack(fill="both", expand=True)

        btn = ttk.Frame(tab)
        btn.pack(fill="x", pady=(8, 10))
        ttk.Button(btn, text="START", width=10, command=self.run_searcher).pack(side="left", padx=4, ipady=3)
        ttk.Button(btn, text="STOP", width=10, command=self.stop_searcher).pack(side="left", padx=4, ipady=3)

    # ─── helpers ───
    def on_domain_only(self):
        self.chk_dupe.pack_forget()
        self.lbl_dupe.pack_forget()
        self.chk_domain.pack_forget()
        self.chk_scheme.pack_forget()
        if self.domain_only.get():
            self.remove_dupe.set(True)
            self.lbl_dupe.pack(side="left", padx=8)
            self.chk_domain.pack(side="left", padx=8)
            self.chk_scheme.pack(side="left", padx=8)
        else:
            self.chk_dupe.pack(side="left", padx=8)
            self.chk_domain.pack(side="left", padx=8)
            self.keep_scheme.set(False)

    def toggle_checker_mode(self):
        mode = self.check_mode.get()

        # Toggle input
        self.single_input.pack_forget()
        self.mass_input.pack_forget()
        if mode == "single":
            self.single_input.pack(fill="both", expand=True)
        else:
            self.mass_input.pack(fill="both", expand=True)

        # Toggle CMS frame
        if mode == "mass_cms":
            if not self.cms_frame.winfo_ismapped():
                self.cms_frame.pack(fill="x", pady=2, before=self.log_frame)
        else:
            self.cms_frame.pack_forget()

    def set_all(self, d, v):
        for x in d.values():
            x.set(v)

    def browse(self):
        p = filedialog.askopenfilename(filetypes=[("Text", "*.txt"), ("All", "*.*")])
        if p:
            self.file_path.set(p)

    def sort_log_msg(self, m):
        self.sort_log.insert("end", m + "\n")
        self.sort_log.see("end")
        self.root.update_idletasks()

    def log(self, m):
        self.log_text.insert("end", m + "\n")
        self.log_text.see("end")
        self.root.update_idletasks()

    def merge_log_msg(self, m):
        self.merge_log.insert("end", m + "\n")
        self.merge_log.see("end")
        self.root.update_idletasks()

    def searchersearcher_log_msg(self, m):
        self.searcher_log.insert("end", m + "\n")
        self.searchersearcher_log.see("end")
        self.root.update_idletasks()

    # merge
    def merge_refresh_preview(self):
        for i in self.merge_tree.get_children():
            self.merge_tree.delete(i)
        rows, total = merge.preview_files(self.merge_paths)
        for r in rows:
            self.merge_tree.insert("", "end", values=(r["name"], r["lines"], r["path"]))
        self.merge_total_lbl.configure(text=f"Total: {len(rows)} file | {total} baris")

    def merge_pick_files(self):
        paths = filedialog.askopenfilenames(filetypes=[("Text", "*.txt"), ("All", "*.*")])
        if not paths:
            return
        exist = set(self.merge_paths)
        for p in paths:
            if p not in exist:
                self.merge_paths.append(p)
                exist.add(p)
        self.merge_refresh_preview()

    def merge_pick_folder(self):
        folder = filedialog.askdirectory()
        if not folder:
            return
        paths = merge.list_txt_in_folder(folder)
        if not paths:
            messagebox.showinfo("Info", "Tidak ada file .txt di folder itu")
            return
        exist = set(self.merge_paths)
        for p in paths:
            if p not in exist:
                self.merge_paths.append(p)
                exist.add(p)
        self.merge_refresh_preview()

    def merge_clear(self):
        self.merge_paths = []
        self.merge_refresh_preview()
        self.merge_log.delete("1.0", "end")

    def run_merge(self):
        if not self.merge_paths:
            messagebox.showerror("Error", "Pilih file / folder dulu")
            return
        self.stop_flag = False
        self.merge_log.delete("1.0", "end")
        self.merge_log_msg("[*] Mulai merge...")

        def task():
            try:
                def prog(cur, total, msg=""):
                    if not self.stop_flag:
                        if cur >= 0 and total > 0:
                            self.merge_log_msg(f"[*] [{cur}/{total}] {msg}")
                        elif msg:
                            self.merge_log_msg(f"[*] {msg}")

                out, written, read, skipped = merge.process_merge(
                    paths=list(self.merge_paths),
                    output_name=self.merge_output.get(),
                    remove_dupe=self.merge_dupe.get(),
                    sort_az=self.merge_sort.get(),
                    skip_empty=self.merge_skip_empty.get(),
                    progress_callback=prog,
                    stop_flag=lambda: self.stop_flag,
                )
                if self.stop_flag or out is None:
                    self.merge_log_msg("[!] Dihentikan")
                    return
                self.merge_log_msg(
                    f"[+] Selesai → {out}\n    Baca: {read} | Tulis: {written} | Skip kosong: {skipped}"
                )
                messagebox.showinfo("Selesai", f"Output: {out}\nBaris tertulis: {written}")
            except Exception as e:
                self.merge_log_msg(f"[!] {e}")
                messagebox.showerror("Error", str(e))

        threading.Thread(target=task, daemon=True).start()

    def stop_merge(self):
        self.stop_flag = True
        self.merge_log_msg("[!] Menghentikan...")

    # searcher
    def run_searcher(self):
        text = self.searcher_input.get().strip()
        if not text:
            messagebox.showerror("Error", "Isi input dulu")
            return
        self.stop_flag = False
        self.searcher_log.delete("1.0", "end")
        self.searcher_log_msg("[*] Mulai searcher check...")

        def task():
            ok = searchersearcher.run_check(
                text,
                log_callback=self.searcher_log_msg,
                stop_flag=lambda: self.stop_flag,
            )
            if self.stop_flag:
                self.searcher_log_msg("[!] Dihentikan")
            elif ok:
                self.searcher_log_msg("[+] Selesai")
            else:
                self.searcher_log_msg("[!] Gagal / belum selesai")

        threading.Thread(target=task, daemon=True).start()

    def stop_searcher(self):
        self.stop_flag = True
        self.searcher_log_msg("[!] Menghentikan...")

    # sorting
    def run_sorting(self):
        if not self.file_path.get():
            messagebox.showerror("Error", "Pilih file dulu")
            return
        self.stop_flag = False
        self.sort_log.delete("1.0", "end")
        self.sort_log_msg("[*] Mulai sorting...")

        def task():
            try:
                st = [t for t, v in self.type_vars.items() if v.get()]
                sc = [c for c, v in self.country_vars.items() if v.get()]

                def prog(d, t):
                    if not self.stop_flag:
                        self.sort_log_msg(f"[*] Progress: {d}/{t}")

                result, skipped, skipped_samples = sorter.process_sorting(
                    input_path=self.file_path.get(),
                    sort_az=self.sort_az.get(),
                    domain_only=self.domain_only.get(),
                    keep_scheme=self.keep_scheme.get(),
                    remove_dupe=self.remove_dupe.get(),
                    selected_types=st,
                    selected_countries=sc,
                    progress_callback=prog,
                    stop_flag=lambda: self.stop_flag,
                )
                if self.stop_flag:
                    self.sort_log_msg("[!] Dihentikan")
                    return
                sorter.ensure_dir()
                base = self.output_name.get().strip() or "hasil"
                out = sorter.SORTER_DIR / (base + ".txt")
                if out.exists():
                    n = 1
                    while True:
                        bak = sorter.SORTER_DIR / f"{base}_old_{n}.txt"
                        if not bak.exists():
                            out.rename(bak)
                            self.sort_log_msg(f"[*] Backup: {out.name} → {bak.name}")
                            break
                        n += 1
                with open(out, "w", encoding="utf-8") as f:
                    f.write("\n".join(result) + ("\n" if result else ""))
                self.sort_log_msg(f"[+] Output : {len(result)} → {out}")
                messagebox.showinfo("Selesai", f"Output: {len(result)}\nFile: {out}")
            except Exception as e:
                self.sort_log_msg(f"[!] {e}")
                messagebox.showerror("Error", str(e))

        threading.Thread(target=task, daemon=True).start()

    def stop_sorting(self):
        self.stop_flag = True
        self.sort_log_msg("[!] Menghentikan...")

    # checker
    def start_checker(self):
        self.stop_flag = False
        self.log_text.delete("1.0", "end")

        mode = self.check_mode.get()

        if mode == "single":
            url = self.single_url.get().strip()
            if not url:
                messagebox.showerror("Error", "Masukkan URL")
                return
            checker.check_single(url, log_callback=self.log)
            return

        if not self.file_path.get():
            messagebox.showerror("Error", "Pilih file dulu")
            return

        # mass_alive atau mass_cms
        run_mode = "alive" if mode == "mass_alive" else "cms"
        cms_list = [n for n, v in self.cms_vars.items() if v.get()] if mode == "mass_cms" else None

        self.log(f"[*] Mode: {run_mode}")

        def task():
            try:
                def prog(d, t):
                    if not self.stop_flag and (d % 25 == 0 or d == t):
                        self.log(f"[*] Progress: {d}/{t}")
                checker.start_or_resume(
                    self.file_path.get(),
                    mode=run_mode,
                    cms_list=cms_list,
                    progress_callback=prog,
                    log_callback=self.log,
                    stop_flag=lambda: self.stop_flag,
                )
                if self.stop_flag:
                    self.log("[!] Dihentikan — progress tersimpan")
            except Exception as e:
                self.log(f"[!] {e}")

        threading.Thread(target=task, daemon=True).start()

    def stop_checker(self):
        self.stop_flag = True
        self.log("[!] Menghentikan...")


if __name__ == "__main__":
    root = tk.Tk()
    App(root)
    root.mainloop()
