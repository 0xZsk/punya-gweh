# searcher.py
import asyncio
import re
import zipfile
from pathlib import Path

try:
    from telethon import TelegramClient
except ImportError:
    TelegramClient = None

# ========== CONFIG — edit di sini ==========
API_ID = 31699530                         
API_HASH = "9bd1923825f3745504c0d9fa50cacd87"                
SESSION_NAME = "sessions/my_account"       
BOT_USERNAME = "TTMlogsBot"                 
OUTPUT_DIR = Path("searcher")
COMMAND_PREFIX = "/search"
WAIT_BUTTON_SEC = 60
WAIT_FILE_SEC = 120
# ==========================================

# Teks yang dianggap "tidak ada hasil"
NO_RESULT_TEXTS = [
    "❌ no strings available",
    "no strings available",
]


def ensure_dirs():
    OUTPUT_DIR.mkdir(exist_ok=True)
    Path(SESSION_NAME).parent.mkdir(parents=True, exist_ok=True)


def _safe_name(name: str) -> str:
    name = (name or "download.bin").strip() or "download.bin"
    return re.sub(r'[<>:"/\\|?*]', "_", name)


def _is_no_result(text: str) -> bool:
    if not text:
        return False
    t = text.lower().strip()
    for keyword in NO_RESULT_TEXTS:
        if keyword.lower() in t:
            return True
    return False


def _already_exists(user_input: str) -> list[Path]:
    """Cek apakah di searcher/ sudah ada file yang mengandung input."""
    if not user_input:
        return []
    key = user_input.strip().lower()
    found = []
    if not OUTPUT_DIR.exists():
        return found
    for p in OUTPUT_DIR.iterdir():
        if not p.is_file():
            continue
        name = p.name.lower()
        if key in name:
            found.append(p)
    return found


def _handle_zip(zip_path: Path, log):
    """
    Ekstrak isi ZIP langsung ke searcher/ (tanpa subfolder), lalu hapus ZIP.
    Nama file di dalam ZIP tetap dipertahankan.
    """
    if not zipfile.is_zipfile(zip_path):
        log(f"[!] Bukan ZIP valid: {zip_path.name}")
        return

    try:
        with zipfile.ZipFile(zip_path, "r") as zf:
            zf.extractall(OUTPUT_DIR)
            log(f"[+] Unzip → searcher/ ({len(zf.namelist())} file)")
        zip_path.unlink()
        log(f"[*] Hapus ZIP: {zip_path.name}")
    except Exception as e:
        log(f"[!] Gagal unzip: {e}")


async def _run_async(user_input: str, log, stop_flag):
    if TelegramClient is None:
        log("[!] pip install telethon")
        return False

    ensure_dirs()
    user_input = (user_input or "").strip()
    if not user_input:
        log("[!] Input kosong")
        return False

    # --- CEK LOKAL DULU ---
    existing = _already_exists(user_input)
    if existing:
        log(f"[*] Sudah ada di searcher/ (skip request):")
        for p in existing:
            log(f"    - {p.name}")
        return True

    client = TelegramClient(SESSION_NAME, API_ID, API_HASH)
    await client.connect()

    if not await client.is_user_authorized():
        log("[!] Session belum login.")
        log("[*] Jalankan sekali: python searcher.py --login")
        await client.disconnect()
        return False

    try:
        bot = await client.get_entity(BOT_USERNAME)
    except Exception as e:
        log(f"[!] Bot tidak ditemukan: {e}")
        await client.disconnect()
        return False

    cmd = f"{COMMAND_PREFIX} {user_input}".strip()
    log(f"[*] Kirim ke @{BOT_USERNAME}: {cmd}")
    await client.send_message(bot, cmd)

    if stop_flag and stop_flag():
        await client.disconnect()
        return False

    # --- tunggu pesan yang punya tombol inline ---
    log("[*] Tunggu domain:user:pass...")
    button_msg = None
    deadline = asyncio.get_event_loop().time() + WAIT_BUTTON_SEC

    while asyncio.get_event_loop().time() < deadline:
        if stop_flag and stop_flag():
            await client.disconnect()
            return False
        msgs = await client.get_messages(bot, limit=5)
        for m in msgs:
            if m.out:
                continue
            if m.buttons:
                button_msg = m
                break
        if button_msg:
            break
        await asyncio.sleep(1.0)

    if not button_msg:
        log("[!] Timeout: gaada buttonnya jir keknya lagi mati botnya wkwkwk")
        await client.disconnect()
        return False

    # klik kiri = index 0
    try:
        log("[*] Okehh dapet nih...")
        await button_msg.click(0)
    except Exception as e:
        log(f"[!] Gabisa di clock jir: {e}")
        await client.disconnect()
        return False

    if stop_flag and stop_flag():
        await client.disconnect()
        return False

    # --- tunggu file ATAU pesan "no result" ---
    log("[*] Sabar ya nuggu file sama donlot...")
    min_id = button_msg.id
    file_msg = None
    deadline = asyncio.get_event_loop().time() + WAIT_FILE_SEC

    while asyncio.get_event_loop().time() < deadline:
        if stop_flag and stop_flag():
            await client.disconnect()
            return False

        msgs = await client.get_messages(bot, limit=8)
        for m in msgs:
            if m.out or m.id <= min_id:
                continue

            # Cek teks "no strings available"
            if m.text and _is_no_result(m.text):
                log(f"[!] Bot: {m.text.strip()}")
                log("[!] Gaada file (no strings available)")
                await client.disconnect()
                return False

            # Cek file
            if m.document or (m.file and m.file.name):
                file_msg = m
                break

        if file_msg:
            break
        await asyncio.sleep(1.0)

    if not file_msg:
        log("[!] Timeout: pelit botnya ga ngasih file")
        await client.disconnect()
        return False

    # nama file dari bot
    fname = None
    if file_msg.file and file_msg.file.name:
        fname = file_msg.file.name
    elif file_msg.document:
        for attr in file_msg.document.attributes:
            if hasattr(attr, "file_name") and attr.file_name:
                fname = attr.file_name
                break
    fname = _safe_name(fname or f"file_{file_msg.id}.bin")
    dest = OUTPUT_DIR / fname

    log(f"[*] Download → {dest}")
    saved = await client.download_media(file_msg, file=str(dest))
    if not saved:
        log("[!] Download gagal")
        await client.disconnect()
        return False

    saved_path = Path(saved)
    log(f"[+] Tersimpan: {saved_path.name}")

    # Kalau ZIP → ekstrak langsung ke searcher/, hapus ZIP
    if saved_path.suffix.lower() == ".zip":
        _handle_zip(saved_path, log)

    await client.disconnect()
    return True


def run_check(user_input: str, log_callback=None, stop_flag=None):
    """Dipanggil dari GUI (thread biasa)."""

    def log(m):
        if log_callback:
            log_callback(m)
        else:
            print(m)

    try:
        return asyncio.run(_run_async(user_input, log, stop_flag))
    except Exception as e:
        log(f"[!] {e}")
        return False


def login_interactive():
    """python searcher.py --login"""
    if TelegramClient is None:
        print("pip install telethon")
        return
    ensure_dirs()
    client = TelegramClient(SESSION_NAME, API_ID, API_HASH)
    client.start()
    print("[+] Login OK — session tersimpan:", SESSION_NAME + ".session")
    client.disconnect()


if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1 and sys.argv[1] == "--login":
        login_interactive()
    else:
        print("Edit CONFIG di searcher.py dulu.")
        print("Login:  python searcher.py --login")
        print("Atau pakai tab Searcher di main.py")
