# merge.py
from pathlib import Path

MERGE_DIR = Path("merge")


def ensure_dir():
    MERGE_DIR.mkdir(exist_ok=True)


def list_txt_in_folder(folder: str):
    """Ambil semua .txt di folder (non-recursive)."""
    p = Path(folder)
    if not p.is_dir():
        return []
    return sorted(str(f) for f in p.iterdir() if f.is_file() and f.suffix.lower() == ".txt")


def count_lines(path: str) -> int:
    n = 0
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        for _ in f:
            n += 1
    return n


def preview_files(paths):
    """
    Return list of dict: {path, name, lines}
    + total lines
    """
    rows = []
    total = 0
    for p in paths:
        try:
            n = count_lines(p)
        except Exception:
            n = 0
        rows.append({"path": p, "name": Path(p).name, "lines": n})
        total += n
    return rows, total


def _backup_if_exists(out: Path):
    """hasil.txt → hasil_old_1.txt, hasil_old_2.txt, ..."""
    if not out.exists():
        return None
    base = out.stem
    parent = out.parent
    n = 1
    while True:
        bak = parent / f"{base}_old_{n}{out.suffix}"
        if not bak.exists():
            out.rename(bak)
            return bak
        n += 1


def process_merge(
    paths,
    output_name="merged",
    remove_dupe=True,
    sort_az=False,
    skip_empty=True,
    progress_callback=None,
    stop_flag=None,
):
    """
    Gabung banyak file txt jadi satu.
    Return: (output_path, total_written, total_read, skipped_empty)
    """
    ensure_dir()
    paths = [p for p in (paths or []) if p]
    if not paths:
        raise ValueError("Tidak ada file untuk di-merge")

    base = (output_name or "merged").strip() or "merged"
    if not base.endswith(".txt"):
        out = MERGE_DIR / f"{base}.txt"
    else:
        out = MERGE_DIR / base

    bak = _backup_if_exists(out)
    if bak and progress_callback:
        progress_callback(-1, -1, f"Backup: {out.name} → {bak.name}")

    seen = set()
    result = []
    total_read = 0
    skipped_empty = 0
    total_files = len(paths)

    for fi, path in enumerate(paths):
        if stop_flag and stop_flag():
            break
        try:
            with open(path, "r", encoding="utf-8", errors="ignore") as f:
                for line in f:
                    if stop_flag and stop_flag():
                        break
                    total_read += 1
                    line = line.rstrip("\n\r")
                    if skip_empty and not line.strip():
                        skipped_empty += 1
                        continue
                    key = line
                    if remove_dupe:
                        if key in seen:
                            continue
                        seen.add(key)
                    result.append(line)
        except Exception as e:
            if progress_callback:
                progress_callback(fi + 1, total_files, f"Skip file error: {Path(path).name} ({e})")
            continue

        if progress_callback:
            progress_callback(fi + 1, total_files, f"Done: {Path(path).name}")

    if stop_flag and stop_flag():
        return None, 0, total_read, skipped_empty

    if sort_az:
        result.sort(key=str.lower)

    with open(out, "w", encoding="utf-8") as f:
        f.write("\n".join(result) + ("\n" if result else ""))

    return str(out), len(result), total_read, skipped_empty
