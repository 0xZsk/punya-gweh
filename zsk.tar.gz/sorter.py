# sorter.py
import re
import heapq
import tempfile
import shutil
from pathlib import Path

COUNTRY_TLDS = [
    "ac","ad","ae","af","ag","ai","al","am","ao","aq","ar","as","at","au","aw","ax","az",
    "ba","bb","bd","be","bf","bg","bh","bi","bj","bm","bn","bo","br","bs","bt","bv","bw","by","bz",
    "ca","cc","cd","cf","cg","ch","ci","ck","cl","cm","cn","co","cr","cu","cv","cw","cx","cy","cz",
    "de","dj","dk","dm","do","dz","ec","ee","eg","eh","er","es","et","eu",
    "fi","fj","fk","fm","fo","fr","ga","gb","gd","ge","gf","gg","gh","gi","gl","gm","gn","gp","gq","gr","gs","gt","gu","gw","gy",
    "hk","hm","hn","hr","ht","hu","id","ie","il","im","in","io","iq","ir","is","it",
    "je","jm","jo","jp","ke","kg","kh","ki","km","kn","kp","kr","kw","ky","kz",
    "la","lb","lc","li","lk","lr","ls","lt","lu","lv","ly",
    "ma","mc","md","me","mg","mh","mk","ml","mm","mn","mo","mp","mq","mr","ms","mt","mu","mv","mw","mx","my","mz",
    "na","nc","ne","nf","ng","ni","nl","no","np","nr","nu","nz","om",
    "pa","pe","pf","pg","ph","pk","pl","pm","pn","pr","ps","pt","pw","py","qa",
    "re","ro","rs","ru","rw","sa","sb","sc","sd","se","sg","sh","si","sj","sk","sl","sm","sn","so","sr","ss","st","su","sv","sx","sy","sz",
    "tc","td","tf","tg","th","tj","tk","tl","tm","tn","to","tr","tt","tv","tw","tz",
    "ua","ug","uk","us","uy","uz","va","vc","ve","vg","vi","vn","vu","wf","ws","ye","yt","za","zm","zw"
]

# Urut: paling berguna di atas
DOMAIN_PATTERNS = {
    "GOV":  [r"(^|\.)gov(\.|$)"],
    "GOB":  [r"(^|\.)gob(\.|$)"],
    "GO":   [r"(^|\.)go(\.|$)"],
    "GOUV": [r"(^|\.)gouv(\.|$)"],
    "GV":   [r"(^|\.)gv(\.|$)"],
    "EDU":  [r"(^|\.)edu(\.|$)"],
    "AC":   [r"(^|\.)ac(\.|$)"],
    "SCH":  [r"(^|\.)sch(\.|$)"],
    "MIL":  [r"(^|\.)mil(\.|$)"],
    "COM":  [r"(^|\.)com(\.|$)"],
    "CO":   [r"(^|\.)co(\.|$)"],
    "ORG":  [r"(^|\.)org(\.|$)"],
    "OR":   [r"(^|\.)or(\.|$)"],
    "NET":  [r"(^|\.)net(\.|$)"],
    "NIC":  [r"(^|\.)nic(\.|$)"],
    "GOVT": [r"(^|\.)govt(\.|$)"],
    "INFO": [r"(^|\.)info(\.|$)"],
    "BIZ":  [r"(^|\.)biz(\.|$)"],
    "MY":   [r"(^|\.)my(\.|$)"],
    "WEB":  [r"(^|\.)web(\.|$)"],
    "NAME": [r"(^|\.)name(\.|$)"],
    "INT":  [r"(^|\.)int(\.|$)"],
    "IO":   [r"(^|\.)io(\.|$)"],
    "AI":   [r"(^|\.)ai(\.|$)"],
    "APP":  [r"(^|\.)app(\.|$)"],
    "DEV":  [r"(^|\.)dev(\.|$)"],
    "RES":  [r"(^|\.)res(\.|$)"],
    "ASN":  [r"(^|\.)asn(\.|$)"],
}

SORTER_DIR = Path("sorter")
CHUNK_SIZE = 50_000
CHUNK_THRESHOLD = 1_000_000


def ensure_dir():
    SORTER_DIR.mkdir(exist_ok=True)


def extract_domain(text: str):
    text = (text or "").strip()
    if not text:
        return None
    if "@" in text:
        text = text.rsplit("@", 1)[-1]
    text = re.sub(r"^https?://", "", text, flags=re.I)
    text = text.split("/")[0].split("?")[0].split("#")[0]
    text = text.split(":")[0]
    text = text.strip().lower().strip(".")
    if not text:
        return None
    if re.match(r"^[a-z0-9]([a-z0-9\-\.]*[a-z0-9])?$", text) and "." in text:
        return text
    m = re.search(r"([a-z0-9]([a-z0-9\-\.]*\.)+[a-z]{2,})", text)
    return m.group(1).lower() if m else None


def detect_scheme(line: str):
    line = line.strip().lower()
    if line.startswith("https://"):
        return "https"
    if line.startswith("http://"):
        return "http"
    return None


def parse_line(line: str, domain_only: bool = False, keep_scheme: bool = False):
    line = line.strip()
    if not line:
        return None
    scheme = detect_scheme(line)

    if domain_only:
        domain = None
        if line.count(":") >= 2:
            parts = line.split(":")
            if len(parts) >= 4 and parts[0].lower() in ("http", "https") and parts[1].startswith("//"):
                raw = parts[0] + ":" + ":".join(parts[1:-2])
            else:
                raw = ":".join(parts[:-2])
            domain = extract_domain(raw)
        if not domain:
            domain = extract_domain(line)
        if not domain:
            return None
        if keep_scheme and scheme:
            original = f"{scheme}://{domain}"
        else:
            original = domain
        return {"original": original, "domain": domain, "scheme": scheme}

    if line.count(":") >= 2:
        parts = line.split(":")
        if len(parts) >= 3:
            if len(parts) >= 4 and parts[0].lower() in ("http", "https") and parts[1].startswith("//"):
                raw = parts[0] + ":" + ":".join(parts[1:-2])
            else:
                raw = ":".join(parts[:-2])
            domain = extract_domain(raw)
            if domain:
                return {"original": line, "domain": domain, "scheme": scheme}

    domain = extract_domain(line)
    if domain:
        return {"original": line, "domain": domain, "scheme": scheme}
    return None


def match_type(domain, selected, original=None):
    if not selected:
        return True
    for t in selected:
        for pat in DOMAIN_PATTERNS.get(t, []):
            if re.search(pat, domain, re.I):
                return True
    return False


def match_country(domain, selected, selected_types=None):
    selected_types = selected_types or []
    if not selected or len(selected) >= len(COUNTRY_TLDS) - 5:
        return True
    strict = len(selected_types) == 0
    for c in selected:
        c = c.lower()
        if strict:
            if domain.count(".") == 1 and domain.endswith("." + c):
                return True
            if domain == c:
                return True
        else:
            if domain == c or domain.endswith("." + c):
                return True
    return False


def _filter_line(line, domain_only, keep_scheme, selected_types, selected_countries):
    p = parse_line(line, domain_only=domain_only, keep_scheme=keep_scheme)
    if not p:
        return None, "parse_fail"
    if not match_type(p["domain"], selected_types, original=p["original"]):
        return None, "type_fail"
    if not match_country(p["domain"], selected_countries, selected_types=selected_types):
        return None, "country_fail"
    return p, None


def count_lines_quick(path):
    n = 0
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        for _ in f:
            n += 1
    return n


def process_sorting(
    lines=None,
    input_path=None,
    sort_az=True,
    domain_only=False,
    keep_scheme=False,
    remove_dupe=True,
    selected_types=None,
    selected_countries=None,
    progress_callback=None,
    stop_flag=None,
):
    selected_types = selected_types or []
    selected_countries = selected_countries or []
    if domain_only:
        remove_dupe = True

    if input_path:
        total = count_lines_quick(input_path)
        use_chunk = total >= CHUNK_THRESHOLD
    else:
        total = len(lines or [])
        use_chunk = False

    if progress_callback:
        progress_callback(0, total)

    if use_chunk and input_path:
        return _process_chunked(
            input_path, total, sort_az, domain_only, keep_scheme, remove_dupe,
            selected_types, selected_countries, progress_callback, stop_flag,
        )

    if input_path and lines is None:
        with open(input_path, "r", encoding="utf-8", errors="ignore") as f:
            lines = [l.strip() for l in f if l.strip()]
        total = len(lines)

    items = []
    skipped_count = 0
    skipped_samples = []

    for i, line in enumerate(lines or []):
        if stop_flag and stop_flag():
            break
        p, reason = _filter_line(line, domain_only, keep_scheme, selected_types, selected_countries)
        if p is None:
            skipped_count += 1
            if len(skipped_samples) < 200:
                skipped_samples.append(f"{reason}\t{line}")
            continue
        items.append(p)
        if progress_callback and i % 20000 == 0:
            progress_callback(i, total)

    if stop_flag and stop_flag():
        return [], skipped_count, skipped_samples

    result = _finalize(items, domain_only, keep_scheme, remove_dupe, sort_az)
    if progress_callback:
        progress_callback(total, total)
    return result, skipped_count, skipped_samples


def _scheme_rank(scheme):
    if scheme == "https":
        return 2
    if scheme == "http":
        return 1
    return 0


def _finalize(items, domain_only, keep_scheme, remove_dupe, sort_az):
    if domain_only:
        best = {}
        for it in items:
            d = it["domain"]
            if d not in best or _scheme_rank(it.get("scheme")) > _scheme_rank(best[d].get("scheme")):
                best[d] = it
        result = [best[d]["original"] for d in best]
        if sort_az:
            result.sort(key=str.lower)
        return result

    if remove_dupe:
        seen = set()
        unique = []
        for it in items:
            if it["original"] not in seen:
                seen.add(it["original"])
                unique.append(it)
        items = unique

    if sort_az:
        items.sort(key=lambda x: x["domain"].lower())
    return [it["original"] for it in items]


def _process_chunked(
    input_path, total, sort_az, domain_only, keep_scheme, remove_dupe,
    selected_types, selected_countries, progress_callback, stop_flag,
):
    tmp_dir = Path(tempfile.mkdtemp(prefix="sorter_chunks_"))
    chunk_files = []
    skipped_count = 0
    skipped_samples = []
    processed = 0
    chunk_idx = 0
    buf = []

    def flush_chunk(buf, idx):
        nonlocal skipped_count
        if not buf:
            return None
        items = []
        for line in buf:
            p, reason = _filter_line(line, domain_only, keep_scheme, selected_types, selected_countries)
            if p is None:
                skipped_count += 1
                if len(skipped_samples) < 200:
                    skipped_samples.append(f"{reason}\t{line}")
                continue
            items.append(p)
        finalized = _finalize(items, domain_only, keep_scheme, remove_dupe, sort_az=True)
        if not finalized:
            return None
        path = tmp_dir / f"chunk_{idx:05d}.txt"
        path.write_text("\n".join(finalized) + "\n", encoding="utf-8")
        return path

    try:
        with open(input_path, "r", encoding="utf-8", errors="ignore") as f:
            for line in f:
                if stop_flag and stop_flag():
                    break
                line = line.strip()
                if not line:
                    continue
                buf.append(line)
                processed += 1
                if len(buf) >= CHUNK_SIZE:
                    p = flush_chunk(buf, chunk_idx)
                    if p:
                        chunk_files.append(p)
                    buf = []
                    chunk_idx += 1
                    if progress_callback:
                        progress_callback(processed, total)
            if buf and not (stop_flag and stop_flag()):
                p = flush_chunk(buf, chunk_idx)
                if p:
                    chunk_files.append(p)

        if stop_flag and stop_flag():
            return [], skipped_count, skipped_samples
        if not chunk_files:
            return [], skipped_count, skipped_samples
        if len(chunk_files) == 1:
            result = chunk_files[0].read_text(encoding="utf-8").splitlines()
        else:
            result = _merge_sorted_files(chunk_files, remove_dupe=remove_dupe or domain_only)
        if progress_callback:
            progress_callback(total, total)
        return result, skipped_count, skipped_samples
    finally:
        shutil.rmtree(tmp_dir, ignore_errors=True)


def _merge_sorted_files(paths, remove_dupe=True):
    files = [open(p, "r", encoding="utf-8", errors="ignore") for p in paths]
    try:
        iters = []
        for f in files:
            def gen(fh):
                for line in fh:
                    line = line.strip()
                    if line:
                        yield line
            iters.append(gen(f))
        merged = heapq.merge(*iters, key=str.lower)
        result, seen = [], set()
        for line in merged:
            if remove_dupe:
                if line in seen:
                    continue
                seen.add(line)
            result.append(line)
        return result
    finally:
        for f in files:
            try:
                f.close()
            except Exception:
                pass
