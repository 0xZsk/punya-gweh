import re
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

try:
    import requests
except ImportError:
    requests = None

CHECKER_DIR = Path("checker")
RESULT_DIR = CHECKER_DIR / "hasil"

# Progress Alive
PROGRESS_DO = CHECKER_DIR / "progress_domain_only.txt"
PROGRESS_WC = CHECKER_DIR / "progress_with_creds.txt"

# Progress CMS
PROGRESS_CMS_DO = CHECKER_DIR / "progress_cms_domain_only.txt"
PROGRESS_CMS_WC = CHECKER_DIR / "progress_cms_with_creds.txt"

# Hasil
ALIVE_DO = RESULT_DIR / "alive" / "domain_only.txt"
ALIVE_WC = RESULT_DIR / "alive" / "with_creds.txt"
FAILED_FILE = CHECKER_DIR / "failed.txt"
CHECKED_DOMAINS = CHECKER_DIR / "checked_domains.txt"
CHECKED_CMS = CHECKER_DIR / "checked_cms.txt"

MAX_WORKERS = 250
TIMEOUT = 12
UA = "Mozilla/5.0 (compatible; WordlistTools/1.0)"

# ==================== CMS SIGNATURES ====================
CMS_SIGS = {
    "WordPress": {
        "khas": [r"/wp-content/", r"/wp-includes/", r"/wp-json/", r"wordpress_logged_in", r"wp-settings"],
        "semi": [],
        "umum": [r"/admin/"]
    },
    "Drupal": {
        "khas": [r"x-generator:\s*drupal", r"x-drupal-cache", r"/core/misc/drupal\.js", r"drupalsettings", r"/sites/default/files/"],
        "semi": [],
        "umum": [r"/admin/"]
    },
    "Moodle": {
        "khas": [r"moodlesession", r"/lib/upgrade\.txt"],
        "semi": [r"\?sesskey="],
        "umum": [r"/admin/"]
    },
    "phpBB": {
        "khas": [r"phpbb3_", r'<body[^>]*id=["\']phpbb["\']'],
        "semi": [],
        "umum": [r"forum"]
    },
    "PKP_OJS": {
        "khas": [r"/lib/pkp/", r"open journal systems"],
        "semi": [r"/plugins/"],
        "umum": [r"journal"]
    },
    "phpMyAdmin": {
        "khas": [r"pma_username", r"<title[^>]*>phpmyadmin"],
        "semi": [],
        "umum": [r"login"]
    },
    "cPanel": {
        "khas": [r"x-cpanel-version"],
        "semi": [r"/cpsess"],
        "umum": []
    },
    "WHM": {
        "khas": [r"/whm"],
        "semi": [r"/cpsess"],
        "umum": []
    },
    "Laravel": {
        "khas": [r"laravel_session", r"/vendor/laravel/"],
        "semi": [r"/vendor/"],
        "umum": [r"x-powered-by"]
    },
    "CodeIgniter": {
        "khas": [r"ci_session"],
        "semi": [r"/system/"],
        "umum": [r"phpsessid"]
    },
    "Yii": {
        "khas": [r"yii\.js", r"yii\.activeform\.js", r"yii\.validation\.js", r"_csrf", r"yii_csrf_token", r"/assets/yii/"],
        "semi": [],
        "umum": [r"/assets/"]
    },
    "Joomla": {
        "khas": [r'content=["\']joomla!', r"/media/system/js/"],
        "semi": [r"/administrator/"],
        "umum": [r"/admin/"]
    },
    "Django": {
        "khas": [r"csrftoken", r"csrfmiddlewaretoken"],
        "semi": [],
        "umum": []
    }
}

DETECT_ORDER = list(CMS_SIGS.keys())

_executor = None
EMAIL_DOMAINS = {"gmail.com", "yahoo.com", "ymail.com", "hotmail.com", "outlook.com", "mail.com"}


def ensure_dirs():
    CHECKER_DIR.mkdir(exist_ok=True)
    RESULT_DIR.mkdir(exist_ok=True)
    (RESULT_DIR / "alive").mkdir(exist_ok=True)
    for name in list(CMS_SIGS.keys()) + ["RandomCMS"]:
        (RESULT_DIR / name).mkdir(exist_ok=True)


def extract_domain(text: str):
    if not text:
        return None
    text = text.strip()
    text = re.sub(r"^https?://", "", text, flags=re.I)
    host_part = text.split("/")[0]
    host_part = host_part.split(":")[0]
    host_part = host_part.strip().lower().strip(".")
    if not host_part or "." not in host_part:
        return None
    if host_part in EMAIL_DOMAINS:
        return None
    return host_part


def parse_line(line: str):
    line = (line or "").strip()
    if not line or line.startswith("#"):
        return None

    # https://domain or http://domain (tanpa user:pass) = domain_only
    if line.lower().startswith(("http://", "https://")):
        rest = line.split("://", 1)[1]
        # Cek apakah ada user:pass setelah domain
        # Format: https://domain:user:pass atau https://domain/path
        if "/" in rest:
            # Ada path, cek apakah ada : sebelum path
            host_part = rest.split("/")[0]
            if host_part.count(":") >= 2:
                # https://domain:user:pass/path
                domain = extract_domain(host_part.split(":")[0])
                if domain:
                    return {"kind": "with_creds", "domain": domain, "original": line}
            else:
                # https://domain/path = domain_only
                domain = extract_domain(host_part)
                if domain:
                    return {"kind": "domain_only", "domain": domain, "original": domain}
        else:
            # Nggak ada path
            if rest.count(":") >= 2:
                # https://domain:user:pass
                domain = extract_domain(rest.split(":")[0])
                if domain:
                    return {"kind": "with_creds", "domain": domain, "original": line}
            else:
                # https://domain = domain_only
                domain = extract_domain(rest)
                if domain:
                    return {"kind": "domain_only", "domain": domain, "original": domain}
        return None

    # Format: domain:user:pass
    if ":" in line:
        parts = line.split(":")
        if len(parts) >= 3:
            domain = extract_domain(parts[0])
            if domain:
                return {"kind": "with_creds", "domain": domain, "original": line}

    # Domain only
    domain = extract_domain(line)
    if domain:
        return {"kind": "domain_only", "domain": domain, "original": domain}
    return None


def _load_lines(path: Path):
    if not path.exists():
        return []
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        return [l.strip() for l in f if l.strip()]


def _save_lines(path: Path, lines):
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + ("\n" if lines else ""))


def _append_line(path: Path, line: str):
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "a", encoding="utf-8") as f:
        f.write(line + "\n")


def _load_set(path: Path):
    s = set()
    if path.exists():
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            for line in f:
                d = line.strip().lower()
                if d:
                    s.add(d)
    return s


def _load_cms_map():
    m = {}
    if CHECKED_CMS.exists():
        with open(CHECKED_CMS, "r", encoding="utf-8", errors="ignore") as f:
            for line in f:
                line = line.strip()
                if "|" in line:
                    dom, cms = line.split("|", 1)
                    m[dom.lower()] = cms
    return m


def _mark_cms(domain: str, cms: str):
    _append_line(CHECKED_CMS, f"{domain.lower()}|{cms}")


# ==================== DETEKSI CMS ====================
def detect_cms(headers: dict, body: str):
    text = "\n".join(f"{k}: {v}" for k, v in (headers or {}).items()) + " " + (body or "")[:200000]
    text = text.lower()

    for cms, sigs in CMS_SIGS.items():
        # 1. Khas
        for pattern in sigs["khas"]:
            if re.search(pattern, text, re.IGNORECASE):
                return cms

        # 2. Semi
        semi_hits = sum(1 for p in sigs["semi"] if re.search(p, text, re.IGNORECASE))
        if semi_hits >= 2:
            return cms

        # 3. Umum
        umum_hits = sum(1 for p in sigs["umum"] if re.search(p, text, re.IGNORECASE))
        if umum_hits >= 2:
            return cms

    return "RandomCMS"


def _request(url: str):
    if requests is None:
        raise RuntimeError("pip install requests")
    return requests.get(url, timeout=TIMEOUT, allow_redirects=True,
                        headers={"User-Agent": UA}, verify=False)


def check_alive(domain: str):
    for scheme in ("https", "http"):
        try:
            r = _request(f"{scheme}://{domain}")
            if 200 <= r.status_code < 400:
                return True, r
        except Exception:
            continue
    return False, None


def stop_checker():
    global _executor
    if _executor:
        try:
            _executor.shutdown(wait=False, cancel_futures=True)
        except Exception:
            pass
        _executor = None


def get_progress_counts(mode="alive"):
    if mode == "alive":
        a = len(_load_lines(PROGRESS_DO))
        b = len(_load_lines(PROGRESS_WC))
    else:
        a = len(_load_lines(PROGRESS_CMS_DO))
        b = len(_load_lines(PROGRESS_CMS_WC))
    return a, b


def get_progress_count(mode="alive"):
    a, b = get_progress_counts(mode)
    return a + b


def analyze_file(input_path: str):
    """Cek isi file: domain_only, with_creds, atau mixed"""
    do_count = 0
    wc_count = 0
    with open(input_path, "r", encoding="utf-8", errors="ignore") as f:
        for line in f:
            p = parse_line(line)
            if not p:
                continue
            if p["kind"] == "domain_only":
                do_count += 1
            else:
                wc_count += 1

    if do_count > 0 and wc_count > 0:
        return "mixed", do_count, wc_count
    elif do_count > 0:
        return "domain_only", do_count, 0
    elif wc_count > 0:
        return "with_creds", 0, wc_count
    else:
        return "empty", 0, 0


def split_and_save(input_path: str, mode="alive", append=False):
    ensure_dirs()
    do_lines, wc_lines = [], []
    with open(input_path, "r", encoding="utf-8", errors="ignore") as f:
        for line in f:
            p = parse_line(line)
            if not p:
                continue
            if p["kind"] == "domain_only":
                do_lines.append(p["domain"])
            else:
                wc_lines.append(p["original"])

    if mode == "alive":
        pdo, pwc = PROGRESS_DO, PROGRESS_WC
    else:
        pdo, pwc = PROGRESS_CMS_DO, PROGRESS_CMS_WC

    if append:
        existing_do = set(_load_lines(pdo))
        existing_wc = set(_load_lines(pwc))
        do_lines = [x for x in do_lines if x not in existing_do]
        wc_lines = [x for x in wc_lines if x not in existing_wc]
        if do_lines:
            with open(pdo, "a", encoding="utf-8") as f:
                f.write("\n".join(do_lines) + "\n")
        if wc_lines:
            with open(pwc, "a", encoding="utf-8") as f:
                f.write("\n".join(wc_lines) + "\n")
    else:
        _save_lines(pdo, do_lines)
        _save_lines(pwc, wc_lines)
    return len(do_lines), len(wc_lines)


def start_or_resume(
    input_path: str,
    mode: str = "alive",
    cms_list: list = None,
    progress_callback=None,
    log_callback=None,
    stop_flag=None,
    start_with: str = "domain_only",
):
    global _executor

    def log(m):
        if log_callback:
            log_callback(m)

    ensure_dirs()
    if requests is None:
        log("[!] pip install requests")
        return

    cms_list = cms_list or DETECT_ORDER

    if mode == "alive":
        pdo, pwc = PROGRESS_DO, PROGRESS_WC
    else:
        pdo, pwc = PROGRESS_CMS_DO, PROGRESS_CMS_WC

    do_lines = _load_lines(pdo)
    wc_lines = _load_lines(pwc)

    if not do_lines and not wc_lines:
        split_and_save(input_path, mode=mode, append=False)
        do_lines = _load_lines(pdo)
        wc_lines = _load_lines(pwc)

    checked_domains = _load_set(CHECKED_DOMAINS)
    failed_set = _load_set(FAILED_FILE)
    cms_map = _load_cms_map() if mode == "cms" else {}

    # Load existing results for dedup
    alive_do_set = _load_set(ALIVE_DO)
    alive_wc_set = set(_load_lines(ALIVE_WC))

    total = len(do_lines) + len(wc_lines)
    done = 0
    log(f"[*] Mode: {mode} | Antrian: {total} | Workers: {MAX_WORKERS}")

    try:
        import urllib3
        urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
    except Exception:
        pass

    queues = []
    if start_with == "domain_only":
        if do_lines:
            queues.append(("domain_only", do_lines, pdo))
        if wc_lines:
            queues.append(("with_creds", wc_lines, pwc))
    else:
        if wc_lines:
            queues.append(("with_creds", wc_lines, pwc))
        if do_lines:
            queues.append(("domain_only", do_lines, pdo))

    stopped = False
    for kind, queue, progress_file in queues:
        remaining = list(queue)

        def worker(item):
            p = parse_line(item) if kind == "with_creds" else {"domain": item, "original": item, "kind": "domain_only"}
            domain = p["domain"]
            original = p["original"]

            # --- Mass Alive ---
            if mode == "alive":
                if domain.lower() in checked_domains:
                    if domain.lower() in failed_set:
                        return kind, item, False, None, None, True, "dead"
                    # Hidup, cek dedup
                    if kind == "domain_only":
                        if domain.lower() in alive_do_set:
                            return kind, item, False, None, None, True, "dup"
                        return kind, item, True, domain, None, False, "new"
                    else:
                        if original in alive_wc_set:
                            return kind, item, False, None, None, True, "dup"
                        return kind, item, True, original, None, False, "new"
                # Domain baru
                ok, resp = check_alive(domain)
                if ok:
                    return kind, item, True, original if kind == "with_creds" else domain, None, False, "new"
                else:
                    return kind, item, False, domain, None, False, "dead"

            # --- Mass CMS ---
            else:
                is_alive = False
                resp = None
                if domain.lower() in checked_domains:
                    if domain.lower() in failed_set:
                        return kind, item, False, None, None, True, "dead"
                    is_alive = True
                else:
                    ok, resp = check_alive(domain)
                    if not ok:
                        return kind, item, False, domain, None, False, "dead"
                    is_alive = True

                # CMS check
                cms = cms_map.get(domain.lower())
                if not cms:
                    if resp is None:
                        ok2, resp = check_alive(domain)
                    if resp:
                        cms = detect_cms(dict(resp.headers), resp.text)
                        _mark_cms(domain, cms)
                        cms_map[domain.lower()] = cms
                    else:
                        cms = "RandomCMS"
                return kind, item, True, original if kind == "with_creds" else domain, cms, False, "new"

        _executor = ThreadPoolExecutor(max_workers=MAX_WORKERS)
        futures = {_executor.submit(worker, item): item for item in remaining}
        try:
            for fut in as_completed(futures):
                if stop_flag and stop_flag():
                    stopped = True
                    break
                try:
                    kind_r, item, ok, out, cms, skipped, status = fut.result()
                except Exception:
                    continue

                done += 1
                domain_clean = extract_domain(item) or item

                if skipped:
                    log(f"[-] [{done}/{total}] skip ({status}): {item}")
                elif ok:
                    # Masuk alive (Mass Alive & Mass CMS)
                    if kind_r == "domain_only":
                        if domain_clean.lower() not in alive_do_set:
                            _append_line(ALIVE_DO, domain_clean)
                            alive_do_set.add(domain_clean.lower())
                    else:
                        if out not in alive_wc_set:
                            _append_line(ALIVE_WC, out)
                            alive_wc_set.add(out)

                    if mode == "alive":
                        log(f"[+] [{done}/{total}] alive: {out}")
                    else:
                        if cms in cms_list:
                            sub = "domain_only" if kind_r == "domain_only" else "with_creds"
                            _append_line(RESULT_DIR / cms / f"{sub}.txt", out)
                            log(f"[+] [{done}/{total}] {cms}: {out}")
                        else:
                            log(f"[~] [{done}/{total}] {cms} (skip, not selected): {out}")

                    if domain_clean and domain_clean.lower() not in checked_domains:
                        checked_domains.add(domain_clean.lower())
                        _append_line(CHECKED_DOMAINS, domain_clean.lower())
                else:
                    if domain_clean and domain_clean.lower() not in failed_set:
                        _append_line(FAILED_FILE, domain_clean)
                        failed_set.add(domain_clean.lower())
                    if domain_clean and domain_clean.lower() not in checked_domains:
                        checked_domains.add(domain_clean.lower())
                        _append_line(CHECKED_DOMAINS, domain_clean.lower())
                    log(f"[-] [{done}/{total}] fail: {item}")

                if item in remaining:
                    remaining.remove(item)
                _save_lines(progress_file, remaining)

                if progress_callback and done % 25 == 0:
                    progress_callback(done, total)
        finally:
            if _executor:
                _executor.shutdown(wait=False, cancel_futures=True)
                _executor = None

        if not stopped:
            _save_lines(progress_file, [])
        if stopped:
            break

    if stopped:
        log("[!] Stop — progress tersimpan")
    else:
        log(f"[+] Selesai {done}/{total}")


def check_single(url: str, log_callback=None):
    def log(m):
        if log_callback:
            log_callback(m)

    ensure_dirs()
    domain = extract_domain(url)
    if not domain:
        log("[!] Domain tidak valid")
        return

    log(f"[*] Cek: {domain}")
    ok, resp = check_alive(domain)
    if ok:
        cms = detect_cms(dict(resp.headers), resp.text)
        log(f"[+] 200 OK → {cms}")
    else:
        log("[-] FAIL")
